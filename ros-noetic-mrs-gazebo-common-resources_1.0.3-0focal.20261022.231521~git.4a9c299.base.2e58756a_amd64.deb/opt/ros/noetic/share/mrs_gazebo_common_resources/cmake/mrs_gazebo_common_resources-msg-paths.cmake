# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${mrs_gazebo_common_resources_DIR}/.." "msg" mrs_gazebo_common_resources_MSG_INCLUDE_DIRS UNIQUE)
set(mrs_gazebo_common_resources_MSG_DEPENDENCIES std_msgs)
