
"use strict";

let PoseWithSize = require('./PoseWithSize.js');

module.exports = {
  PoseWithSize: PoseWithSize,
};
