; Auto-generated. Do not edit!


(cl:in-package vins_mono_vins_estimator-msg)


;//! \htmlinclude Diagnostics.msg.html

(cl:defclass <Diagnostics> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (t_triangulate
    :reader t_triangulate
    :initarg :t_triangulate
    :type cl:float
    :initform 0.0)
   (t_solver_prepare
    :reader t_solver_prepare
    :initarg :t_solver_prepare
    :type cl:float
    :initform 0.0)
   (t_solver
    :reader t_solver
    :initarg :t_solver
    :type cl:float
    :initform 0.0)
   (t_marginalize
    :reader t_marginalize
    :initarg :t_marginalize
    :type cl:float
    :initform 0.0)
   (t_optimize_total
    :reader t_optimize_total
    :initarg :t_optimize_total
    :type cl:float
    :initform 0.0)
   (solver_iterations
    :reader solver_iterations
    :initarg :solver_iterations
    :type cl:fixnum
    :initform 0))
)

(cl:defclass Diagnostics (<Diagnostics>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Diagnostics>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Diagnostics)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name vins_mono_vins_estimator-msg:<Diagnostics> is deprecated: use vins_mono_vins_estimator-msg:Diagnostics instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <Diagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader vins_mono_vins_estimator-msg:header-val is deprecated.  Use vins_mono_vins_estimator-msg:header instead.")
  (header m))

(cl:ensure-generic-function 't_triangulate-val :lambda-list '(m))
(cl:defmethod t_triangulate-val ((m <Diagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader vins_mono_vins_estimator-msg:t_triangulate-val is deprecated.  Use vins_mono_vins_estimator-msg:t_triangulate instead.")
  (t_triangulate m))

(cl:ensure-generic-function 't_solver_prepare-val :lambda-list '(m))
(cl:defmethod t_solver_prepare-val ((m <Diagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader vins_mono_vins_estimator-msg:t_solver_prepare-val is deprecated.  Use vins_mono_vins_estimator-msg:t_solver_prepare instead.")
  (t_solver_prepare m))

(cl:ensure-generic-function 't_solver-val :lambda-list '(m))
(cl:defmethod t_solver-val ((m <Diagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader vins_mono_vins_estimator-msg:t_solver-val is deprecated.  Use vins_mono_vins_estimator-msg:t_solver instead.")
  (t_solver m))

(cl:ensure-generic-function 't_marginalize-val :lambda-list '(m))
(cl:defmethod t_marginalize-val ((m <Diagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader vins_mono_vins_estimator-msg:t_marginalize-val is deprecated.  Use vins_mono_vins_estimator-msg:t_marginalize instead.")
  (t_marginalize m))

(cl:ensure-generic-function 't_optimize_total-val :lambda-list '(m))
(cl:defmethod t_optimize_total-val ((m <Diagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader vins_mono_vins_estimator-msg:t_optimize_total-val is deprecated.  Use vins_mono_vins_estimator-msg:t_optimize_total instead.")
  (t_optimize_total m))

(cl:ensure-generic-function 'solver_iterations-val :lambda-list '(m))
(cl:defmethod solver_iterations-val ((m <Diagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader vins_mono_vins_estimator-msg:solver_iterations-val is deprecated.  Use vins_mono_vins_estimator-msg:solver_iterations instead.")
  (solver_iterations m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Diagnostics>) ostream)
  "Serializes a message object of type '<Diagnostics>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 't_triangulate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 't_solver_prepare))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 't_solver))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 't_marginalize))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 't_optimize_total))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'solver_iterations)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Diagnostics>) istream)
  "Deserializes a message object of type '<Diagnostics>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 't_triangulate) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 't_solver_prepare) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 't_solver) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 't_marginalize) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 't_optimize_total) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'solver_iterations)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Diagnostics>)))
  "Returns string type for a message object of type '<Diagnostics>"
  "vins_mono_vins_estimator/Diagnostics")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Diagnostics)))
  "Returns string type for a message object of type 'Diagnostics"
  "vins_mono_vins_estimator/Diagnostics")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Diagnostics>)))
  "Returns md5sum for a message object of type '<Diagnostics>"
  "8df9aa2449ec5e7b97fec426fb37a982")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Diagnostics)))
  "Returns md5sum for a message object of type 'Diagnostics"
  "8df9aa2449ec5e7b97fec426fb37a982")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Diagnostics>)))
  "Returns full string definition for message of type '<Diagnostics>"
  (cl:format cl:nil "std_msgs/Header header~%~%~%float64 t_triangulate~%float64 t_solver_prepare~%float64 t_solver~%float64 t_marginalize~%float64 t_optimize_total~%~%uint8 solver_iterations~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Diagnostics)))
  "Returns full string definition for message of type 'Diagnostics"
  (cl:format cl:nil "std_msgs/Header header~%~%~%float64 t_triangulate~%float64 t_solver_prepare~%float64 t_solver~%float64 t_marginalize~%float64 t_optimize_total~%~%uint8 solver_iterations~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Diagnostics>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     8
     8
     8
     8
     8
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Diagnostics>))
  "Converts a ROS message object to a list"
  (cl:list 'Diagnostics
    (cl:cons ':header (header msg))
    (cl:cons ':t_triangulate (t_triangulate msg))
    (cl:cons ':t_solver_prepare (t_solver_prepare msg))
    (cl:cons ':t_solver (t_solver msg))
    (cl:cons ':t_marginalize (t_marginalize msg))
    (cl:cons ':t_optimize_total (t_optimize_total msg))
    (cl:cons ':solver_iterations (solver_iterations msg))
))
