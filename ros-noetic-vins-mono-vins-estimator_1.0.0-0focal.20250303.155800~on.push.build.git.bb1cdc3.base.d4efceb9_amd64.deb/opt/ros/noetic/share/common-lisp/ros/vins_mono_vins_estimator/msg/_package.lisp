(cl:defpackage vins_mono_vins_estimator-msg
  (:use )
  (:export
   "<DIAGNOSTICS>"
   "DIAGNOSTICS"
  ))

