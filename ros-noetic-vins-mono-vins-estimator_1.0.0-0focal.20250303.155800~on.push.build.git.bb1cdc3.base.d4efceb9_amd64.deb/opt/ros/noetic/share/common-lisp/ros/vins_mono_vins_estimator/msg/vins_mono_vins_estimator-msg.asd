
(cl:in-package :asdf)

(defsystem "vins_mono_vins_estimator-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :std_msgs-msg
)
  :components ((:file "_package")
    (:file "Diagnostics" :depends-on ("_package_Diagnostics"))
    (:file "_package_Diagnostics" :depends-on ("_package"))
  ))