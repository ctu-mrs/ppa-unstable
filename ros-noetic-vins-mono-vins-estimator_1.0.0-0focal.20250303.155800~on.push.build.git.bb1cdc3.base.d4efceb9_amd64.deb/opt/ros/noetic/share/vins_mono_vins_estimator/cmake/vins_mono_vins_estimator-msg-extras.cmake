set(vins_mono_vins_estimator_MESSAGE_FILES "msg/Diagnostics.msg")
set(vins_mono_vins_estimator_SERVICE_FILES "")
