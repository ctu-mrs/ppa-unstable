# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${vins_mono_vins_estimator_DIR}/.." "msg" vins_mono_vins_estimator_MSG_INCLUDE_DIRS UNIQUE)
set(vins_mono_vins_estimator_MSG_DEPENDENCIES std_msgs)
