; Auto-generated. Do not edit!


(cl:in-package mrs_modules_msgs-msg)


;//! \htmlinclude SensorInfo.msg.html

(cl:defclass <SensorInfo> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type cl:string
    :initform "")
   (topic
    :reader topic
    :initarg :topic
    :type cl:string
    :initform "")
   (type
    :reader type
    :initarg :type
    :type cl:fixnum
    :initform 0)
   (expected_rate
    :reader expected_rate
    :initarg :expected_rate
    :type cl:float
    :initform 0.0))
)

(cl:defclass SensorInfo (<SensorInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SensorInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SensorInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_modules_msgs-msg:<SensorInfo> is deprecated: use mrs_modules_msgs-msg:SensorInfo instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <SensorInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-msg:name-val is deprecated.  Use mrs_modules_msgs-msg:name instead.")
  (name m))

(cl:ensure-generic-function 'topic-val :lambda-list '(m))
(cl:defmethod topic-val ((m <SensorInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-msg:topic-val is deprecated.  Use mrs_modules_msgs-msg:topic instead.")
  (topic m))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <SensorInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-msg:type-val is deprecated.  Use mrs_modules_msgs-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'expected_rate-val :lambda-list '(m))
(cl:defmethod expected_rate-val ((m <SensorInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-msg:expected_rate-val is deprecated.  Use mrs_modules_msgs-msg:expected_rate instead.")
  (expected_rate m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<SensorInfo>)))
    "Constants for message type '<SensorInfo>"
  '((:SENSOR_TYPE_UNKNOWN . 0)
    (:SENSOR_TYPE_CAMERA . 1)
    (:SENSOR_TYPE_LIDAR_1D . 2)
    (:SENSOR_TYPE_LIDAR_2D . 3)
    (:SENSOR_TYPE_LIDAR_3D . 4))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'SensorInfo)))
    "Constants for message type 'SensorInfo"
  '((:SENSOR_TYPE_UNKNOWN . 0)
    (:SENSOR_TYPE_CAMERA . 1)
    (:SENSOR_TYPE_LIDAR_1D . 2)
    (:SENSOR_TYPE_LIDAR_2D . 3)
    (:SENSOR_TYPE_LIDAR_3D . 4))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SensorInfo>) ostream)
  "Serializes a message object of type '<SensorInfo>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'name))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'topic))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'topic))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'expected_rate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SensorInfo>) istream)
  "Deserializes a message object of type '<SensorInfo>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'topic) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'topic) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'expected_rate) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SensorInfo>)))
  "Returns string type for a message object of type '<SensorInfo>"
  "mrs_modules_msgs/SensorInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SensorInfo)))
  "Returns string type for a message object of type 'SensorInfo"
  "mrs_modules_msgs/SensorInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SensorInfo>)))
  "Returns md5sum for a message object of type '<SensorInfo>"
  "941a2ed7a40c7cefe15477f16f455b79")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SensorInfo)))
  "Returns md5sum for a message object of type 'SensorInfo"
  "941a2ed7a40c7cefe15477f16f455b79")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SensorInfo>)))
  "Returns full string definition for message of type '<SensorInfo>"
  (cl:format cl:nil "# name of the sensor~%string name~%~%string topic~%~%# sensor type~%uint8 SENSOR_TYPE_UNKNOWN  = 0~%uint8 SENSOR_TYPE_CAMERA   = 1~%uint8 SENSOR_TYPE_LIDAR_1D = 2~%uint8 SENSOR_TYPE_LIDAR_2D = 3~%uint8 SENSOR_TYPE_LIDAR_3D = 4~%uint8 type~%~%float32 expected_rate~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SensorInfo)))
  "Returns full string definition for message of type 'SensorInfo"
  (cl:format cl:nil "# name of the sensor~%string name~%~%string topic~%~%# sensor type~%uint8 SENSOR_TYPE_UNKNOWN  = 0~%uint8 SENSOR_TYPE_CAMERA   = 1~%uint8 SENSOR_TYPE_LIDAR_1D = 2~%uint8 SENSOR_TYPE_LIDAR_2D = 3~%uint8 SENSOR_TYPE_LIDAR_3D = 4~%uint8 type~%~%float32 expected_rate~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SensorInfo>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'name))
     4 (cl:length (cl:slot-value msg 'topic))
     1
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SensorInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'SensorInfo
    (cl:cons ':name (name msg))
    (cl:cons ':topic (topic msg))
    (cl:cons ':type (type msg))
    (cl:cons ':expected_rate (expected_rate msg))
))
