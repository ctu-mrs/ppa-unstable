#!/bin/bash 

sudo timedatectl set-local-rtc 1
