sudo systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target
