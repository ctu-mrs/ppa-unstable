(cl:defpackage nimbro_service_transport-msg
  (:use )
  (:export
   "<SERVICESTATUS>"
   "SERVICESTATUS"
  ))

