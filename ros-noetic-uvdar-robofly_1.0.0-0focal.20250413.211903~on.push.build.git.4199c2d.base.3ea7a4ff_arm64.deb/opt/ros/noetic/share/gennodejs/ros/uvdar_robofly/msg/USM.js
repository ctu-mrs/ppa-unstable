// Auto-generated. Do not edit!

// (in-package uvdar_robofly.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class USM {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.blank_msg = null;
      this.msg_type = null;
      this.payload = null;
    }
    else {
      if (initObj.hasOwnProperty('blank_msg')) {
        this.blank_msg = initObj.blank_msg
      }
      else {
        this.blank_msg = false;
      }
      if (initObj.hasOwnProperty('msg_type')) {
        this.msg_type = initObj.msg_type
      }
      else {
        this.msg_type = 0;
      }
      if (initObj.hasOwnProperty('payload')) {
        this.payload = initObj.payload
      }
      else {
        this.payload = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type USM
    // Serialize message field [blank_msg]
    bufferOffset = _serializer.bool(obj.blank_msg, buffer, bufferOffset);
    // Serialize message field [msg_type]
    bufferOffset = _serializer.int32(obj.msg_type, buffer, bufferOffset);
    // Serialize message field [payload]
    bufferOffset = _arraySerializer.float32(obj.payload, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type USM
    let len;
    let data = new USM(null);
    // Deserialize message field [blank_msg]
    data.blank_msg = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [msg_type]
    data.msg_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [payload]
    data.payload = _arrayDeserializer.float32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.payload.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'uvdar_robofly/USM';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6689f332297817c47d89432ea6a38875';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Uvdar Swarm Message
    bool blank_msg
    int32 msg_type
    float32[] payload
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new USM(null);
    if (msg.blank_msg !== undefined) {
      resolved.blank_msg = msg.blank_msg;
    }
    else {
      resolved.blank_msg = false
    }

    if (msg.msg_type !== undefined) {
      resolved.msg_type = msg.msg_type;
    }
    else {
      resolved.msg_type = 0
    }

    if (msg.payload !== undefined) {
      resolved.payload = msg.payload;
    }
    else {
      resolved.payload = []
    }

    return resolved;
    }
};

module.exports = USM;
