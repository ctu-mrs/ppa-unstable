# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${uvdar_gazebo_plugin_DIR}/.." "msg" uvdar_gazebo_plugin_MSG_INCLUDE_DIRS UNIQUE)
set(uvdar_gazebo_plugin_MSG_DEPENDENCIES std_msgs;uvdar_core)
