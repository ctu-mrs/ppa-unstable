(cl:in-package uvdar_gazebo_plugin-msg)
(cl:export '(DATA_FRAME-VAL
          DATA_FRAME
))