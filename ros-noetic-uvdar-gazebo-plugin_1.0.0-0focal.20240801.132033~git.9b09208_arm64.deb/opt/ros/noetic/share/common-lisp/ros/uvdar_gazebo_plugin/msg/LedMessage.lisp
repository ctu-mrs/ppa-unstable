; Auto-generated. Do not edit!


(cl:in-package uvdar_gazebo_plugin-msg)


;//! \htmlinclude LedMessage.msg.html

(cl:defclass <LedMessage> (roslisp-msg-protocol:ros-message)
  ((data_frame
    :reader data_frame
    :initarg :data_frame
    :type (cl:vector cl:boolean)
   :initform (cl:make-array 0 :element-type 'cl:boolean :initial-element cl:nil)))
)

(cl:defclass LedMessage (<LedMessage>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LedMessage>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LedMessage)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_gazebo_plugin-msg:<LedMessage> is deprecated: use uvdar_gazebo_plugin-msg:LedMessage instead.")))

(cl:ensure-generic-function 'data_frame-val :lambda-list '(m))
(cl:defmethod data_frame-val ((m <LedMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:data_frame-val is deprecated.  Use uvdar_gazebo_plugin-msg:data_frame instead.")
  (data_frame m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LedMessage>) ostream)
  "Serializes a message object of type '<LedMessage>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data_frame))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if ele 1 0)) ostream))
   (cl:slot-value msg 'data_frame))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LedMessage>) istream)
  "Deserializes a message object of type '<LedMessage>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data_frame) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data_frame)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:not (cl:zerop (cl:read-byte istream)))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LedMessage>)))
  "Returns string type for a message object of type '<LedMessage>"
  "uvdar_gazebo_plugin/LedMessage")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LedMessage)))
  "Returns string type for a message object of type 'LedMessage"
  "uvdar_gazebo_plugin/LedMessage")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LedMessage>)))
  "Returns md5sum for a message object of type '<LedMessage>"
  "3e4a8998ae740cf0477421df4e37caee")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LedMessage)))
  "Returns md5sum for a message object of type 'LedMessage"
  "3e4a8998ae740cf0477421df4e37caee")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LedMessage>)))
  "Returns full string definition for message of type '<LedMessage>"
  (cl:format cl:nil "bool[] data_frame~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LedMessage)))
  "Returns full string definition for message of type 'LedMessage"
  (cl:format cl:nil "bool[] data_frame~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LedMessage>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data_frame) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LedMessage>))
  "Converts a ROS message object to a list"
  (cl:list 'LedMessage
    (cl:cons ':data_frame (data_frame msg))
))
