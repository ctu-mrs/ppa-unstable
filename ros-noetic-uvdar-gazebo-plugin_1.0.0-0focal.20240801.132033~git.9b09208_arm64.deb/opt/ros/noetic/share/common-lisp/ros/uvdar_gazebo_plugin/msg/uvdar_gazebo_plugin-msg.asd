
(cl:in-package :asdf)

(defsystem "uvdar_gazebo_plugin-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :std_msgs-msg
)
  :components ((:file "_package")
    (:file "CamInfo" :depends-on ("_package_CamInfo"))
    (:file "_package_CamInfo" :depends-on ("_package"))
    (:file "LedInfo" :depends-on ("_package_LedInfo"))
    (:file "_package_LedInfo" :depends-on ("_package"))
    (:file "LedMessage" :depends-on ("_package_LedMessage"))
    (:file "_package_LedMessage" :depends-on ("_package"))
  ))