
(cl:in-package :asdf)

(defsystem "mrs_modules_msgs-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "SetServo" :depends-on ("_package_SetServo"))
    (:file "_package_SetServo" :depends-on ("_package"))
    (:file "SetTrigger" :depends-on ("_package_SetTrigger"))
    (:file "_package_SetTrigger" :depends-on ("_package"))
  ))