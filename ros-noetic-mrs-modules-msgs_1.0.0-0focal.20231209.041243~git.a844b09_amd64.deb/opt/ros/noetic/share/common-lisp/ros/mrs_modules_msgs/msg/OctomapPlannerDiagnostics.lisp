; Auto-generated. Do not edit!


(cl:in-package mrs_modules_msgs-msg)


;//! \htmlinclude OctomapPlannerDiagnostics.msg.html

(cl:defclass <OctomapPlannerDiagnostics> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (idle
    :reader idle
    :initarg :idle
    :type cl:boolean
    :initform cl:nil)
   (desired_reference
    :reader desired_reference
    :initarg :desired_reference
    :type geometry_msgs-msg:Point
    :initform (cl:make-instance 'geometry_msgs-msg:Point))
   (best_goal
    :reader best_goal
    :initarg :best_goal
    :type geometry_msgs-msg:Point
    :initform (cl:make-instance 'geometry_msgs-msg:Point)))
)

(cl:defclass OctomapPlannerDiagnostics (<OctomapPlannerDiagnostics>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <OctomapPlannerDiagnostics>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'OctomapPlannerDiagnostics)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_modules_msgs-msg:<OctomapPlannerDiagnostics> is deprecated: use mrs_modules_msgs-msg:OctomapPlannerDiagnostics instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <OctomapPlannerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-msg:header-val is deprecated.  Use mrs_modules_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'idle-val :lambda-list '(m))
(cl:defmethod idle-val ((m <OctomapPlannerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-msg:idle-val is deprecated.  Use mrs_modules_msgs-msg:idle instead.")
  (idle m))

(cl:ensure-generic-function 'desired_reference-val :lambda-list '(m))
(cl:defmethod desired_reference-val ((m <OctomapPlannerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-msg:desired_reference-val is deprecated.  Use mrs_modules_msgs-msg:desired_reference instead.")
  (desired_reference m))

(cl:ensure-generic-function 'best_goal-val :lambda-list '(m))
(cl:defmethod best_goal-val ((m <OctomapPlannerDiagnostics>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_modules_msgs-msg:best_goal-val is deprecated.  Use mrs_modules_msgs-msg:best_goal instead.")
  (best_goal m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <OctomapPlannerDiagnostics>) ostream)
  "Serializes a message object of type '<OctomapPlannerDiagnostics>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'idle) 1 0)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'desired_reference) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'best_goal) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <OctomapPlannerDiagnostics>) istream)
  "Deserializes a message object of type '<OctomapPlannerDiagnostics>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:setf (cl:slot-value msg 'idle) (cl:not (cl:zerop (cl:read-byte istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'desired_reference) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'best_goal) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<OctomapPlannerDiagnostics>)))
  "Returns string type for a message object of type '<OctomapPlannerDiagnostics>"
  "mrs_modules_msgs/OctomapPlannerDiagnostics")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'OctomapPlannerDiagnostics)))
  "Returns string type for a message object of type 'OctomapPlannerDiagnostics"
  "mrs_modules_msgs/OctomapPlannerDiagnostics")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<OctomapPlannerDiagnostics>)))
  "Returns md5sum for a message object of type '<OctomapPlannerDiagnostics>"
  "8d93eea4b3519478cd470e5b07e11263")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'OctomapPlannerDiagnostics)))
  "Returns md5sum for a message object of type 'OctomapPlannerDiagnostics"
  "8d93eea4b3519478cd470e5b07e11263")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<OctomapPlannerDiagnostics>)))
  "Returns full string definition for message of type '<OctomapPlannerDiagnostics>"
  (cl:format cl:nil "Header header~%~%bool idle~%geometry_msgs/Point desired_reference~%geometry_msgs/Point best_goal~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'OctomapPlannerDiagnostics)))
  "Returns full string definition for message of type 'OctomapPlannerDiagnostics"
  (cl:format cl:nil "Header header~%~%bool idle~%geometry_msgs/Point desired_reference~%geometry_msgs/Point best_goal~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <OctomapPlannerDiagnostics>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     1
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'desired_reference))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'best_goal))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <OctomapPlannerDiagnostics>))
  "Converts a ROS message object to a list"
  (cl:list 'OctomapPlannerDiagnostics
    (cl:cons ':header (header msg))
    (cl:cons ':idle (idle msg))
    (cl:cons ':desired_reference (desired_reference msg))
    (cl:cons ':best_goal (best_goal msg))
))
