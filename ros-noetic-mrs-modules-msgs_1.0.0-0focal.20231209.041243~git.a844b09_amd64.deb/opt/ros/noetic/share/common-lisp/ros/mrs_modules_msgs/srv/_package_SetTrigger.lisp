(cl:in-package mrs_modules_msgs-srv)
(cl:export '(TRIGGER-VAL
          TRIGGER
          TRIGGER_NUM-VAL
          TRIGGER_NUM
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))