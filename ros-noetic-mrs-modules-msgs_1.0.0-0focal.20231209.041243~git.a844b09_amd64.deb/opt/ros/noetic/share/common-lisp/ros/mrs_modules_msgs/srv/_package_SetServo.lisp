(cl:in-package mrs_modules_msgs-srv)
(cl:export '(SERVO1_VAL-VAL
          SERVO1_VAL
          SERVO2_VAL-VAL
          SERVO2_VAL
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))