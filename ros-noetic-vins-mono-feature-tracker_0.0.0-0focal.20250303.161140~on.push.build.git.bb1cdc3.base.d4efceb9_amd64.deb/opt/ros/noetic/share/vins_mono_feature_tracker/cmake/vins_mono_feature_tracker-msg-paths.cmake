# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${vins_mono_feature_tracker_DIR}/.." "msg" vins_mono_feature_tracker_MSG_INCLUDE_DIRS UNIQUE)
set(vins_mono_feature_tracker_MSG_DEPENDENCIES std_msgs)
