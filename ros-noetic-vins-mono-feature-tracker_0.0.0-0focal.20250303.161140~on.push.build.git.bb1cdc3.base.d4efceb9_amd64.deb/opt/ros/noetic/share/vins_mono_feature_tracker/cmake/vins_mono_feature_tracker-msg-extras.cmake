set(vins_mono_feature_tracker_MESSAGE_FILES "msg/Diagnostics.msg")
set(vins_mono_feature_tracker_SERVICE_FILES "")
