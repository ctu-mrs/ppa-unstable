(cl:defpackage vins_mono_feature_tracker-msg
  (:use )
  (:export
   "<DIAGNOSTICS>"
   "DIAGNOSTICS"
  ))

