// Auto-generated. Do not edit!

// (in-package mrs_pcl_tools.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SrvRegisterPointCloudByNameRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.uav_name = null;
      this.init_guess_use = null;
      this.init_guess_translation = null;
      this.init_guess_yaw = null;
    }
    else {
      if (initObj.hasOwnProperty('uav_name')) {
        this.uav_name = initObj.uav_name
      }
      else {
        this.uav_name = '';
      }
      if (initObj.hasOwnProperty('init_guess_use')) {
        this.init_guess_use = initObj.init_guess_use
      }
      else {
        this.init_guess_use = false;
      }
      if (initObj.hasOwnProperty('init_guess_translation')) {
        this.init_guess_translation = initObj.init_guess_translation
      }
      else {
        this.init_guess_translation = new geometry_msgs.msg.Point();
      }
      if (initObj.hasOwnProperty('init_guess_yaw')) {
        this.init_guess_yaw = initObj.init_guess_yaw
      }
      else {
        this.init_guess_yaw = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SrvRegisterPointCloudByNameRequest
    // Serialize message field [uav_name]
    bufferOffset = _serializer.string(obj.uav_name, buffer, bufferOffset);
    // Serialize message field [init_guess_use]
    bufferOffset = _serializer.bool(obj.init_guess_use, buffer, bufferOffset);
    // Serialize message field [init_guess_translation]
    bufferOffset = geometry_msgs.msg.Point.serialize(obj.init_guess_translation, buffer, bufferOffset);
    // Serialize message field [init_guess_yaw]
    bufferOffset = _serializer.float64(obj.init_guess_yaw, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SrvRegisterPointCloudByNameRequest
    let len;
    let data = new SrvRegisterPointCloudByNameRequest(null);
    // Deserialize message field [uav_name]
    data.uav_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [init_guess_use]
    data.init_guess_use = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [init_guess_translation]
    data.init_guess_translation = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [init_guess_yaw]
    data.init_guess_yaw = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.uav_name);
    return length + 37;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mrs_pcl_tools/SrvRegisterPointCloudByNameRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9a63b645d69ecf4fe3e7b5309640985a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string              uav_name
    bool                init_guess_use
    geometry_msgs/Point init_guess_translation
    float64             init_guess_yaw
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SrvRegisterPointCloudByNameRequest(null);
    if (msg.uav_name !== undefined) {
      resolved.uav_name = msg.uav_name;
    }
    else {
      resolved.uav_name = ''
    }

    if (msg.init_guess_use !== undefined) {
      resolved.init_guess_use = msg.init_guess_use;
    }
    else {
      resolved.init_guess_use = false
    }

    if (msg.init_guess_translation !== undefined) {
      resolved.init_guess_translation = geometry_msgs.msg.Point.Resolve(msg.init_guess_translation)
    }
    else {
      resolved.init_guess_translation = new geometry_msgs.msg.Point()
    }

    if (msg.init_guess_yaw !== undefined) {
      resolved.init_guess_yaw = msg.init_guess_yaw;
    }
    else {
      resolved.init_guess_yaw = 0.0
    }

    return resolved;
    }
};

class SrvRegisterPointCloudByNameResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
      this.transform = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('transform')) {
        this.transform = initObj.transform
      }
      else {
        this.transform = new geometry_msgs.msg.TransformStamped();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SrvRegisterPointCloudByNameResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [transform]
    bufferOffset = geometry_msgs.msg.TransformStamped.serialize(obj.transform, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SrvRegisterPointCloudByNameResponse
    let len;
    let data = new SrvRegisterPointCloudByNameResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [transform]
    data.transform = geometry_msgs.msg.TransformStamped.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.message);
    length += geometry_msgs.msg.TransformStamped.getMessageSize(object.transform);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mrs_pcl_tools/SrvRegisterPointCloudByNameResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd8d29a2ef6558013af0acd6758fbe3de';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    geometry_msgs/TransformStamped transform
    
    
    ================================================================================
    MSG: geometry_msgs/TransformStamped
    # This expresses a transform from coordinate frame header.frame_id
    # to the coordinate frame child_frame_id
    #
    # This message is mostly used by the 
    # <a href="http://wiki.ros.org/tf">tf</a> package. 
    # See its documentation for more information.
    
    Header header
    string child_frame_id # the frame id of the child frame
    Transform transform
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Transform
    # This represents the transform between two coordinate frames in free space.
    
    Vector3 translation
    Quaternion rotation
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SrvRegisterPointCloudByNameResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.transform !== undefined) {
      resolved.transform = geometry_msgs.msg.TransformStamped.Resolve(msg.transform)
    }
    else {
      resolved.transform = new geometry_msgs.msg.TransformStamped()
    }

    return resolved;
    }
};

module.exports = {
  Request: SrvRegisterPointCloudByNameRequest,
  Response: SrvRegisterPointCloudByNameResponse,
  md5sum() { return 'd46abbe9775a756780c6c6b373c6e89a'; },
  datatype() { return 'mrs_pcl_tools/SrvRegisterPointCloudByName'; }
};
