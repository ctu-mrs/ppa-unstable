; Auto-generated. Do not edit!


(cl:in-package uvdar_gazebo_plugin-msg)


;//! \htmlinclude LedInfo.msg.html

(cl:defclass <LedInfo> (roslisp-msg-protocol:ros-message)
  ((seq_bitrate
    :reader seq_bitrate
    :initarg :seq_bitrate
    :type std_msgs-msg:Float64
    :initform (cl:make-instance 'std_msgs-msg:Float64))
   (mes_bitrate
    :reader mes_bitrate
    :initarg :mes_bitrate
    :type std_msgs-msg:Float64
    :initform (cl:make-instance 'std_msgs-msg:Float64))
   (ID
    :reader ID
    :initarg :ID
    :type std_msgs-msg:Int32
    :initform (cl:make-instance 'std_msgs-msg:Int32))
   (link_name
    :reader link_name
    :initarg :link_name
    :type std_msgs-msg:String
    :initform (cl:make-instance 'std_msgs-msg:String))
   (device_id
    :reader device_id
    :initarg :device_id
    :type std_msgs-msg:String
    :initform (cl:make-instance 'std_msgs-msg:String))
   (active
    :reader active
    :initarg :active
    :type std_msgs-msg:Bool
    :initform (cl:make-instance 'std_msgs-msg:Bool))
   (mode
    :reader mode
    :initarg :mode
    :type std_msgs-msg:Int32
    :initform (cl:make-instance 'std_msgs-msg:Int32)))
)

(cl:defclass LedInfo (<LedInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LedInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LedInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_gazebo_plugin-msg:<LedInfo> is deprecated: use uvdar_gazebo_plugin-msg:LedInfo instead.")))

(cl:ensure-generic-function 'seq_bitrate-val :lambda-list '(m))
(cl:defmethod seq_bitrate-val ((m <LedInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:seq_bitrate-val is deprecated.  Use uvdar_gazebo_plugin-msg:seq_bitrate instead.")
  (seq_bitrate m))

(cl:ensure-generic-function 'mes_bitrate-val :lambda-list '(m))
(cl:defmethod mes_bitrate-val ((m <LedInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:mes_bitrate-val is deprecated.  Use uvdar_gazebo_plugin-msg:mes_bitrate instead.")
  (mes_bitrate m))

(cl:ensure-generic-function 'ID-val :lambda-list '(m))
(cl:defmethod ID-val ((m <LedInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:ID-val is deprecated.  Use uvdar_gazebo_plugin-msg:ID instead.")
  (ID m))

(cl:ensure-generic-function 'link_name-val :lambda-list '(m))
(cl:defmethod link_name-val ((m <LedInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:link_name-val is deprecated.  Use uvdar_gazebo_plugin-msg:link_name instead.")
  (link_name m))

(cl:ensure-generic-function 'device_id-val :lambda-list '(m))
(cl:defmethod device_id-val ((m <LedInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:device_id-val is deprecated.  Use uvdar_gazebo_plugin-msg:device_id instead.")
  (device_id m))

(cl:ensure-generic-function 'active-val :lambda-list '(m))
(cl:defmethod active-val ((m <LedInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:active-val is deprecated.  Use uvdar_gazebo_plugin-msg:active instead.")
  (active m))

(cl:ensure-generic-function 'mode-val :lambda-list '(m))
(cl:defmethod mode-val ((m <LedInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_gazebo_plugin-msg:mode-val is deprecated.  Use uvdar_gazebo_plugin-msg:mode instead.")
  (mode m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LedInfo>) ostream)
  "Serializes a message object of type '<LedInfo>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'seq_bitrate) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'mes_bitrate) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'ID) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'link_name) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'device_id) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'active) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'mode) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LedInfo>) istream)
  "Deserializes a message object of type '<LedInfo>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'seq_bitrate) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'mes_bitrate) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'ID) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'link_name) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'device_id) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'active) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'mode) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LedInfo>)))
  "Returns string type for a message object of type '<LedInfo>"
  "uvdar_gazebo_plugin/LedInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LedInfo)))
  "Returns string type for a message object of type 'LedInfo"
  "uvdar_gazebo_plugin/LedInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LedInfo>)))
  "Returns md5sum for a message object of type '<LedInfo>"
  "54979e00e6253418143263d0883238a0")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LedInfo)))
  "Returns md5sum for a message object of type 'LedInfo"
  "54979e00e6253418143263d0883238a0")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LedInfo>)))
  "Returns full string definition for message of type '<LedInfo>"
  (cl:format cl:nil "std_msgs/Float64 seq_bitrate~%std_msgs/Float64 mes_bitrate~%std_msgs/Int32 ID~%std_msgs/String link_name~%std_msgs/String device_id~%std_msgs/Bool active~%std_msgs/Int32 mode~%~%================================================================================~%MSG: std_msgs/Float64~%float64 data~%================================================================================~%MSG: std_msgs/Int32~%int32 data~%================================================================================~%MSG: std_msgs/String~%string data~%~%================================================================================~%MSG: std_msgs/Bool~%bool data~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LedInfo)))
  "Returns full string definition for message of type 'LedInfo"
  (cl:format cl:nil "std_msgs/Float64 seq_bitrate~%std_msgs/Float64 mes_bitrate~%std_msgs/Int32 ID~%std_msgs/String link_name~%std_msgs/String device_id~%std_msgs/Bool active~%std_msgs/Int32 mode~%~%================================================================================~%MSG: std_msgs/Float64~%float64 data~%================================================================================~%MSG: std_msgs/Int32~%int32 data~%================================================================================~%MSG: std_msgs/String~%string data~%~%================================================================================~%MSG: std_msgs/Bool~%bool data~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LedInfo>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'seq_bitrate))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'mes_bitrate))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'ID))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'link_name))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'device_id))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'active))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'mode))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LedInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'LedInfo
    (cl:cons ':seq_bitrate (seq_bitrate msg))
    (cl:cons ':mes_bitrate (mes_bitrate msg))
    (cl:cons ':ID (ID msg))
    (cl:cons ':link_name (link_name msg))
    (cl:cons ':device_id (device_id msg))
    (cl:cons ':active (active msg))
    (cl:cons ':mode (mode msg))
))
