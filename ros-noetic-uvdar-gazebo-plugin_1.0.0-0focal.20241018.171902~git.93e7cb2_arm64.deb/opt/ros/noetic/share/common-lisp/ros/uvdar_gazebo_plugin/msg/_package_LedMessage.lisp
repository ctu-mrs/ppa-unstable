(cl:in-package uvdar_gazebo_plugin-msg)
(cl:export '(LINK_NAME-VAL
          LINK_NAME
          DATA_FRAME-VAL
          DATA_FRAME
))