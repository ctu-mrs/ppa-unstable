# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${mrs_errorgraph_DIR}/.." "msg" mrs_errorgraph_MSG_INCLUDE_DIRS UNIQUE)
set(mrs_errorgraph_MSG_DEPENDENCIES std_msgs)
