set(mrs_errorgraph_MESSAGE_FILES "msg/ErrorgraphNodeID.msg;msg/ErrorgraphError.msg;msg/ErrorgraphElement.msg;msg/ErrorgraphElementArray.msg")
set(mrs_errorgraph_SERVICE_FILES "")
