; Auto-generated. Do not edit!


(cl:in-package mrs_errorgraph-msg)


;//! \htmlinclude ErrorgraphElementArray.msg.html

(cl:defclass <ErrorgraphElementArray> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (elements
    :reader elements
    :initarg :elements
    :type (cl:vector mrs_errorgraph-msg:ErrorgraphElement)
   :initform (cl:make-array 0 :element-type 'mrs_errorgraph-msg:ErrorgraphElement :initial-element (cl:make-instance 'mrs_errorgraph-msg:ErrorgraphElement))))
)

(cl:defclass ErrorgraphElementArray (<ErrorgraphElementArray>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ErrorgraphElementArray>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ErrorgraphElementArray)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_errorgraph-msg:<ErrorgraphElementArray> is deprecated: use mrs_errorgraph-msg:ErrorgraphElementArray instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <ErrorgraphElementArray>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:stamp-val is deprecated.  Use mrs_errorgraph-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'elements-val :lambda-list '(m))
(cl:defmethod elements-val ((m <ErrorgraphElementArray>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:elements-val is deprecated.  Use mrs_errorgraph-msg:elements instead.")
  (elements m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ErrorgraphElementArray>) ostream)
  "Serializes a message object of type '<ErrorgraphElementArray>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'elements))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'elements))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ErrorgraphElementArray>) istream)
  "Deserializes a message object of type '<ErrorgraphElementArray>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'elements) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'elements)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'mrs_errorgraph-msg:ErrorgraphElement))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ErrorgraphElementArray>)))
  "Returns string type for a message object of type '<ErrorgraphElementArray>"
  "mrs_errorgraph/ErrorgraphElementArray")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ErrorgraphElementArray)))
  "Returns string type for a message object of type 'ErrorgraphElementArray"
  "mrs_errorgraph/ErrorgraphElementArray")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ErrorgraphElementArray>)))
  "Returns md5sum for a message object of type '<ErrorgraphElementArray>"
  "50e18f4bec404a11351cd43f5c14fa48")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ErrorgraphElementArray)))
  "Returns md5sum for a message object of type 'ErrorgraphElementArray"
  "50e18f4bec404a11351cd43f5c14fa48")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ErrorgraphElementArray>)))
  "Returns full string definition for message of type '<ErrorgraphElementArray>"
  (cl:format cl:nil "time stamp~%~%ErrorgraphElement[] elements~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphElement~%time stamp~%~%mrs_errorgraph/ErrorgraphNodeID source_node~%~%mrs_errorgraph/ErrorgraphError[] errors~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphNodeID~%# unique identifier of a node that can be a source of an error~%string node~%# optional identifier of a component within the node~%string component~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphError~%time stamp~%~%string type~%~%string waited_for_topic~%mrs_errorgraph/ErrorgraphNodeID waited_for_node~%~%string TYPE_WAITING_FOR_TOPIC = waiting_for_topic~%string TYPE_WAITING_FOR_NODE = waiting_for_node~%string TYPE_NOT_REPORTING = not_reporting~%string TYPE_NO_ERROR = no_error~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ErrorgraphElementArray)))
  "Returns full string definition for message of type 'ErrorgraphElementArray"
  (cl:format cl:nil "time stamp~%~%ErrorgraphElement[] elements~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphElement~%time stamp~%~%mrs_errorgraph/ErrorgraphNodeID source_node~%~%mrs_errorgraph/ErrorgraphError[] errors~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphNodeID~%# unique identifier of a node that can be a source of an error~%string node~%# optional identifier of a component within the node~%string component~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphError~%time stamp~%~%string type~%~%string waited_for_topic~%mrs_errorgraph/ErrorgraphNodeID waited_for_node~%~%string TYPE_WAITING_FOR_TOPIC = waiting_for_topic~%string TYPE_WAITING_FOR_NODE = waiting_for_node~%string TYPE_NOT_REPORTING = not_reporting~%string TYPE_NO_ERROR = no_error~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ErrorgraphElementArray>))
  (cl:+ 0
     8
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'elements) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ErrorgraphElementArray>))
  "Converts a ROS message object to a list"
  (cl:list 'ErrorgraphElementArray
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':elements (elements msg))
))
