; Auto-generated. Do not edit!


(cl:in-package mrs_errorgraph-msg)


;//! \htmlinclude ErrorgraphNodeID.msg.html

(cl:defclass <ErrorgraphNodeID> (roslisp-msg-protocol:ros-message)
  ((node
    :reader node
    :initarg :node
    :type cl:string
    :initform "")
   (component
    :reader component
    :initarg :component
    :type cl:string
    :initform ""))
)

(cl:defclass ErrorgraphNodeID (<ErrorgraphNodeID>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ErrorgraphNodeID>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ErrorgraphNodeID)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_errorgraph-msg:<ErrorgraphNodeID> is deprecated: use mrs_errorgraph-msg:ErrorgraphNodeID instead.")))

(cl:ensure-generic-function 'node-val :lambda-list '(m))
(cl:defmethod node-val ((m <ErrorgraphNodeID>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:node-val is deprecated.  Use mrs_errorgraph-msg:node instead.")
  (node m))

(cl:ensure-generic-function 'component-val :lambda-list '(m))
(cl:defmethod component-val ((m <ErrorgraphNodeID>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:component-val is deprecated.  Use mrs_errorgraph-msg:component instead.")
  (component m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ErrorgraphNodeID>) ostream)
  "Serializes a message object of type '<ErrorgraphNodeID>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'node))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'node))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'component))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'component))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ErrorgraphNodeID>) istream)
  "Deserializes a message object of type '<ErrorgraphNodeID>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'node) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'node) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'component) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'component) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ErrorgraphNodeID>)))
  "Returns string type for a message object of type '<ErrorgraphNodeID>"
  "mrs_errorgraph/ErrorgraphNodeID")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ErrorgraphNodeID)))
  "Returns string type for a message object of type 'ErrorgraphNodeID"
  "mrs_errorgraph/ErrorgraphNodeID")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ErrorgraphNodeID>)))
  "Returns md5sum for a message object of type '<ErrorgraphNodeID>"
  "021c4eb002fdf940453828d71c49326a")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ErrorgraphNodeID)))
  "Returns md5sum for a message object of type 'ErrorgraphNodeID"
  "021c4eb002fdf940453828d71c49326a")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ErrorgraphNodeID>)))
  "Returns full string definition for message of type '<ErrorgraphNodeID>"
  (cl:format cl:nil "# unique identifier of a node that can be a source of an error~%string node~%# optional identifier of a component within the node~%string component~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ErrorgraphNodeID)))
  "Returns full string definition for message of type 'ErrorgraphNodeID"
  (cl:format cl:nil "# unique identifier of a node that can be a source of an error~%string node~%# optional identifier of a component within the node~%string component~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ErrorgraphNodeID>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'node))
     4 (cl:length (cl:slot-value msg 'component))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ErrorgraphNodeID>))
  "Converts a ROS message object to a list"
  (cl:list 'ErrorgraphNodeID
    (cl:cons ':node (node msg))
    (cl:cons ':component (component msg))
))
