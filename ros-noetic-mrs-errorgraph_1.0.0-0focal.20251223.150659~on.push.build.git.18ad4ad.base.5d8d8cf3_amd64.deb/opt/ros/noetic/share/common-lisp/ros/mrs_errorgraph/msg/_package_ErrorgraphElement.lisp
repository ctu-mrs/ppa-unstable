(cl:in-package mrs_errorgraph-msg)
(cl:export '(STAMP-VAL
          STAMP
          SOURCE_NODE-VAL
          SOURCE_NODE
          ERRORS-VAL
          ERRORS
))