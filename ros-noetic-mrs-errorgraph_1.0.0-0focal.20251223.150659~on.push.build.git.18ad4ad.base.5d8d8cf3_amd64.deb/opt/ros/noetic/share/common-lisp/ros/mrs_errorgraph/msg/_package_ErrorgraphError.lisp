(cl:in-package mrs_errorgraph-msg)
(cl:export '(STAMP-VAL
          STAMP
          TYPE-VAL
          TYPE
          WAITED_FOR_TOPIC-VAL
          WAITED_FOR_TOPIC
          WAITED_FOR_NODE-VAL
          WAITED_FOR_NODE
))