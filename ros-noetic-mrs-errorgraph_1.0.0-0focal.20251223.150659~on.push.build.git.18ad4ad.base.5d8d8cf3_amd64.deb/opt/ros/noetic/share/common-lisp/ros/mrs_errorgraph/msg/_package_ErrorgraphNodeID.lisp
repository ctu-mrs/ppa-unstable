(cl:in-package mrs_errorgraph-msg)
(cl:export '(NODE-VAL
          NODE
          COMPONENT-VAL
          COMPONENT
))