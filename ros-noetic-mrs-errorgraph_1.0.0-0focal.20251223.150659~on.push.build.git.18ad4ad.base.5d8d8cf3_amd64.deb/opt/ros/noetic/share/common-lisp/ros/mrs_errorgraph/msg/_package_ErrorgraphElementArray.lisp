(cl:in-package mrs_errorgraph-msg)
(cl:export '(STAMP-VAL
          STAMP
          ELEMENTS-VAL
          ELEMENTS
))