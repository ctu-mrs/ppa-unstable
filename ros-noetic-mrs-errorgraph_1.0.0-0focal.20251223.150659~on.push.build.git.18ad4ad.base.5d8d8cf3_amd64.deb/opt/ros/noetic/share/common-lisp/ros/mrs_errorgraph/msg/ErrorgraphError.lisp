; Auto-generated. Do not edit!


(cl:in-package mrs_errorgraph-msg)


;//! \htmlinclude ErrorgraphError.msg.html

(cl:defclass <ErrorgraphError> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (type
    :reader type
    :initarg :type
    :type cl:string
    :initform "")
   (waited_for_topic
    :reader waited_for_topic
    :initarg :waited_for_topic
    :type cl:string
    :initform "")
   (waited_for_node
    :reader waited_for_node
    :initarg :waited_for_node
    :type mrs_errorgraph-msg:ErrorgraphNodeID
    :initform (cl:make-instance 'mrs_errorgraph-msg:ErrorgraphNodeID)))
)

(cl:defclass ErrorgraphError (<ErrorgraphError>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ErrorgraphError>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ErrorgraphError)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_errorgraph-msg:<ErrorgraphError> is deprecated: use mrs_errorgraph-msg:ErrorgraphError instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <ErrorgraphError>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:stamp-val is deprecated.  Use mrs_errorgraph-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <ErrorgraphError>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:type-val is deprecated.  Use mrs_errorgraph-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'waited_for_topic-val :lambda-list '(m))
(cl:defmethod waited_for_topic-val ((m <ErrorgraphError>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:waited_for_topic-val is deprecated.  Use mrs_errorgraph-msg:waited_for_topic instead.")
  (waited_for_topic m))

(cl:ensure-generic-function 'waited_for_node-val :lambda-list '(m))
(cl:defmethod waited_for_node-val ((m <ErrorgraphError>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:waited_for_node-val is deprecated.  Use mrs_errorgraph-msg:waited_for_node instead.")
  (waited_for_node m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<ErrorgraphError>)))
    "Constants for message type '<ErrorgraphError>"
  '((:TYPE_WAITING_FOR_TOPIC . "waiting_for_topic")
    (:TYPE_WAITING_FOR_NODE . "waiting_for_node")
    (:TYPE_NOT_REPORTING . "not_reporting")
    (:TYPE_NO_ERROR . "no_error"))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'ErrorgraphError)))
    "Constants for message type 'ErrorgraphError"
  '((:TYPE_WAITING_FOR_TOPIC . "waiting_for_topic")
    (:TYPE_WAITING_FOR_NODE . "waiting_for_node")
    (:TYPE_NOT_REPORTING . "not_reporting")
    (:TYPE_NO_ERROR . "no_error"))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ErrorgraphError>) ostream)
  "Serializes a message object of type '<ErrorgraphError>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'type))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'type))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'waited_for_topic))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'waited_for_topic))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'waited_for_node) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ErrorgraphError>) istream)
  "Deserializes a message object of type '<ErrorgraphError>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'type) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'type) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'waited_for_topic) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'waited_for_topic) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'waited_for_node) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ErrorgraphError>)))
  "Returns string type for a message object of type '<ErrorgraphError>"
  "mrs_errorgraph/ErrorgraphError")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ErrorgraphError)))
  "Returns string type for a message object of type 'ErrorgraphError"
  "mrs_errorgraph/ErrorgraphError")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ErrorgraphError>)))
  "Returns md5sum for a message object of type '<ErrorgraphError>"
  "c8a5347848a549ac92fbe848ea183835")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ErrorgraphError)))
  "Returns md5sum for a message object of type 'ErrorgraphError"
  "c8a5347848a549ac92fbe848ea183835")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ErrorgraphError>)))
  "Returns full string definition for message of type '<ErrorgraphError>"
  (cl:format cl:nil "time stamp~%~%string type~%~%string waited_for_topic~%mrs_errorgraph/ErrorgraphNodeID waited_for_node~%~%string TYPE_WAITING_FOR_TOPIC = waiting_for_topic~%string TYPE_WAITING_FOR_NODE = waiting_for_node~%string TYPE_NOT_REPORTING = not_reporting~%string TYPE_NO_ERROR = no_error~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphNodeID~%# unique identifier of a node that can be a source of an error~%string node~%# optional identifier of a component within the node~%string component~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ErrorgraphError)))
  "Returns full string definition for message of type 'ErrorgraphError"
  (cl:format cl:nil "time stamp~%~%string type~%~%string waited_for_topic~%mrs_errorgraph/ErrorgraphNodeID waited_for_node~%~%string TYPE_WAITING_FOR_TOPIC = waiting_for_topic~%string TYPE_WAITING_FOR_NODE = waiting_for_node~%string TYPE_NOT_REPORTING = not_reporting~%string TYPE_NO_ERROR = no_error~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphNodeID~%# unique identifier of a node that can be a source of an error~%string node~%# optional identifier of a component within the node~%string component~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ErrorgraphError>))
  (cl:+ 0
     8
     4 (cl:length (cl:slot-value msg 'type))
     4 (cl:length (cl:slot-value msg 'waited_for_topic))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'waited_for_node))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ErrorgraphError>))
  "Converts a ROS message object to a list"
  (cl:list 'ErrorgraphError
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':type (type msg))
    (cl:cons ':waited_for_topic (waited_for_topic msg))
    (cl:cons ':waited_for_node (waited_for_node msg))
))
