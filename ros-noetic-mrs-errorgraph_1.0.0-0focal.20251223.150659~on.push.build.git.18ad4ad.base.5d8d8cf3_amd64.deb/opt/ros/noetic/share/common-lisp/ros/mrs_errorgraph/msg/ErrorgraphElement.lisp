; Auto-generated. Do not edit!


(cl:in-package mrs_errorgraph-msg)


;//! \htmlinclude ErrorgraphElement.msg.html

(cl:defclass <ErrorgraphElement> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (source_node
    :reader source_node
    :initarg :source_node
    :type mrs_errorgraph-msg:ErrorgraphNodeID
    :initform (cl:make-instance 'mrs_errorgraph-msg:ErrorgraphNodeID))
   (errors
    :reader errors
    :initarg :errors
    :type (cl:vector mrs_errorgraph-msg:ErrorgraphError)
   :initform (cl:make-array 0 :element-type 'mrs_errorgraph-msg:ErrorgraphError :initial-element (cl:make-instance 'mrs_errorgraph-msg:ErrorgraphError))))
)

(cl:defclass ErrorgraphElement (<ErrorgraphElement>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ErrorgraphElement>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ErrorgraphElement)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_errorgraph-msg:<ErrorgraphElement> is deprecated: use mrs_errorgraph-msg:ErrorgraphElement instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <ErrorgraphElement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:stamp-val is deprecated.  Use mrs_errorgraph-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'source_node-val :lambda-list '(m))
(cl:defmethod source_node-val ((m <ErrorgraphElement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:source_node-val is deprecated.  Use mrs_errorgraph-msg:source_node instead.")
  (source_node m))

(cl:ensure-generic-function 'errors-val :lambda-list '(m))
(cl:defmethod errors-val ((m <ErrorgraphElement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_errorgraph-msg:errors-val is deprecated.  Use mrs_errorgraph-msg:errors instead.")
  (errors m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ErrorgraphElement>) ostream)
  "Serializes a message object of type '<ErrorgraphElement>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'source_node) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'errors))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'errors))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ErrorgraphElement>) istream)
  "Deserializes a message object of type '<ErrorgraphElement>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'source_node) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'errors) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'errors)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'mrs_errorgraph-msg:ErrorgraphError))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ErrorgraphElement>)))
  "Returns string type for a message object of type '<ErrorgraphElement>"
  "mrs_errorgraph/ErrorgraphElement")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ErrorgraphElement)))
  "Returns string type for a message object of type 'ErrorgraphElement"
  "mrs_errorgraph/ErrorgraphElement")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ErrorgraphElement>)))
  "Returns md5sum for a message object of type '<ErrorgraphElement>"
  "df6fc48e0950c218435f0fb10ac5c3df")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ErrorgraphElement)))
  "Returns md5sum for a message object of type 'ErrorgraphElement"
  "df6fc48e0950c218435f0fb10ac5c3df")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ErrorgraphElement>)))
  "Returns full string definition for message of type '<ErrorgraphElement>"
  (cl:format cl:nil "time stamp~%~%mrs_errorgraph/ErrorgraphNodeID source_node~%~%mrs_errorgraph/ErrorgraphError[] errors~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphNodeID~%# unique identifier of a node that can be a source of an error~%string node~%# optional identifier of a component within the node~%string component~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphError~%time stamp~%~%string type~%~%string waited_for_topic~%mrs_errorgraph/ErrorgraphNodeID waited_for_node~%~%string TYPE_WAITING_FOR_TOPIC = waiting_for_topic~%string TYPE_WAITING_FOR_NODE = waiting_for_node~%string TYPE_NOT_REPORTING = not_reporting~%string TYPE_NO_ERROR = no_error~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ErrorgraphElement)))
  "Returns full string definition for message of type 'ErrorgraphElement"
  (cl:format cl:nil "time stamp~%~%mrs_errorgraph/ErrorgraphNodeID source_node~%~%mrs_errorgraph/ErrorgraphError[] errors~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphNodeID~%# unique identifier of a node that can be a source of an error~%string node~%# optional identifier of a component within the node~%string component~%~%================================================================================~%MSG: mrs_errorgraph/ErrorgraphError~%time stamp~%~%string type~%~%string waited_for_topic~%mrs_errorgraph/ErrorgraphNodeID waited_for_node~%~%string TYPE_WAITING_FOR_TOPIC = waiting_for_topic~%string TYPE_WAITING_FOR_NODE = waiting_for_node~%string TYPE_NOT_REPORTING = not_reporting~%string TYPE_NO_ERROR = no_error~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ErrorgraphElement>))
  (cl:+ 0
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'source_node))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'errors) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ErrorgraphElement>))
  "Converts a ROS message object to a list"
  (cl:list 'ErrorgraphElement
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':source_node (source_node msg))
    (cl:cons ':errors (errors msg))
))
