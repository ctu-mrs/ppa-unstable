// Auto-generated. Do not edit!

// (in-package mrs_errorgraph.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ErrorgraphElement = require('./ErrorgraphElement.js');

//-----------------------------------------------------------

class ErrorgraphElementArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.elements = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('elements')) {
        this.elements = initObj.elements
      }
      else {
        this.elements = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ErrorgraphElementArray
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [elements]
    // Serialize the length for message field [elements]
    bufferOffset = _serializer.uint32(obj.elements.length, buffer, bufferOffset);
    obj.elements.forEach((val) => {
      bufferOffset = ErrorgraphElement.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ErrorgraphElementArray
    let len;
    let data = new ErrorgraphElementArray(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [elements]
    // Deserialize array length for message field [elements]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.elements = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.elements[i] = ErrorgraphElement.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.elements.forEach((val) => {
      length += ErrorgraphElement.getMessageSize(val);
    });
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_errorgraph/ErrorgraphElementArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '50e18f4bec404a11351cd43f5c14fa48';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp
    
    ErrorgraphElement[] elements
    
    ================================================================================
    MSG: mrs_errorgraph/ErrorgraphElement
    time stamp
    
    mrs_errorgraph/ErrorgraphNodeID source_node
    
    mrs_errorgraph/ErrorgraphError[] errors
    
    ================================================================================
    MSG: mrs_errorgraph/ErrorgraphNodeID
    # unique identifier of a node that can be a source of an error
    string node
    # optional identifier of a component within the node
    string component
    
    ================================================================================
    MSG: mrs_errorgraph/ErrorgraphError
    time stamp
    
    string type
    
    string waited_for_topic
    mrs_errorgraph/ErrorgraphNodeID waited_for_node
    
    string TYPE_WAITING_FOR_TOPIC = waiting_for_topic
    string TYPE_WAITING_FOR_NODE = waiting_for_node
    string TYPE_NOT_REPORTING = not_reporting
    string TYPE_NO_ERROR = no_error
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ErrorgraphElementArray(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.elements !== undefined) {
      resolved.elements = new Array(msg.elements.length);
      for (let i = 0; i < resolved.elements.length; ++i) {
        resolved.elements[i] = ErrorgraphElement.Resolve(msg.elements[i]);
      }
    }
    else {
      resolved.elements = []
    }

    return resolved;
    }
};

module.exports = ErrorgraphElementArray;
