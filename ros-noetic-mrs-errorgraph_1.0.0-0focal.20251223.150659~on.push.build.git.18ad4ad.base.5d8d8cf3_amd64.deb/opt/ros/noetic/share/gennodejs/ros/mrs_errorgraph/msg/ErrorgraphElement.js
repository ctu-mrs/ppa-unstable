// Auto-generated. Do not edit!

// (in-package mrs_errorgraph.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ErrorgraphNodeID = require('./ErrorgraphNodeID.js');
let ErrorgraphError = require('./ErrorgraphError.js');

//-----------------------------------------------------------

class ErrorgraphElement {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.source_node = null;
      this.errors = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('source_node')) {
        this.source_node = initObj.source_node
      }
      else {
        this.source_node = new ErrorgraphNodeID();
      }
      if (initObj.hasOwnProperty('errors')) {
        this.errors = initObj.errors
      }
      else {
        this.errors = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ErrorgraphElement
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [source_node]
    bufferOffset = ErrorgraphNodeID.serialize(obj.source_node, buffer, bufferOffset);
    // Serialize message field [errors]
    // Serialize the length for message field [errors]
    bufferOffset = _serializer.uint32(obj.errors.length, buffer, bufferOffset);
    obj.errors.forEach((val) => {
      bufferOffset = ErrorgraphError.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ErrorgraphElement
    let len;
    let data = new ErrorgraphElement(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [source_node]
    data.source_node = ErrorgraphNodeID.deserialize(buffer, bufferOffset);
    // Deserialize message field [errors]
    // Deserialize array length for message field [errors]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.errors = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.errors[i] = ErrorgraphError.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += ErrorgraphNodeID.getMessageSize(object.source_node);
    object.errors.forEach((val) => {
      length += ErrorgraphError.getMessageSize(val);
    });
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_errorgraph/ErrorgraphElement';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'df6fc48e0950c218435f0fb10ac5c3df';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp
    
    mrs_errorgraph/ErrorgraphNodeID source_node
    
    mrs_errorgraph/ErrorgraphError[] errors
    
    ================================================================================
    MSG: mrs_errorgraph/ErrorgraphNodeID
    # unique identifier of a node that can be a source of an error
    string node
    # optional identifier of a component within the node
    string component
    
    ================================================================================
    MSG: mrs_errorgraph/ErrorgraphError
    time stamp
    
    string type
    
    string waited_for_topic
    mrs_errorgraph/ErrorgraphNodeID waited_for_node
    
    string TYPE_WAITING_FOR_TOPIC = waiting_for_topic
    string TYPE_WAITING_FOR_NODE = waiting_for_node
    string TYPE_NOT_REPORTING = not_reporting
    string TYPE_NO_ERROR = no_error
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ErrorgraphElement(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.source_node !== undefined) {
      resolved.source_node = ErrorgraphNodeID.Resolve(msg.source_node)
    }
    else {
      resolved.source_node = new ErrorgraphNodeID()
    }

    if (msg.errors !== undefined) {
      resolved.errors = new Array(msg.errors.length);
      for (let i = 0; i < resolved.errors.length; ++i) {
        resolved.errors[i] = ErrorgraphError.Resolve(msg.errors[i]);
      }
    }
    else {
      resolved.errors = []
    }

    return resolved;
    }
};

module.exports = ErrorgraphElement;
