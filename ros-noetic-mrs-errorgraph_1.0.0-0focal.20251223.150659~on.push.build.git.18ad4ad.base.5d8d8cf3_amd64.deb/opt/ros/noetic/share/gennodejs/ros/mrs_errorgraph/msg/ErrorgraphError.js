// Auto-generated. Do not edit!

// (in-package mrs_errorgraph.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ErrorgraphNodeID = require('./ErrorgraphNodeID.js');

//-----------------------------------------------------------

class ErrorgraphError {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.type = null;
      this.waited_for_topic = null;
      this.waited_for_node = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = '';
      }
      if (initObj.hasOwnProperty('waited_for_topic')) {
        this.waited_for_topic = initObj.waited_for_topic
      }
      else {
        this.waited_for_topic = '';
      }
      if (initObj.hasOwnProperty('waited_for_node')) {
        this.waited_for_node = initObj.waited_for_node
      }
      else {
        this.waited_for_node = new ErrorgraphNodeID();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ErrorgraphError
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.string(obj.type, buffer, bufferOffset);
    // Serialize message field [waited_for_topic]
    bufferOffset = _serializer.string(obj.waited_for_topic, buffer, bufferOffset);
    // Serialize message field [waited_for_node]
    bufferOffset = ErrorgraphNodeID.serialize(obj.waited_for_node, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ErrorgraphError
    let len;
    let data = new ErrorgraphError(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [waited_for_topic]
    data.waited_for_topic = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [waited_for_node]
    data.waited_for_node = ErrorgraphNodeID.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.type);
    length += _getByteLength(object.waited_for_topic);
    length += ErrorgraphNodeID.getMessageSize(object.waited_for_node);
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_errorgraph/ErrorgraphError';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c8a5347848a549ac92fbe848ea183835';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time stamp
    
    string type
    
    string waited_for_topic
    mrs_errorgraph/ErrorgraphNodeID waited_for_node
    
    string TYPE_WAITING_FOR_TOPIC = waiting_for_topic
    string TYPE_WAITING_FOR_NODE = waiting_for_node
    string TYPE_NOT_REPORTING = not_reporting
    string TYPE_NO_ERROR = no_error
    
    ================================================================================
    MSG: mrs_errorgraph/ErrorgraphNodeID
    # unique identifier of a node that can be a source of an error
    string node
    # optional identifier of a component within the node
    string component
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ErrorgraphError(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = ''
    }

    if (msg.waited_for_topic !== undefined) {
      resolved.waited_for_topic = msg.waited_for_topic;
    }
    else {
      resolved.waited_for_topic = ''
    }

    if (msg.waited_for_node !== undefined) {
      resolved.waited_for_node = ErrorgraphNodeID.Resolve(msg.waited_for_node)
    }
    else {
      resolved.waited_for_node = new ErrorgraphNodeID()
    }

    return resolved;
    }
};

// Constants for message
ErrorgraphError.Constants = {
  TYPE_WAITING_FOR_TOPIC: 'waiting_for_topic',
  TYPE_WAITING_FOR_NODE: 'waiting_for_node',
  TYPE_NOT_REPORTING: 'not_reporting',
  TYPE_NO_ERROR: 'no_error',
}

module.exports = ErrorgraphError;
