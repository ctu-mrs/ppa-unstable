// Auto-generated. Do not edit!

// (in-package vins_mono_vins_estimator.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Diagnostics {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.t_triangulate = null;
      this.t_solver_prepare = null;
      this.t_solver = null;
      this.t_marginalize = null;
      this.t_optimize_total = null;
      this.solver_iterations = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('t_triangulate')) {
        this.t_triangulate = initObj.t_triangulate
      }
      else {
        this.t_triangulate = 0.0;
      }
      if (initObj.hasOwnProperty('t_solver_prepare')) {
        this.t_solver_prepare = initObj.t_solver_prepare
      }
      else {
        this.t_solver_prepare = 0.0;
      }
      if (initObj.hasOwnProperty('t_solver')) {
        this.t_solver = initObj.t_solver
      }
      else {
        this.t_solver = 0.0;
      }
      if (initObj.hasOwnProperty('t_marginalize')) {
        this.t_marginalize = initObj.t_marginalize
      }
      else {
        this.t_marginalize = 0.0;
      }
      if (initObj.hasOwnProperty('t_optimize_total')) {
        this.t_optimize_total = initObj.t_optimize_total
      }
      else {
        this.t_optimize_total = 0.0;
      }
      if (initObj.hasOwnProperty('solver_iterations')) {
        this.solver_iterations = initObj.solver_iterations
      }
      else {
        this.solver_iterations = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Diagnostics
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [t_triangulate]
    bufferOffset = _serializer.float64(obj.t_triangulate, buffer, bufferOffset);
    // Serialize message field [t_solver_prepare]
    bufferOffset = _serializer.float64(obj.t_solver_prepare, buffer, bufferOffset);
    // Serialize message field [t_solver]
    bufferOffset = _serializer.float64(obj.t_solver, buffer, bufferOffset);
    // Serialize message field [t_marginalize]
    bufferOffset = _serializer.float64(obj.t_marginalize, buffer, bufferOffset);
    // Serialize message field [t_optimize_total]
    bufferOffset = _serializer.float64(obj.t_optimize_total, buffer, bufferOffset);
    // Serialize message field [solver_iterations]
    bufferOffset = _serializer.uint8(obj.solver_iterations, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Diagnostics
    let len;
    let data = new Diagnostics(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [t_triangulate]
    data.t_triangulate = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [t_solver_prepare]
    data.t_solver_prepare = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [t_solver]
    data.t_solver = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [t_marginalize]
    data.t_marginalize = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [t_optimize_total]
    data.t_optimize_total = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [solver_iterations]
    data.solver_iterations = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 41;
  }

  static datatype() {
    // Returns string type for a message object
    return 'vins_mono_vins_estimator/Diagnostics';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8df9aa2449ec5e7b97fec426fb37a982';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    
    float64 t_triangulate
    float64 t_solver_prepare
    float64 t_solver
    float64 t_marginalize
    float64 t_optimize_total
    
    uint8 solver_iterations
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Diagnostics(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.t_triangulate !== undefined) {
      resolved.t_triangulate = msg.t_triangulate;
    }
    else {
      resolved.t_triangulate = 0.0
    }

    if (msg.t_solver_prepare !== undefined) {
      resolved.t_solver_prepare = msg.t_solver_prepare;
    }
    else {
      resolved.t_solver_prepare = 0.0
    }

    if (msg.t_solver !== undefined) {
      resolved.t_solver = msg.t_solver;
    }
    else {
      resolved.t_solver = 0.0
    }

    if (msg.t_marginalize !== undefined) {
      resolved.t_marginalize = msg.t_marginalize;
    }
    else {
      resolved.t_marginalize = 0.0
    }

    if (msg.t_optimize_total !== undefined) {
      resolved.t_optimize_total = msg.t_optimize_total;
    }
    else {
      resolved.t_optimize_total = 0.0
    }

    if (msg.solver_iterations !== undefined) {
      resolved.solver_iterations = msg.solver_iterations;
    }
    else {
      resolved.solver_iterations = 0
    }

    return resolved;
    }
};

module.exports = Diagnostics;
