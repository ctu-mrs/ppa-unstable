
"use strict";

let Diagnostics = require('./Diagnostics.js');

module.exports = {
  Diagnostics: Diagnostics,
};
