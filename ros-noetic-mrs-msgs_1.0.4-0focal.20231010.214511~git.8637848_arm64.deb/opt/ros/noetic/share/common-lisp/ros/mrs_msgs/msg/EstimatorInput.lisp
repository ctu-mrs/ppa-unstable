; Auto-generated. Do not edit!


(cl:in-package mrs_msgs-msg)


;//! \htmlinclude EstimatorInput.msg.html

(cl:defclass <EstimatorInput> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (control_acceleration
    :reader control_acceleration
    :initarg :control_acceleration
    :type geometry_msgs-msg:Vector3
    :initform (cl:make-instance 'geometry_msgs-msg:Vector3))
   (control_hdg_rate
    :reader control_hdg_rate
    :initarg :control_hdg_rate
    :type cl:float
    :initform 0.0))
)

(cl:defclass EstimatorInput (<EstimatorInput>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <EstimatorInput>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'EstimatorInput)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_msgs-msg:<EstimatorInput> is deprecated: use mrs_msgs-msg:EstimatorInput instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <EstimatorInput>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:header-val is deprecated.  Use mrs_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'control_acceleration-val :lambda-list '(m))
(cl:defmethod control_acceleration-val ((m <EstimatorInput>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:control_acceleration-val is deprecated.  Use mrs_msgs-msg:control_acceleration instead.")
  (control_acceleration m))

(cl:ensure-generic-function 'control_hdg_rate-val :lambda-list '(m))
(cl:defmethod control_hdg_rate-val ((m <EstimatorInput>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-msg:control_hdg_rate-val is deprecated.  Use mrs_msgs-msg:control_hdg_rate instead.")
  (control_hdg_rate m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <EstimatorInput>) ostream)
  "Serializes a message object of type '<EstimatorInput>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'control_acceleration) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'control_hdg_rate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <EstimatorInput>) istream)
  "Deserializes a message object of type '<EstimatorInput>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'control_acceleration) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'control_hdg_rate) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<EstimatorInput>)))
  "Returns string type for a message object of type '<EstimatorInput>"
  "mrs_msgs/EstimatorInput")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'EstimatorInput)))
  "Returns string type for a message object of type 'EstimatorInput"
  "mrs_msgs/EstimatorInput")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<EstimatorInput>)))
  "Returns md5sum for a message object of type '<EstimatorInput>"
  "8756fee487290057802d05d69b4226ca")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'EstimatorInput)))
  "Returns md5sum for a message object of type 'EstimatorInput"
  "8756fee487290057802d05d69b4226ca")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<EstimatorInput>)))
  "Returns full string definition for message of type '<EstimatorInput>"
  (cl:format cl:nil "Header header~%~%# unbiased acceleration caused by controller's action~%geometry_msgs/Vector3 control_acceleration~%~%# heading rate caused by the controller's action~%float64 control_hdg_rate~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'EstimatorInput)))
  "Returns full string definition for message of type 'EstimatorInput"
  (cl:format cl:nil "Header header~%~%# unbiased acceleration caused by controller's action~%geometry_msgs/Vector3 control_acceleration~%~%# heading rate caused by the controller's action~%float64 control_hdg_rate~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <EstimatorInput>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'control_acceleration))
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <EstimatorInput>))
  "Converts a ROS message object to a list"
  (cl:list 'EstimatorInput
    (cl:cons ':header (header msg))
    (cl:cons ':control_acceleration (control_acceleration msg))
    (cl:cons ':control_hdg_rate (control_hdg_rate msg))
))
