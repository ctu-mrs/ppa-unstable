(cl:in-package mrs_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          GPS-VAL
          GPS
          STATUS-VAL
          STATUS
          FIX_TYPE-VAL
          FIX_TYPE
))