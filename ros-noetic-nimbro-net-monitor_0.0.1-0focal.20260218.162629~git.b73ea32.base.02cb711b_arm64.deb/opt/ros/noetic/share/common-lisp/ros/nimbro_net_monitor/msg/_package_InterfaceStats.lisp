(cl:in-package nimbro_net_monitor-msg)
(cl:export '(INTERFACE_NAME-VAL
          INTERFACE_NAME
          MAX_BITS_PER_SECOND-VAL
          MAX_BITS_PER_SECOND
          DUPLEX-VAL
          DUPLEX
          TX_BANDWIDTH-VAL
          TX_BANDWIDTH
          RX_BANDWIDTH-VAL
          RX_BANDWIDTH
          PEERS-VAL
          PEERS
))