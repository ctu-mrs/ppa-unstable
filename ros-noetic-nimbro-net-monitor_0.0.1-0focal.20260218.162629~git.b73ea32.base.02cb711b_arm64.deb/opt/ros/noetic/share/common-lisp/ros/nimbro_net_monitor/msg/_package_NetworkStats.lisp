(cl:in-package nimbro_net_monitor-msg)
(cl:export '(HEADER-VAL
          HEADER
          HOST-VAL
          HOST
          INTERFACES-VAL
          INTERFACES
))