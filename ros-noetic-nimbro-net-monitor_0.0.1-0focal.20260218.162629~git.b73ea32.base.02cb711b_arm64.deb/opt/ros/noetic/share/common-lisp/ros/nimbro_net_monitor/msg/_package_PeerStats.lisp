(cl:in-package nimbro_net_monitor-msg)
(cl:export '(HOST-VAL
          HOST
          NODES-VAL
          NODES
))