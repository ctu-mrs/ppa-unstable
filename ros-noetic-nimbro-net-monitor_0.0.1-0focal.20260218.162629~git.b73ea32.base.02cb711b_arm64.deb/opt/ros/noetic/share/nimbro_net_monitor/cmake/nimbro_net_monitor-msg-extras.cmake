set(nimbro_net_monitor_MESSAGE_FILES "msg/ConnectionStats.msg;msg/InterfaceStats.msg;msg/NetworkStats.msg;msg/NodeStats.msg;msg/PeerStats.msg")
set(nimbro_net_monitor_SERVICE_FILES "")
