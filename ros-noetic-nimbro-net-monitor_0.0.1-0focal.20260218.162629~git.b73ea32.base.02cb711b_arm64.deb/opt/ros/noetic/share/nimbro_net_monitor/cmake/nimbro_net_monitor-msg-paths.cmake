# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${nimbro_net_monitor_DIR}/.." "msg" nimbro_net_monitor_MSG_INCLUDE_DIRS UNIQUE)
set(nimbro_net_monitor_MSG_DEPENDENCIES std_msgs)
