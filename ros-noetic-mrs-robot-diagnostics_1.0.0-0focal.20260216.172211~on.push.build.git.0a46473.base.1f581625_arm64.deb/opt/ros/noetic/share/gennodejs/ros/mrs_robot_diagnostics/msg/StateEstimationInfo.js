// Auto-generated. Do not edit!

// (in-package mrs_robot_diagnostics.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let mrs_msgs = _finder('mrs_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class StateEstimationInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.local_pose = null;
      this.velocity = null;
      this.acceleration = null;
      this.above_ground_level_height = null;
      this.global_pose = null;
      this.current_estimator = null;
      this.running_estimators = null;
      this.switchable_estimators = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('local_pose')) {
        this.local_pose = initObj.local_pose
      }
      else {
        this.local_pose = new mrs_msgs.msg.Reference();
      }
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = new geometry_msgs.msg.Twist();
      }
      if (initObj.hasOwnProperty('acceleration')) {
        this.acceleration = initObj.acceleration
      }
      else {
        this.acceleration = new geometry_msgs.msg.Accel();
      }
      if (initObj.hasOwnProperty('above_ground_level_height')) {
        this.above_ground_level_height = initObj.above_ground_level_height
      }
      else {
        this.above_ground_level_height = 0.0;
      }
      if (initObj.hasOwnProperty('global_pose')) {
        this.global_pose = initObj.global_pose
      }
      else {
        this.global_pose = new mrs_msgs.msg.Reference();
      }
      if (initObj.hasOwnProperty('current_estimator')) {
        this.current_estimator = initObj.current_estimator
      }
      else {
        this.current_estimator = '';
      }
      if (initObj.hasOwnProperty('running_estimators')) {
        this.running_estimators = initObj.running_estimators
      }
      else {
        this.running_estimators = [];
      }
      if (initObj.hasOwnProperty('switchable_estimators')) {
        this.switchable_estimators = initObj.switchable_estimators
      }
      else {
        this.switchable_estimators = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StateEstimationInfo
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [local_pose]
    bufferOffset = mrs_msgs.msg.Reference.serialize(obj.local_pose, buffer, bufferOffset);
    // Serialize message field [velocity]
    bufferOffset = geometry_msgs.msg.Twist.serialize(obj.velocity, buffer, bufferOffset);
    // Serialize message field [acceleration]
    bufferOffset = geometry_msgs.msg.Accel.serialize(obj.acceleration, buffer, bufferOffset);
    // Serialize message field [above_ground_level_height]
    bufferOffset = _serializer.float64(obj.above_ground_level_height, buffer, bufferOffset);
    // Serialize message field [global_pose]
    bufferOffset = mrs_msgs.msg.Reference.serialize(obj.global_pose, buffer, bufferOffset);
    // Serialize message field [current_estimator]
    bufferOffset = _serializer.string(obj.current_estimator, buffer, bufferOffset);
    // Serialize message field [running_estimators]
    bufferOffset = _arraySerializer.string(obj.running_estimators, buffer, bufferOffset, null);
    // Serialize message field [switchable_estimators]
    bufferOffset = _arraySerializer.string(obj.switchable_estimators, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StateEstimationInfo
    let len;
    let data = new StateEstimationInfo(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [local_pose]
    data.local_pose = mrs_msgs.msg.Reference.deserialize(buffer, bufferOffset);
    // Deserialize message field [velocity]
    data.velocity = geometry_msgs.msg.Twist.deserialize(buffer, bufferOffset);
    // Deserialize message field [acceleration]
    data.acceleration = geometry_msgs.msg.Accel.deserialize(buffer, bufferOffset);
    // Deserialize message field [above_ground_level_height]
    data.above_ground_level_height = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [global_pose]
    data.global_pose = mrs_msgs.msg.Reference.deserialize(buffer, bufferOffset);
    // Deserialize message field [current_estimator]
    data.current_estimator = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [running_estimators]
    data.running_estimators = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [switchable_estimators]
    data.switchable_estimators = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.current_estimator);
    object.running_estimators.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.switchable_estimators.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 180;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_robot_diagnostics/StateEstimationInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3f13c4c14e406f049fa1dd18ef202392';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    # these are in the local frame (the one specified in the header_
    mrs_msgs/Reference local_pose
    geometry_msgs/Twist velocity
    geometry_msgs/Accel acceleration
    
    float64 above_ground_level_height
    
    # this is in the global coordinates (lat/lon/alt)
    mrs_msgs/Reference global_pose
    
    string current_estimator
    string[] running_estimators
    string[] switchable_estimators
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: mrs_msgs/Reference
    # This message defines a control reference with a Position+Heading.
    
    geometry_msgs/Point position
    
    # Heading is atan2() of XY-world projection of the UAV's body X-axis.
    float64 heading
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Twist
    # This expresses velocity in free space broken into its linear and angular parts.
    Vector3  linear
    Vector3  angular
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: geometry_msgs/Accel
    # This expresses acceleration in free space broken into its linear and angular parts.
    Vector3  linear
    Vector3  angular
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StateEstimationInfo(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.local_pose !== undefined) {
      resolved.local_pose = mrs_msgs.msg.Reference.Resolve(msg.local_pose)
    }
    else {
      resolved.local_pose = new mrs_msgs.msg.Reference()
    }

    if (msg.velocity !== undefined) {
      resolved.velocity = geometry_msgs.msg.Twist.Resolve(msg.velocity)
    }
    else {
      resolved.velocity = new geometry_msgs.msg.Twist()
    }

    if (msg.acceleration !== undefined) {
      resolved.acceleration = geometry_msgs.msg.Accel.Resolve(msg.acceleration)
    }
    else {
      resolved.acceleration = new geometry_msgs.msg.Accel()
    }

    if (msg.above_ground_level_height !== undefined) {
      resolved.above_ground_level_height = msg.above_ground_level_height;
    }
    else {
      resolved.above_ground_level_height = 0.0
    }

    if (msg.global_pose !== undefined) {
      resolved.global_pose = mrs_msgs.msg.Reference.Resolve(msg.global_pose)
    }
    else {
      resolved.global_pose = new mrs_msgs.msg.Reference()
    }

    if (msg.current_estimator !== undefined) {
      resolved.current_estimator = msg.current_estimator;
    }
    else {
      resolved.current_estimator = ''
    }

    if (msg.running_estimators !== undefined) {
      resolved.running_estimators = msg.running_estimators;
    }
    else {
      resolved.running_estimators = []
    }

    if (msg.switchable_estimators !== undefined) {
      resolved.switchable_estimators = msg.switchable_estimators;
    }
    else {
      resolved.switchable_estimators = []
    }

    return resolved;
    }
};

module.exports = StateEstimationInfo;
