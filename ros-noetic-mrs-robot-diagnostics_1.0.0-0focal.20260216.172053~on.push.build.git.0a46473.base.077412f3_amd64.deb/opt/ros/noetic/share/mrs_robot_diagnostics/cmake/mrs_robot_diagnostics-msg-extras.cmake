set(mrs_robot_diagnostics_MESSAGE_FILES "msg/BatteryState.msg;msg/SensorStatus.msg;msg/SensorInfo.msg;msg/NodeCpuLoad.msg;msg/GeneralRobotInfo.msg;msg/StateEstimationInfo.msg;msg/ControlInfo.msg;msg/CollisionAvoidanceInfo.msg;msg/UavInfo.msg;msg/SystemHealthInfo.msg;msg/UavState.msg")
set(mrs_robot_diagnostics_SERVICE_FILES "")
