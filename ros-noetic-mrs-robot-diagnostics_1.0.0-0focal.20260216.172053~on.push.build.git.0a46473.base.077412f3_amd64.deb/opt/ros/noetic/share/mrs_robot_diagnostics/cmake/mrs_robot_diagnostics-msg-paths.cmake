# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${mrs_robot_diagnostics_DIR}/.." "msg" mrs_robot_diagnostics_MSG_INCLUDE_DIRS UNIQUE)
set(mrs_robot_diagnostics_MSG_DEPENDENCIES std_msgs;geometry_msgs;sensor_msgs;mrs_msgs)
