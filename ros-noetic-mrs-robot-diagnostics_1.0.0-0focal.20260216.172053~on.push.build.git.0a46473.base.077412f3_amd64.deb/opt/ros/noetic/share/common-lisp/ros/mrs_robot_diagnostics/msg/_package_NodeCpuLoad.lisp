(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(NODE_NAME-VAL
          NODE_NAME
          CPU_LOAD-VAL
          CPU_LOAD
))