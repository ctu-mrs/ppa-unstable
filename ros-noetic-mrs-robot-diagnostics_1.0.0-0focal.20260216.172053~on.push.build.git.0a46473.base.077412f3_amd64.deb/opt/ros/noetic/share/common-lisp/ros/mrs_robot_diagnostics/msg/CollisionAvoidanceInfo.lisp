; Auto-generated. Do not edit!


(cl:in-package mrs_robot_diagnostics-msg)


;//! \htmlinclude CollisionAvoidanceInfo.msg.html

(cl:defclass <CollisionAvoidanceInfo> (roslisp-msg-protocol:ros-message)
  ((collision_avoidance_enabled
    :reader collision_avoidance_enabled
    :initarg :collision_avoidance_enabled
    :type cl:boolean
    :initform cl:nil)
   (avoiding_collision
    :reader avoiding_collision
    :initarg :avoiding_collision
    :type cl:boolean
    :initform cl:nil)
   (other_robots_visible
    :reader other_robots_visible
    :initarg :other_robots_visible
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element "")))
)

(cl:defclass CollisionAvoidanceInfo (<CollisionAvoidanceInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CollisionAvoidanceInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CollisionAvoidanceInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_robot_diagnostics-msg:<CollisionAvoidanceInfo> is deprecated: use mrs_robot_diagnostics-msg:CollisionAvoidanceInfo instead.")))

(cl:ensure-generic-function 'collision_avoidance_enabled-val :lambda-list '(m))
(cl:defmethod collision_avoidance_enabled-val ((m <CollisionAvoidanceInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:collision_avoidance_enabled-val is deprecated.  Use mrs_robot_diagnostics-msg:collision_avoidance_enabled instead.")
  (collision_avoidance_enabled m))

(cl:ensure-generic-function 'avoiding_collision-val :lambda-list '(m))
(cl:defmethod avoiding_collision-val ((m <CollisionAvoidanceInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:avoiding_collision-val is deprecated.  Use mrs_robot_diagnostics-msg:avoiding_collision instead.")
  (avoiding_collision m))

(cl:ensure-generic-function 'other_robots_visible-val :lambda-list '(m))
(cl:defmethod other_robots_visible-val ((m <CollisionAvoidanceInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:other_robots_visible-val is deprecated.  Use mrs_robot_diagnostics-msg:other_robots_visible instead.")
  (other_robots_visible m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CollisionAvoidanceInfo>) ostream)
  "Serializes a message object of type '<CollisionAvoidanceInfo>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'collision_avoidance_enabled) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'avoiding_collision) 1 0)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'other_robots_visible))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'other_robots_visible))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CollisionAvoidanceInfo>) istream)
  "Deserializes a message object of type '<CollisionAvoidanceInfo>"
    (cl:setf (cl:slot-value msg 'collision_avoidance_enabled) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'avoiding_collision) (cl:not (cl:zerop (cl:read-byte istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'other_robots_visible) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'other_robots_visible)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CollisionAvoidanceInfo>)))
  "Returns string type for a message object of type '<CollisionAvoidanceInfo>"
  "mrs_robot_diagnostics/CollisionAvoidanceInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CollisionAvoidanceInfo)))
  "Returns string type for a message object of type 'CollisionAvoidanceInfo"
  "mrs_robot_diagnostics/CollisionAvoidanceInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CollisionAvoidanceInfo>)))
  "Returns md5sum for a message object of type '<CollisionAvoidanceInfo>"
  "fb981268dbbb1fedcf378ca128941e66")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CollisionAvoidanceInfo)))
  "Returns md5sum for a message object of type 'CollisionAvoidanceInfo"
  "fb981268dbbb1fedcf378ca128941e66")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CollisionAvoidanceInfo>)))
  "Returns full string definition for message of type '<CollisionAvoidanceInfo>"
  (cl:format cl:nil "~%bool      collision_avoidance_enabled~%bool      avoiding_collision~%string[]  other_robots_visible~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CollisionAvoidanceInfo)))
  "Returns full string definition for message of type 'CollisionAvoidanceInfo"
  (cl:format cl:nil "~%bool      collision_avoidance_enabled~%bool      avoiding_collision~%string[]  other_robots_visible~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CollisionAvoidanceInfo>))
  (cl:+ 0
     1
     1
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'other_robots_visible) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CollisionAvoidanceInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'CollisionAvoidanceInfo
    (cl:cons ':collision_avoidance_enabled (collision_avoidance_enabled msg))
    (cl:cons ':avoiding_collision (avoiding_collision msg))
    (cl:cons ':other_robots_visible (other_robots_visible msg))
))
