; Auto-generated. Do not edit!


(cl:in-package mrs_robot_diagnostics-msg)


;//! \htmlinclude GeneralRobotInfo.msg.html

(cl:defclass <GeneralRobotInfo> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (robot_name
    :reader robot_name
    :initarg :robot_name
    :type cl:string
    :initform "")
   (robot_type
    :reader robot_type
    :initarg :robot_type
    :type cl:fixnum
    :initform 0)
   (robot_ip_address
    :reader robot_ip_address
    :initarg :robot_ip_address
    :type cl:string
    :initform "")
   (battery_state
    :reader battery_state
    :initarg :battery_state
    :type mrs_robot_diagnostics-msg:BatteryState
    :initform (cl:make-instance 'mrs_robot_diagnostics-msg:BatteryState))
   (ready_to_start
    :reader ready_to_start
    :initarg :ready_to_start
    :type cl:boolean
    :initform cl:nil)
   (problems_preventing_start
    :reader problems_preventing_start
    :initarg :problems_preventing_start
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (errors
    :reader errors
    :initarg :errors
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element "")))
)

(cl:defclass GeneralRobotInfo (<GeneralRobotInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <GeneralRobotInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'GeneralRobotInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_robot_diagnostics-msg:<GeneralRobotInfo> is deprecated: use mrs_robot_diagnostics-msg:GeneralRobotInfo instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <GeneralRobotInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:stamp-val is deprecated.  Use mrs_robot_diagnostics-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'robot_name-val :lambda-list '(m))
(cl:defmethod robot_name-val ((m <GeneralRobotInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:robot_name-val is deprecated.  Use mrs_robot_diagnostics-msg:robot_name instead.")
  (robot_name m))

(cl:ensure-generic-function 'robot_type-val :lambda-list '(m))
(cl:defmethod robot_type-val ((m <GeneralRobotInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:robot_type-val is deprecated.  Use mrs_robot_diagnostics-msg:robot_type instead.")
  (robot_type m))

(cl:ensure-generic-function 'robot_ip_address-val :lambda-list '(m))
(cl:defmethod robot_ip_address-val ((m <GeneralRobotInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:robot_ip_address-val is deprecated.  Use mrs_robot_diagnostics-msg:robot_ip_address instead.")
  (robot_ip_address m))

(cl:ensure-generic-function 'battery_state-val :lambda-list '(m))
(cl:defmethod battery_state-val ((m <GeneralRobotInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:battery_state-val is deprecated.  Use mrs_robot_diagnostics-msg:battery_state instead.")
  (battery_state m))

(cl:ensure-generic-function 'ready_to_start-val :lambda-list '(m))
(cl:defmethod ready_to_start-val ((m <GeneralRobotInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:ready_to_start-val is deprecated.  Use mrs_robot_diagnostics-msg:ready_to_start instead.")
  (ready_to_start m))

(cl:ensure-generic-function 'problems_preventing_start-val :lambda-list '(m))
(cl:defmethod problems_preventing_start-val ((m <GeneralRobotInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:problems_preventing_start-val is deprecated.  Use mrs_robot_diagnostics-msg:problems_preventing_start instead.")
  (problems_preventing_start m))

(cl:ensure-generic-function 'errors-val :lambda-list '(m))
(cl:defmethod errors-val ((m <GeneralRobotInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:errors-val is deprecated.  Use mrs_robot_diagnostics-msg:errors instead.")
  (errors m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <GeneralRobotInfo>) ostream)
  "Serializes a message object of type '<GeneralRobotInfo>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'robot_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'robot_name))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'robot_type)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'robot_ip_address))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'robot_ip_address))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'battery_state) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'ready_to_start) 1 0)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'problems_preventing_start))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'problems_preventing_start))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'errors))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'errors))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <GeneralRobotInfo>) istream)
  "Deserializes a message object of type '<GeneralRobotInfo>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'robot_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'robot_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'robot_type)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'robot_ip_address) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'robot_ip_address) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'battery_state) istream)
    (cl:setf (cl:slot-value msg 'ready_to_start) (cl:not (cl:zerop (cl:read-byte istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'problems_preventing_start) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'problems_preventing_start)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'errors) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'errors)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<GeneralRobotInfo>)))
  "Returns string type for a message object of type '<GeneralRobotInfo>"
  "mrs_robot_diagnostics/GeneralRobotInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'GeneralRobotInfo)))
  "Returns string type for a message object of type 'GeneralRobotInfo"
  "mrs_robot_diagnostics/GeneralRobotInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<GeneralRobotInfo>)))
  "Returns md5sum for a message object of type '<GeneralRobotInfo>"
  "8f8ad84ab9ed52ce1423ffee93d7554c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'GeneralRobotInfo)))
  "Returns md5sum for a message object of type 'GeneralRobotInfo"
  "8f8ad84ab9ed52ce1423ffee93d7554c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<GeneralRobotInfo>)))
  "Returns full string definition for message of type '<GeneralRobotInfo>"
  (cl:format cl:nil "~%time stamp~%string robot_name~%uint8  robot_type~%string robot_ip_address~%~%mrs_robot_diagnostics/BatteryState battery_state~%~%bool ready_to_start~%string[] problems_preventing_start~%string[] errors~%~%================================================================================~%MSG: mrs_robot_diagnostics/BatteryState~%float64 voltage~%float64 percentage~%float64 wh_drained~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'GeneralRobotInfo)))
  "Returns full string definition for message of type 'GeneralRobotInfo"
  (cl:format cl:nil "~%time stamp~%string robot_name~%uint8  robot_type~%string robot_ip_address~%~%mrs_robot_diagnostics/BatteryState battery_state~%~%bool ready_to_start~%string[] problems_preventing_start~%string[] errors~%~%================================================================================~%MSG: mrs_robot_diagnostics/BatteryState~%float64 voltage~%float64 percentage~%float64 wh_drained~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <GeneralRobotInfo>))
  (cl:+ 0
     8
     4 (cl:length (cl:slot-value msg 'robot_name))
     1
     4 (cl:length (cl:slot-value msg 'robot_ip_address))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'battery_state))
     1
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'problems_preventing_start) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'errors) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <GeneralRobotInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'GeneralRobotInfo
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':robot_name (robot_name msg))
    (cl:cons ':robot_type (robot_type msg))
    (cl:cons ':robot_ip_address (robot_ip_address msg))
    (cl:cons ':battery_state (battery_state msg))
    (cl:cons ':ready_to_start (ready_to_start msg))
    (cl:cons ':problems_preventing_start (problems_preventing_start msg))
    (cl:cons ':errors (errors msg))
))
