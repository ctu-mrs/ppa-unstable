; Auto-generated. Do not edit!


(cl:in-package mrs_robot_diagnostics-msg)


;//! \htmlinclude SensorInfo.msg.html

(cl:defclass <SensorInfo> (roslisp-msg-protocol:ros-message)
  ((type
    :reader type
    :initarg :type
    :type cl:fixnum
    :initform 0)
   (details
    :reader details
    :initarg :details
    :type cl:string
    :initform ""))
)

(cl:defclass SensorInfo (<SensorInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SensorInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SensorInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_robot_diagnostics-msg:<SensorInfo> is deprecated: use mrs_robot_diagnostics-msg:SensorInfo instead.")))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <SensorInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:type-val is deprecated.  Use mrs_robot_diagnostics-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'details-val :lambda-list '(m))
(cl:defmethod details-val ((m <SensorInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:details-val is deprecated.  Use mrs_robot_diagnostics-msg:details instead.")
  (details m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SensorInfo>) ostream)
  "Serializes a message object of type '<SensorInfo>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'details))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'details))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SensorInfo>) istream)
  "Deserializes a message object of type '<SensorInfo>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'details) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'details) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SensorInfo>)))
  "Returns string type for a message object of type '<SensorInfo>"
  "mrs_robot_diagnostics/SensorInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SensorInfo)))
  "Returns string type for a message object of type 'SensorInfo"
  "mrs_robot_diagnostics/SensorInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SensorInfo>)))
  "Returns md5sum for a message object of type '<SensorInfo>"
  "06602f1fca09c63c0587fc3e5006d5d0")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SensorInfo)))
  "Returns md5sum for a message object of type 'SensorInfo"
  "06602f1fca09c63c0587fc3e5006d5d0")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SensorInfo>)))
  "Returns full string definition for message of type '<SensorInfo>"
  (cl:format cl:nil "uint8 type~%string details~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SensorInfo)))
  "Returns full string definition for message of type 'SensorInfo"
  (cl:format cl:nil "uint8 type~%string details~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SensorInfo>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'details))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SensorInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'SensorInfo
    (cl:cons ':type (type msg))
    (cl:cons ':details (details msg))
))
