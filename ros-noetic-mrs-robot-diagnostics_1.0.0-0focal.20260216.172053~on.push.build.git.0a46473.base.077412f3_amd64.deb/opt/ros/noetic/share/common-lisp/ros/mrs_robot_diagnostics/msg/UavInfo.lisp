; Auto-generated. Do not edit!


(cl:in-package mrs_robot_diagnostics-msg)


;//! \htmlinclude UavInfo.msg.html

(cl:defclass <UavInfo> (roslisp-msg-protocol:ros-message)
  ((flight_state
    :reader flight_state
    :initarg :flight_state
    :type cl:string
    :initform "")
   (flight_duration
    :reader flight_duration
    :initarg :flight_duration
    :type cl:float
    :initform 0.0)
   (armed
    :reader armed
    :initarg :armed
    :type cl:boolean
    :initform cl:nil)
   (offboard
    :reader offboard
    :initarg :offboard
    :type cl:boolean
    :initform cl:nil)
   (mass_nominal
    :reader mass_nominal
    :initarg :mass_nominal
    :type cl:float
    :initform 0.0)
   (mass_estimate
    :reader mass_estimate
    :initarg :mass_estimate
    :type cl:float
    :initform 0.0))
)

(cl:defclass UavInfo (<UavInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <UavInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'UavInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_robot_diagnostics-msg:<UavInfo> is deprecated: use mrs_robot_diagnostics-msg:UavInfo instead.")))

(cl:ensure-generic-function 'flight_state-val :lambda-list '(m))
(cl:defmethod flight_state-val ((m <UavInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:flight_state-val is deprecated.  Use mrs_robot_diagnostics-msg:flight_state instead.")
  (flight_state m))

(cl:ensure-generic-function 'flight_duration-val :lambda-list '(m))
(cl:defmethod flight_duration-val ((m <UavInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:flight_duration-val is deprecated.  Use mrs_robot_diagnostics-msg:flight_duration instead.")
  (flight_duration m))

(cl:ensure-generic-function 'armed-val :lambda-list '(m))
(cl:defmethod armed-val ((m <UavInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:armed-val is deprecated.  Use mrs_robot_diagnostics-msg:armed instead.")
  (armed m))

(cl:ensure-generic-function 'offboard-val :lambda-list '(m))
(cl:defmethod offboard-val ((m <UavInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:offboard-val is deprecated.  Use mrs_robot_diagnostics-msg:offboard instead.")
  (offboard m))

(cl:ensure-generic-function 'mass_nominal-val :lambda-list '(m))
(cl:defmethod mass_nominal-val ((m <UavInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:mass_nominal-val is deprecated.  Use mrs_robot_diagnostics-msg:mass_nominal instead.")
  (mass_nominal m))

(cl:ensure-generic-function 'mass_estimate-val :lambda-list '(m))
(cl:defmethod mass_estimate-val ((m <UavInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:mass_estimate-val is deprecated.  Use mrs_robot_diagnostics-msg:mass_estimate instead.")
  (mass_estimate m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <UavInfo>) ostream)
  "Serializes a message object of type '<UavInfo>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'flight_state))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'flight_state))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'flight_duration))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'armed) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'offboard) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'mass_nominal))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'mass_estimate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <UavInfo>) istream)
  "Deserializes a message object of type '<UavInfo>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'flight_state) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'flight_state) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'flight_duration) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:slot-value msg 'armed) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'offboard) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'mass_nominal) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'mass_estimate) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<UavInfo>)))
  "Returns string type for a message object of type '<UavInfo>"
  "mrs_robot_diagnostics/UavInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'UavInfo)))
  "Returns string type for a message object of type 'UavInfo"
  "mrs_robot_diagnostics/UavInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<UavInfo>)))
  "Returns md5sum for a message object of type '<UavInfo>"
  "2507a055113367f459cd6f611b464a8d")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'UavInfo)))
  "Returns md5sum for a message object of type 'UavInfo"
  "2507a055113367f459cd6f611b464a8d")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<UavInfo>)))
  "Returns full string definition for message of type '<UavInfo>"
  (cl:format cl:nil "~%string flight_state~%float64 flight_duration # seconds~%bool armed~%bool offboard~%float64 mass_nominal # kilograms~%float64 mass_estimate # kilograms~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'UavInfo)))
  "Returns full string definition for message of type 'UavInfo"
  (cl:format cl:nil "~%string flight_state~%float64 flight_duration # seconds~%bool armed~%bool offboard~%float64 mass_nominal # kilograms~%float64 mass_estimate # kilograms~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <UavInfo>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'flight_state))
     8
     1
     1
     8
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <UavInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'UavInfo
    (cl:cons ':flight_state (flight_state msg))
    (cl:cons ':flight_duration (flight_duration msg))
    (cl:cons ':armed (armed msg))
    (cl:cons ':offboard (offboard msg))
    (cl:cons ':mass_nominal (mass_nominal msg))
    (cl:cons ':mass_estimate (mass_estimate msg))
))
