(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(STAMP-VAL
          STAMP
          STATE-VAL
          STATE
))