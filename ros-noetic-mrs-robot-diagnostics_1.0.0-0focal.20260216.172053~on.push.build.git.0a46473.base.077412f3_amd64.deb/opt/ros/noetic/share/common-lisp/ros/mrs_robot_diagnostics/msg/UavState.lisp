; Auto-generated. Do not edit!


(cl:in-package mrs_robot_diagnostics-msg)


;//! \htmlinclude UavState.msg.html

(cl:defclass <UavState> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (state
    :reader state
    :initarg :state
    :type cl:fixnum
    :initform 0))
)

(cl:defclass UavState (<UavState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <UavState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'UavState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_robot_diagnostics-msg:<UavState> is deprecated: use mrs_robot_diagnostics-msg:UavState instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <UavState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:stamp-val is deprecated.  Use mrs_robot_diagnostics-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'state-val :lambda-list '(m))
(cl:defmethod state-val ((m <UavState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:state-val is deprecated.  Use mrs_robot_diagnostics-msg:state instead.")
  (state m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<UavState>)))
    "Constants for message type '<UavState>"
  '((:STATE_UNKNOWN . 0)
    (:STATE_DISARMED . 1)
    (:STATE_ARMED . 2)
    (:STATE_OFFBOARD . 3)
    (:STATE_MANUAL . 4)
    (:STATE_TAKEOFF . 5)
    (:STATE_LAND . 6)
    (:STATE_RC_MODE . 7)
    (:STATE_HOVER . 8)
    (:STATE_GOTO . 9)
    (:STATE_TRAJECTORY . 10))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'UavState)))
    "Constants for message type 'UavState"
  '((:STATE_UNKNOWN . 0)
    (:STATE_DISARMED . 1)
    (:STATE_ARMED . 2)
    (:STATE_OFFBOARD . 3)
    (:STATE_MANUAL . 4)
    (:STATE_TAKEOFF . 5)
    (:STATE_LAND . 6)
    (:STATE_RC_MODE . 7)
    (:STATE_HOVER . 8)
    (:STATE_GOTO . 9)
    (:STATE_TRAJECTORY . 10))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <UavState>) ostream)
  "Serializes a message object of type '<UavState>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'state)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <UavState>) istream)
  "Deserializes a message object of type '<UavState>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'state)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<UavState>)))
  "Returns string type for a message object of type '<UavState>"
  "mrs_robot_diagnostics/UavState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'UavState)))
  "Returns string type for a message object of type 'UavState"
  "mrs_robot_diagnostics/UavState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<UavState>)))
  "Returns md5sum for a message object of type '<UavState>"
  "0c44ef3c15c14afc9968017d438f8b59")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'UavState)))
  "Returns md5sum for a message object of type 'UavState"
  "0c44ef3c15c14afc9968017d438f8b59")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<UavState>)))
  "Returns full string definition for message of type '<UavState>"
  (cl:format cl:nil "time  stamp~%~%uint8 state~%~%uint8 STATE_UNKNOWN     = 0~%uint8 STATE_DISARMED    = 1~%uint8 STATE_ARMED       = 2~%uint8 STATE_OFFBOARD    = 3~%uint8 STATE_MANUAL      = 4~%uint8 STATE_TAKEOFF     = 5~%uint8 STATE_LAND        = 6~%uint8 STATE_RC_MODE     = 7~%uint8 STATE_HOVER       = 8~%uint8 STATE_GOTO        = 9~%uint8 STATE_TRAJECTORY  = 10~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'UavState)))
  "Returns full string definition for message of type 'UavState"
  (cl:format cl:nil "time  stamp~%~%uint8 state~%~%uint8 STATE_UNKNOWN     = 0~%uint8 STATE_DISARMED    = 1~%uint8 STATE_ARMED       = 2~%uint8 STATE_OFFBOARD    = 3~%uint8 STATE_MANUAL      = 4~%uint8 STATE_TAKEOFF     = 5~%uint8 STATE_LAND        = 6~%uint8 STATE_RC_MODE     = 7~%uint8 STATE_HOVER       = 8~%uint8 STATE_GOTO        = 9~%uint8 STATE_TRAJECTORY  = 10~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <UavState>))
  (cl:+ 0
     8
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <UavState>))
  "Converts a ROS message object to a list"
  (cl:list 'UavState
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':state (state msg))
))
