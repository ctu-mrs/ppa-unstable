; Auto-generated. Do not edit!


(cl:in-package mrs_robot_diagnostics-msg)


;//! \htmlinclude NodeCpuLoad.msg.html

(cl:defclass <NodeCpuLoad> (roslisp-msg-protocol:ros-message)
  ((node_name
    :reader node_name
    :initarg :node_name
    :type cl:string
    :initform "")
   (cpu_load
    :reader cpu_load
    :initarg :cpu_load
    :type cl:float
    :initform 0.0))
)

(cl:defclass NodeCpuLoad (<NodeCpuLoad>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <NodeCpuLoad>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'NodeCpuLoad)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_robot_diagnostics-msg:<NodeCpuLoad> is deprecated: use mrs_robot_diagnostics-msg:NodeCpuLoad instead.")))

(cl:ensure-generic-function 'node_name-val :lambda-list '(m))
(cl:defmethod node_name-val ((m <NodeCpuLoad>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:node_name-val is deprecated.  Use mrs_robot_diagnostics-msg:node_name instead.")
  (node_name m))

(cl:ensure-generic-function 'cpu_load-val :lambda-list '(m))
(cl:defmethod cpu_load-val ((m <NodeCpuLoad>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:cpu_load-val is deprecated.  Use mrs_robot_diagnostics-msg:cpu_load instead.")
  (cpu_load m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <NodeCpuLoad>) ostream)
  "Serializes a message object of type '<NodeCpuLoad>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'node_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'node_name))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cpu_load))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <NodeCpuLoad>) istream)
  "Deserializes a message object of type '<NodeCpuLoad>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'node_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'node_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cpu_load) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<NodeCpuLoad>)))
  "Returns string type for a message object of type '<NodeCpuLoad>"
  "mrs_robot_diagnostics/NodeCpuLoad")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'NodeCpuLoad)))
  "Returns string type for a message object of type 'NodeCpuLoad"
  "mrs_robot_diagnostics/NodeCpuLoad")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<NodeCpuLoad>)))
  "Returns md5sum for a message object of type '<NodeCpuLoad>"
  "aa8137032e8ab92ae21a2e0bd0572131")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'NodeCpuLoad)))
  "Returns md5sum for a message object of type 'NodeCpuLoad"
  "aa8137032e8ab92ae21a2e0bd0572131")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<NodeCpuLoad>)))
  "Returns full string definition for message of type '<NodeCpuLoad>"
  (cl:format cl:nil "string  node_name~%float32 cpu_load~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'NodeCpuLoad)))
  "Returns full string definition for message of type 'NodeCpuLoad"
  (cl:format cl:nil "string  node_name~%float32 cpu_load~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <NodeCpuLoad>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'node_name))
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <NodeCpuLoad>))
  "Converts a ROS message object to a list"
  (cl:list 'NodeCpuLoad
    (cl:cons ':node_name (node_name msg))
    (cl:cons ':cpu_load (cpu_load msg))
))
