(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(STAMP-VAL
          STAMP
          ROBOT_NAME-VAL
          ROBOT_NAME
          ROBOT_TYPE-VAL
          ROBOT_TYPE
          ROBOT_IP_ADDRESS-VAL
          ROBOT_IP_ADDRESS
          BATTERY_STATE-VAL
          BATTERY_STATE
          READY_TO_START-VAL
          READY_TO_START
          PROBLEMS_PREVENTING_START-VAL
          PROBLEMS_PREVENTING_START
          ERRORS-VAL
          ERRORS
))