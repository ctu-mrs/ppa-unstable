(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(HEADER-VAL
          HEADER
          LOCAL_POSE-VAL
          LOCAL_POSE
          VELOCITY-VAL
          VELOCITY
          ACCELERATION-VAL
          ACCELERATION
          ABOVE_GROUND_LEVEL_HEIGHT-VAL
          ABOVE_GROUND_LEVEL_HEIGHT
          GLOBAL_POSE-VAL
          GLOBAL_POSE
          CURRENT_ESTIMATOR-VAL
          CURRENT_ESTIMATOR
          RUNNING_ESTIMATORS-VAL
          RUNNING_ESTIMATORS
          SWITCHABLE_ESTIMATORS-VAL
          SWITCHABLE_ESTIMATORS
))