(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(CPU_LOAD-VAL
          CPU_LOAD
          FREE_RAM-VAL
          FREE_RAM
          TOTAL_RAM-VAL
          TOTAL_RAM
          FREE_HDD-VAL
          FREE_HDD
          NODE_CPU_LOADS-VAL
          NODE_CPU_LOADS
          HW_API_RATE-VAL
          HW_API_RATE
          CONTROL_MANAGER_RATE-VAL
          CONTROL_MANAGER_RATE
          STATE_ESTIMATION_RATE-VAL
          STATE_ESTIMATION_RATE
          GNSS_UNCERTAINTY-VAL
          GNSS_UNCERTAINTY
          MAG_STRENGTH-VAL
          MAG_STRENGTH
          MAG_UNCERTAINTY-VAL
          MAG_UNCERTAINTY
          AVAILABLE_SENSORS-VAL
          AVAILABLE_SENSORS
))