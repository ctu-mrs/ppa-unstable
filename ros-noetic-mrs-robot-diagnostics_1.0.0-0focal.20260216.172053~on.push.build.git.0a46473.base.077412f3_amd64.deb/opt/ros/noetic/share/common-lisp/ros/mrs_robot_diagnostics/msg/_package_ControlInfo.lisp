(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(ACTIVE_CONTROLLER-VAL
          ACTIVE_CONTROLLER
          AVAILABLE_CONTROLLERS-VAL
          AVAILABLE_CONTROLLERS
          ACTIVE_TRACKER-VAL
          ACTIVE_TRACKER
          AVAILABLE_TRACKERS-VAL
          AVAILABLE_TRACKERS
          THRUST-VAL
          THRUST
))