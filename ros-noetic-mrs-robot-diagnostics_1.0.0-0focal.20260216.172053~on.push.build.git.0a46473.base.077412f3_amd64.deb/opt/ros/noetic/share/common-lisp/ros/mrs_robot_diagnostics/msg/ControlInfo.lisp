; Auto-generated. Do not edit!


(cl:in-package mrs_robot_diagnostics-msg)


;//! \htmlinclude ControlInfo.msg.html

(cl:defclass <ControlInfo> (roslisp-msg-protocol:ros-message)
  ((active_controller
    :reader active_controller
    :initarg :active_controller
    :type cl:string
    :initform "")
   (available_controllers
    :reader available_controllers
    :initarg :available_controllers
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (active_tracker
    :reader active_tracker
    :initarg :active_tracker
    :type cl:string
    :initform "")
   (available_trackers
    :reader available_trackers
    :initarg :available_trackers
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (thrust
    :reader thrust
    :initarg :thrust
    :type cl:float
    :initform 0.0))
)

(cl:defclass ControlInfo (<ControlInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ControlInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ControlInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_robot_diagnostics-msg:<ControlInfo> is deprecated: use mrs_robot_diagnostics-msg:ControlInfo instead.")))

(cl:ensure-generic-function 'active_controller-val :lambda-list '(m))
(cl:defmethod active_controller-val ((m <ControlInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:active_controller-val is deprecated.  Use mrs_robot_diagnostics-msg:active_controller instead.")
  (active_controller m))

(cl:ensure-generic-function 'available_controllers-val :lambda-list '(m))
(cl:defmethod available_controllers-val ((m <ControlInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:available_controllers-val is deprecated.  Use mrs_robot_diagnostics-msg:available_controllers instead.")
  (available_controllers m))

(cl:ensure-generic-function 'active_tracker-val :lambda-list '(m))
(cl:defmethod active_tracker-val ((m <ControlInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:active_tracker-val is deprecated.  Use mrs_robot_diagnostics-msg:active_tracker instead.")
  (active_tracker m))

(cl:ensure-generic-function 'available_trackers-val :lambda-list '(m))
(cl:defmethod available_trackers-val ((m <ControlInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:available_trackers-val is deprecated.  Use mrs_robot_diagnostics-msg:available_trackers instead.")
  (available_trackers m))

(cl:ensure-generic-function 'thrust-val :lambda-list '(m))
(cl:defmethod thrust-val ((m <ControlInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:thrust-val is deprecated.  Use mrs_robot_diagnostics-msg:thrust instead.")
  (thrust m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ControlInfo>) ostream)
  "Serializes a message object of type '<ControlInfo>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'active_controller))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'active_controller))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'available_controllers))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'available_controllers))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'active_tracker))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'active_tracker))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'available_trackers))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'available_trackers))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'thrust))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ControlInfo>) istream)
  "Deserializes a message object of type '<ControlInfo>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'active_controller) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'active_controller) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'available_controllers) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'available_controllers)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'active_tracker) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'active_tracker) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'available_trackers) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'available_trackers)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'thrust) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ControlInfo>)))
  "Returns string type for a message object of type '<ControlInfo>"
  "mrs_robot_diagnostics/ControlInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ControlInfo)))
  "Returns string type for a message object of type 'ControlInfo"
  "mrs_robot_diagnostics/ControlInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ControlInfo>)))
  "Returns md5sum for a message object of type '<ControlInfo>"
  "60f44d6d23f58b43adf06836b19dd68a")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ControlInfo)))
  "Returns md5sum for a message object of type 'ControlInfo"
  "60f44d6d23f58b43adf06836b19dd68a")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ControlInfo>)))
  "Returns full string definition for message of type '<ControlInfo>"
  (cl:format cl:nil "string    active_controller~%string[]  available_controllers~%~%string    active_tracker~%string[]  available_trackers~%~%float32   thrust    # [%]~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ControlInfo)))
  "Returns full string definition for message of type 'ControlInfo"
  (cl:format cl:nil "string    active_controller~%string[]  available_controllers~%~%string    active_tracker~%string[]  available_trackers~%~%float32   thrust    # [%]~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ControlInfo>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'active_controller))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'available_controllers) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:length (cl:slot-value msg 'active_tracker))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'available_trackers) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ControlInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'ControlInfo
    (cl:cons ':active_controller (active_controller msg))
    (cl:cons ':available_controllers (available_controllers msg))
    (cl:cons ':active_tracker (active_tracker msg))
    (cl:cons ':available_trackers (available_trackers msg))
    (cl:cons ':thrust (thrust msg))
))
