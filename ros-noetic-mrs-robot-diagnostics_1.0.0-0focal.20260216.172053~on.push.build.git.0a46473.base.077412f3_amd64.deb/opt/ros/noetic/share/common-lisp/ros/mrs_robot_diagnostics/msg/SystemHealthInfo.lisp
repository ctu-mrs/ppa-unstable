; Auto-generated. Do not edit!


(cl:in-package mrs_robot_diagnostics-msg)


;//! \htmlinclude SystemHealthInfo.msg.html

(cl:defclass <SystemHealthInfo> (roslisp-msg-protocol:ros-message)
  ((cpu_load
    :reader cpu_load
    :initarg :cpu_load
    :type cl:float
    :initform 0.0)
   (free_ram
    :reader free_ram
    :initarg :free_ram
    :type cl:float
    :initform 0.0)
   (total_ram
    :reader total_ram
    :initarg :total_ram
    :type cl:float
    :initform 0.0)
   (free_hdd
    :reader free_hdd
    :initarg :free_hdd
    :type cl:integer
    :initform 0)
   (node_cpu_loads
    :reader node_cpu_loads
    :initarg :node_cpu_loads
    :type (cl:vector mrs_robot_diagnostics-msg:NodeCpuLoad)
   :initform (cl:make-array 0 :element-type 'mrs_robot_diagnostics-msg:NodeCpuLoad :initial-element (cl:make-instance 'mrs_robot_diagnostics-msg:NodeCpuLoad)))
   (hw_api_rate
    :reader hw_api_rate
    :initarg :hw_api_rate
    :type cl:float
    :initform 0.0)
   (control_manager_rate
    :reader control_manager_rate
    :initarg :control_manager_rate
    :type cl:float
    :initform 0.0)
   (state_estimation_rate
    :reader state_estimation_rate
    :initarg :state_estimation_rate
    :type cl:float
    :initform 0.0)
   (gnss_uncertainty
    :reader gnss_uncertainty
    :initarg :gnss_uncertainty
    :type cl:float
    :initform 0.0)
   (mag_strength
    :reader mag_strength
    :initarg :mag_strength
    :type cl:float
    :initform 0.0)
   (mag_uncertainty
    :reader mag_uncertainty
    :initarg :mag_uncertainty
    :type cl:float
    :initform 0.0)
   (available_sensors
    :reader available_sensors
    :initarg :available_sensors
    :type (cl:vector mrs_robot_diagnostics-msg:SensorStatus)
   :initform (cl:make-array 0 :element-type 'mrs_robot_diagnostics-msg:SensorStatus :initial-element (cl:make-instance 'mrs_robot_diagnostics-msg:SensorStatus))))
)

(cl:defclass SystemHealthInfo (<SystemHealthInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SystemHealthInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SystemHealthInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_robot_diagnostics-msg:<SystemHealthInfo> is deprecated: use mrs_robot_diagnostics-msg:SystemHealthInfo instead.")))

(cl:ensure-generic-function 'cpu_load-val :lambda-list '(m))
(cl:defmethod cpu_load-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:cpu_load-val is deprecated.  Use mrs_robot_diagnostics-msg:cpu_load instead.")
  (cpu_load m))

(cl:ensure-generic-function 'free_ram-val :lambda-list '(m))
(cl:defmethod free_ram-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:free_ram-val is deprecated.  Use mrs_robot_diagnostics-msg:free_ram instead.")
  (free_ram m))

(cl:ensure-generic-function 'total_ram-val :lambda-list '(m))
(cl:defmethod total_ram-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:total_ram-val is deprecated.  Use mrs_robot_diagnostics-msg:total_ram instead.")
  (total_ram m))

(cl:ensure-generic-function 'free_hdd-val :lambda-list '(m))
(cl:defmethod free_hdd-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:free_hdd-val is deprecated.  Use mrs_robot_diagnostics-msg:free_hdd instead.")
  (free_hdd m))

(cl:ensure-generic-function 'node_cpu_loads-val :lambda-list '(m))
(cl:defmethod node_cpu_loads-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:node_cpu_loads-val is deprecated.  Use mrs_robot_diagnostics-msg:node_cpu_loads instead.")
  (node_cpu_loads m))

(cl:ensure-generic-function 'hw_api_rate-val :lambda-list '(m))
(cl:defmethod hw_api_rate-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:hw_api_rate-val is deprecated.  Use mrs_robot_diagnostics-msg:hw_api_rate instead.")
  (hw_api_rate m))

(cl:ensure-generic-function 'control_manager_rate-val :lambda-list '(m))
(cl:defmethod control_manager_rate-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:control_manager_rate-val is deprecated.  Use mrs_robot_diagnostics-msg:control_manager_rate instead.")
  (control_manager_rate m))

(cl:ensure-generic-function 'state_estimation_rate-val :lambda-list '(m))
(cl:defmethod state_estimation_rate-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:state_estimation_rate-val is deprecated.  Use mrs_robot_diagnostics-msg:state_estimation_rate instead.")
  (state_estimation_rate m))

(cl:ensure-generic-function 'gnss_uncertainty-val :lambda-list '(m))
(cl:defmethod gnss_uncertainty-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:gnss_uncertainty-val is deprecated.  Use mrs_robot_diagnostics-msg:gnss_uncertainty instead.")
  (gnss_uncertainty m))

(cl:ensure-generic-function 'mag_strength-val :lambda-list '(m))
(cl:defmethod mag_strength-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:mag_strength-val is deprecated.  Use mrs_robot_diagnostics-msg:mag_strength instead.")
  (mag_strength m))

(cl:ensure-generic-function 'mag_uncertainty-val :lambda-list '(m))
(cl:defmethod mag_uncertainty-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:mag_uncertainty-val is deprecated.  Use mrs_robot_diagnostics-msg:mag_uncertainty instead.")
  (mag_uncertainty m))

(cl:ensure-generic-function 'available_sensors-val :lambda-list '(m))
(cl:defmethod available_sensors-val ((m <SystemHealthInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:available_sensors-val is deprecated.  Use mrs_robot_diagnostics-msg:available_sensors instead.")
  (available_sensors m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SystemHealthInfo>) ostream)
  "Serializes a message object of type '<SystemHealthInfo>"
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'cpu_load))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'free_ram))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'total_ram))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let* ((signed (cl:slot-value msg 'free_hdd)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'node_cpu_loads))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'node_cpu_loads))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'hw_api_rate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'control_manager_rate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'state_estimation_rate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'gnss_uncertainty))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'mag_strength))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'mag_uncertainty))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'available_sensors))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'available_sensors))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SystemHealthInfo>) istream)
  "Deserializes a message object of type '<SystemHealthInfo>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'cpu_load) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'free_ram) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'total_ram) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'free_hdd) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'node_cpu_loads) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'node_cpu_loads)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'mrs_robot_diagnostics-msg:NodeCpuLoad))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hw_api_rate) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'control_manager_rate) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'state_estimation_rate) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gnss_uncertainty) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'mag_strength) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'mag_uncertainty) (roslisp-utils:decode-single-float-bits bits)))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'available_sensors) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'available_sensors)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'mrs_robot_diagnostics-msg:SensorStatus))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SystemHealthInfo>)))
  "Returns string type for a message object of type '<SystemHealthInfo>"
  "mrs_robot_diagnostics/SystemHealthInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SystemHealthInfo)))
  "Returns string type for a message object of type 'SystemHealthInfo"
  "mrs_robot_diagnostics/SystemHealthInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SystemHealthInfo>)))
  "Returns md5sum for a message object of type '<SystemHealthInfo>"
  "b15a8ec46de23a20cb4c28fed651f75d")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SystemHealthInfo)))
  "Returns md5sum for a message object of type 'SystemHealthInfo"
  "b15a8ec46de23a20cb4c28fed651f75d")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SystemHealthInfo>)))
  "Returns full string definition for message of type '<SystemHealthInfo>"
  (cl:format cl:nil "~%float32 cpu_load                # [%]~%float32 free_ram                # [GiB]~%float32 total_ram               # [GiB]~%int32   free_hdd                # [GiB]~%mrs_robot_diagnostics/NodeCpuLoad[] node_cpu_loads~%~%float32 hw_api_rate             # [Hz]~%float32 control_manager_rate    # [Hz]~%float32 state_estimation_rate   # [Hz]~%~%float32 gnss_uncertainty        # [m]~%float32 mag_strength            # [T]~%float32 mag_uncertainty         # [T]~%~%mrs_robot_diagnostics/SensorStatus[] available_sensors~%~%================================================================================~%MSG: mrs_robot_diagnostics/NodeCpuLoad~%string  node_name~%float32 cpu_load~%~%================================================================================~%MSG: mrs_robot_diagnostics/SensorStatus~%string  name~%string  status~%~%uint8 type~%uint8 TYPE_AUTOPILOT    = 0~%uint8 TYPE_RANGEFINDER  = 1~%uint8 TYPE_GPS          = 2 ~%uint8 TYPE_IMU          = 3~%uint8 TYPE_BAROMETER    = 4~%uint8 TYPE_MAGNETOMETER = 5~%uint8 TYPE_LIDAR        = 6~%uint8 TYPE_CAMERA       = 7~%~%bool    ready~%string  topic~%float32 rate  # [hz]~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SystemHealthInfo)))
  "Returns full string definition for message of type 'SystemHealthInfo"
  (cl:format cl:nil "~%float32 cpu_load                # [%]~%float32 free_ram                # [GiB]~%float32 total_ram               # [GiB]~%int32   free_hdd                # [GiB]~%mrs_robot_diagnostics/NodeCpuLoad[] node_cpu_loads~%~%float32 hw_api_rate             # [Hz]~%float32 control_manager_rate    # [Hz]~%float32 state_estimation_rate   # [Hz]~%~%float32 gnss_uncertainty        # [m]~%float32 mag_strength            # [T]~%float32 mag_uncertainty         # [T]~%~%mrs_robot_diagnostics/SensorStatus[] available_sensors~%~%================================================================================~%MSG: mrs_robot_diagnostics/NodeCpuLoad~%string  node_name~%float32 cpu_load~%~%================================================================================~%MSG: mrs_robot_diagnostics/SensorStatus~%string  name~%string  status~%~%uint8 type~%uint8 TYPE_AUTOPILOT    = 0~%uint8 TYPE_RANGEFINDER  = 1~%uint8 TYPE_GPS          = 2 ~%uint8 TYPE_IMU          = 3~%uint8 TYPE_BAROMETER    = 4~%uint8 TYPE_MAGNETOMETER = 5~%uint8 TYPE_LIDAR        = 6~%uint8 TYPE_CAMERA       = 7~%~%bool    ready~%string  topic~%float32 rate  # [hz]~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SystemHealthInfo>))
  (cl:+ 0
     4
     4
     4
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'node_cpu_loads) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4
     4
     4
     4
     4
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'available_sensors) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SystemHealthInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'SystemHealthInfo
    (cl:cons ':cpu_load (cpu_load msg))
    (cl:cons ':free_ram (free_ram msg))
    (cl:cons ':total_ram (total_ram msg))
    (cl:cons ':free_hdd (free_hdd msg))
    (cl:cons ':node_cpu_loads (node_cpu_loads msg))
    (cl:cons ':hw_api_rate (hw_api_rate msg))
    (cl:cons ':control_manager_rate (control_manager_rate msg))
    (cl:cons ':state_estimation_rate (state_estimation_rate msg))
    (cl:cons ':gnss_uncertainty (gnss_uncertainty msg))
    (cl:cons ':mag_strength (mag_strength msg))
    (cl:cons ':mag_uncertainty (mag_uncertainty msg))
    (cl:cons ':available_sensors (available_sensors msg))
))
