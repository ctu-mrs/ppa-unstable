(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(TYPE-VAL
          TYPE
          DETAILS-VAL
          DETAILS
))