(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(NAME-VAL
          NAME
          STATUS-VAL
          STATUS
          TYPE-VAL
          TYPE
          READY-VAL
          READY
          TOPIC-VAL
          TOPIC
          RATE-VAL
          RATE
))