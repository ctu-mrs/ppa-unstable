; Auto-generated. Do not edit!


(cl:in-package mrs_robot_diagnostics-msg)


;//! \htmlinclude SensorStatus.msg.html

(cl:defclass <SensorStatus> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type cl:string
    :initform "")
   (status
    :reader status
    :initarg :status
    :type cl:string
    :initform "")
   (type
    :reader type
    :initarg :type
    :type cl:fixnum
    :initform 0)
   (ready
    :reader ready
    :initarg :ready
    :type cl:boolean
    :initform cl:nil)
   (topic
    :reader topic
    :initarg :topic
    :type cl:string
    :initform "")
   (rate
    :reader rate
    :initarg :rate
    :type cl:float
    :initform 0.0))
)

(cl:defclass SensorStatus (<SensorStatus>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SensorStatus>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SensorStatus)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_robot_diagnostics-msg:<SensorStatus> is deprecated: use mrs_robot_diagnostics-msg:SensorStatus instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <SensorStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:name-val is deprecated.  Use mrs_robot_diagnostics-msg:name instead.")
  (name m))

(cl:ensure-generic-function 'status-val :lambda-list '(m))
(cl:defmethod status-val ((m <SensorStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:status-val is deprecated.  Use mrs_robot_diagnostics-msg:status instead.")
  (status m))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <SensorStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:type-val is deprecated.  Use mrs_robot_diagnostics-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'ready-val :lambda-list '(m))
(cl:defmethod ready-val ((m <SensorStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:ready-val is deprecated.  Use mrs_robot_diagnostics-msg:ready instead.")
  (ready m))

(cl:ensure-generic-function 'topic-val :lambda-list '(m))
(cl:defmethod topic-val ((m <SensorStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:topic-val is deprecated.  Use mrs_robot_diagnostics-msg:topic instead.")
  (topic m))

(cl:ensure-generic-function 'rate-val :lambda-list '(m))
(cl:defmethod rate-val ((m <SensorStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_robot_diagnostics-msg:rate-val is deprecated.  Use mrs_robot_diagnostics-msg:rate instead.")
  (rate m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<SensorStatus>)))
    "Constants for message type '<SensorStatus>"
  '((:TYPE_AUTOPILOT . 0)
    (:TYPE_RANGEFINDER . 1)
    (:TYPE_GPS . 2)
    (:TYPE_IMU . 3)
    (:TYPE_BAROMETER . 4)
    (:TYPE_MAGNETOMETER . 5)
    (:TYPE_LIDAR . 6)
    (:TYPE_CAMERA . 7))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'SensorStatus)))
    "Constants for message type 'SensorStatus"
  '((:TYPE_AUTOPILOT . 0)
    (:TYPE_RANGEFINDER . 1)
    (:TYPE_GPS . 2)
    (:TYPE_IMU . 3)
    (:TYPE_BAROMETER . 4)
    (:TYPE_MAGNETOMETER . 5)
    (:TYPE_LIDAR . 6)
    (:TYPE_CAMERA . 7))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SensorStatus>) ostream)
  "Serializes a message object of type '<SensorStatus>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'name))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'status))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'status))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'ready) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'topic))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'topic))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'rate))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SensorStatus>) istream)
  "Deserializes a message object of type '<SensorStatus>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'status) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'status) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'ready) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'topic) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'topic) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'rate) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SensorStatus>)))
  "Returns string type for a message object of type '<SensorStatus>"
  "mrs_robot_diagnostics/SensorStatus")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SensorStatus)))
  "Returns string type for a message object of type 'SensorStatus"
  "mrs_robot_diagnostics/SensorStatus")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SensorStatus>)))
  "Returns md5sum for a message object of type '<SensorStatus>"
  "95a3a9fe806ee05ed5f4f9160fe18f72")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SensorStatus)))
  "Returns md5sum for a message object of type 'SensorStatus"
  "95a3a9fe806ee05ed5f4f9160fe18f72")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SensorStatus>)))
  "Returns full string definition for message of type '<SensorStatus>"
  (cl:format cl:nil "string  name~%string  status~%~%uint8 type~%uint8 TYPE_AUTOPILOT    = 0~%uint8 TYPE_RANGEFINDER  = 1~%uint8 TYPE_GPS          = 2 ~%uint8 TYPE_IMU          = 3~%uint8 TYPE_BAROMETER    = 4~%uint8 TYPE_MAGNETOMETER = 5~%uint8 TYPE_LIDAR        = 6~%uint8 TYPE_CAMERA       = 7~%~%bool    ready~%string  topic~%float32 rate  # [hz]~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SensorStatus)))
  "Returns full string definition for message of type 'SensorStatus"
  (cl:format cl:nil "string  name~%string  status~%~%uint8 type~%uint8 TYPE_AUTOPILOT    = 0~%uint8 TYPE_RANGEFINDER  = 1~%uint8 TYPE_GPS          = 2 ~%uint8 TYPE_IMU          = 3~%uint8 TYPE_BAROMETER    = 4~%uint8 TYPE_MAGNETOMETER = 5~%uint8 TYPE_LIDAR        = 6~%uint8 TYPE_CAMERA       = 7~%~%bool    ready~%string  topic~%float32 rate  # [hz]~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SensorStatus>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'name))
     4 (cl:length (cl:slot-value msg 'status))
     1
     1
     4 (cl:length (cl:slot-value msg 'topic))
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SensorStatus>))
  "Converts a ROS message object to a list"
  (cl:list 'SensorStatus
    (cl:cons ':name (name msg))
    (cl:cons ':status (status msg))
    (cl:cons ':type (type msg))
    (cl:cons ':ready (ready msg))
    (cl:cons ':topic (topic msg))
    (cl:cons ':rate (rate msg))
))
