
(cl:in-package :asdf)

(defsystem "mrs_robot_diagnostics-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
               :mrs_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "BatteryState" :depends-on ("_package_BatteryState"))
    (:file "_package_BatteryState" :depends-on ("_package"))
    (:file "CollisionAvoidanceInfo" :depends-on ("_package_CollisionAvoidanceInfo"))
    (:file "_package_CollisionAvoidanceInfo" :depends-on ("_package"))
    (:file "ControlInfo" :depends-on ("_package_ControlInfo"))
    (:file "_package_ControlInfo" :depends-on ("_package"))
    (:file "GeneralRobotInfo" :depends-on ("_package_GeneralRobotInfo"))
    (:file "_package_GeneralRobotInfo" :depends-on ("_package"))
    (:file "NodeCpuLoad" :depends-on ("_package_NodeCpuLoad"))
    (:file "_package_NodeCpuLoad" :depends-on ("_package"))
    (:file "SensorInfo" :depends-on ("_package_SensorInfo"))
    (:file "_package_SensorInfo" :depends-on ("_package"))
    (:file "SensorStatus" :depends-on ("_package_SensorStatus"))
    (:file "_package_SensorStatus" :depends-on ("_package"))
    (:file "StateEstimationInfo" :depends-on ("_package_StateEstimationInfo"))
    (:file "_package_StateEstimationInfo" :depends-on ("_package"))
    (:file "SystemHealthInfo" :depends-on ("_package_SystemHealthInfo"))
    (:file "_package_SystemHealthInfo" :depends-on ("_package"))
    (:file "UavInfo" :depends-on ("_package_UavInfo"))
    (:file "_package_UavInfo" :depends-on ("_package"))
    (:file "UavState" :depends-on ("_package_UavState"))
    (:file "_package_UavState" :depends-on ("_package"))
  ))