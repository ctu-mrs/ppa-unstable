(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(VOLTAGE-VAL
          VOLTAGE
          PERCENTAGE-VAL
          PERCENTAGE
          WH_DRAINED-VAL
          WH_DRAINED
))