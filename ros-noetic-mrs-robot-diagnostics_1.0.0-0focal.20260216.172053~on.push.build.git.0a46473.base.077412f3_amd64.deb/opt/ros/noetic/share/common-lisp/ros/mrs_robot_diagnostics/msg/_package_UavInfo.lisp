(cl:in-package mrs_robot_diagnostics-msg)
(cl:export '(FLIGHT_STATE-VAL
          FLIGHT_STATE
          FLIGHT_DURATION-VAL
          FLIGHT_DURATION
          ARMED-VAL
          ARMED
          OFFBOARD-VAL
          OFFBOARD
          MASS_NOMINAL-VAL
          MASS_NOMINAL
          MASS_ESTIMATE-VAL
          MASS_ESTIMATE
))