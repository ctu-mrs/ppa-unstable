// Auto-generated. Do not edit!

// (in-package mrs_robot_diagnostics.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class BatteryState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.voltage = null;
      this.percentage = null;
      this.wh_drained = null;
    }
    else {
      if (initObj.hasOwnProperty('voltage')) {
        this.voltage = initObj.voltage
      }
      else {
        this.voltage = 0.0;
      }
      if (initObj.hasOwnProperty('percentage')) {
        this.percentage = initObj.percentage
      }
      else {
        this.percentage = 0.0;
      }
      if (initObj.hasOwnProperty('wh_drained')) {
        this.wh_drained = initObj.wh_drained
      }
      else {
        this.wh_drained = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BatteryState
    // Serialize message field [voltage]
    bufferOffset = _serializer.float64(obj.voltage, buffer, bufferOffset);
    // Serialize message field [percentage]
    bufferOffset = _serializer.float64(obj.percentage, buffer, bufferOffset);
    // Serialize message field [wh_drained]
    bufferOffset = _serializer.float64(obj.wh_drained, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BatteryState
    let len;
    let data = new BatteryState(null);
    // Deserialize message field [voltage]
    data.voltage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [percentage]
    data.percentage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [wh_drained]
    data.wh_drained = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_robot_diagnostics/BatteryState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6e8c6449832befe6d9741b7586e0125a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 voltage
    float64 percentage
    float64 wh_drained
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BatteryState(null);
    if (msg.voltage !== undefined) {
      resolved.voltage = msg.voltage;
    }
    else {
      resolved.voltage = 0.0
    }

    if (msg.percentage !== undefined) {
      resolved.percentage = msg.percentage;
    }
    else {
      resolved.percentage = 0.0
    }

    if (msg.wh_drained !== undefined) {
      resolved.wh_drained = msg.wh_drained;
    }
    else {
      resolved.wh_drained = 0.0
    }

    return resolved;
    }
};

module.exports = BatteryState;
