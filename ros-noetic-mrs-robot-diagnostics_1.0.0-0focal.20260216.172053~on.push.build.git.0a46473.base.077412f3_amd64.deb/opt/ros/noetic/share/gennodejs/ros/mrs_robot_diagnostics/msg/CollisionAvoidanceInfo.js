// Auto-generated. Do not edit!

// (in-package mrs_robot_diagnostics.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class CollisionAvoidanceInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.collision_avoidance_enabled = null;
      this.avoiding_collision = null;
      this.other_robots_visible = null;
    }
    else {
      if (initObj.hasOwnProperty('collision_avoidance_enabled')) {
        this.collision_avoidance_enabled = initObj.collision_avoidance_enabled
      }
      else {
        this.collision_avoidance_enabled = false;
      }
      if (initObj.hasOwnProperty('avoiding_collision')) {
        this.avoiding_collision = initObj.avoiding_collision
      }
      else {
        this.avoiding_collision = false;
      }
      if (initObj.hasOwnProperty('other_robots_visible')) {
        this.other_robots_visible = initObj.other_robots_visible
      }
      else {
        this.other_robots_visible = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CollisionAvoidanceInfo
    // Serialize message field [collision_avoidance_enabled]
    bufferOffset = _serializer.bool(obj.collision_avoidance_enabled, buffer, bufferOffset);
    // Serialize message field [avoiding_collision]
    bufferOffset = _serializer.bool(obj.avoiding_collision, buffer, bufferOffset);
    // Serialize message field [other_robots_visible]
    bufferOffset = _arraySerializer.string(obj.other_robots_visible, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CollisionAvoidanceInfo
    let len;
    let data = new CollisionAvoidanceInfo(null);
    // Deserialize message field [collision_avoidance_enabled]
    data.collision_avoidance_enabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [avoiding_collision]
    data.avoiding_collision = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [other_robots_visible]
    data.other_robots_visible = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.other_robots_visible.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 6;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_robot_diagnostics/CollisionAvoidanceInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fb981268dbbb1fedcf378ca128941e66';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    bool      collision_avoidance_enabled
    bool      avoiding_collision
    string[]  other_robots_visible
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CollisionAvoidanceInfo(null);
    if (msg.collision_avoidance_enabled !== undefined) {
      resolved.collision_avoidance_enabled = msg.collision_avoidance_enabled;
    }
    else {
      resolved.collision_avoidance_enabled = false
    }

    if (msg.avoiding_collision !== undefined) {
      resolved.avoiding_collision = msg.avoiding_collision;
    }
    else {
      resolved.avoiding_collision = false
    }

    if (msg.other_robots_visible !== undefined) {
      resolved.other_robots_visible = msg.other_robots_visible;
    }
    else {
      resolved.other_robots_visible = []
    }

    return resolved;
    }
};

module.exports = CollisionAvoidanceInfo;
