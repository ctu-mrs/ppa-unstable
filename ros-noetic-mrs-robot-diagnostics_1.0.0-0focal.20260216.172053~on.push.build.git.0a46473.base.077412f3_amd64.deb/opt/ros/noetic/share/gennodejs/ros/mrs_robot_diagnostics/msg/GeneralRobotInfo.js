// Auto-generated. Do not edit!

// (in-package mrs_robot_diagnostics.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let BatteryState = require('./BatteryState.js');

//-----------------------------------------------------------

class GeneralRobotInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.robot_name = null;
      this.robot_type = null;
      this.robot_ip_address = null;
      this.battery_state = null;
      this.ready_to_start = null;
      this.problems_preventing_start = null;
      this.errors = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('robot_name')) {
        this.robot_name = initObj.robot_name
      }
      else {
        this.robot_name = '';
      }
      if (initObj.hasOwnProperty('robot_type')) {
        this.robot_type = initObj.robot_type
      }
      else {
        this.robot_type = 0;
      }
      if (initObj.hasOwnProperty('robot_ip_address')) {
        this.robot_ip_address = initObj.robot_ip_address
      }
      else {
        this.robot_ip_address = '';
      }
      if (initObj.hasOwnProperty('battery_state')) {
        this.battery_state = initObj.battery_state
      }
      else {
        this.battery_state = new BatteryState();
      }
      if (initObj.hasOwnProperty('ready_to_start')) {
        this.ready_to_start = initObj.ready_to_start
      }
      else {
        this.ready_to_start = false;
      }
      if (initObj.hasOwnProperty('problems_preventing_start')) {
        this.problems_preventing_start = initObj.problems_preventing_start
      }
      else {
        this.problems_preventing_start = [];
      }
      if (initObj.hasOwnProperty('errors')) {
        this.errors = initObj.errors
      }
      else {
        this.errors = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GeneralRobotInfo
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [robot_name]
    bufferOffset = _serializer.string(obj.robot_name, buffer, bufferOffset);
    // Serialize message field [robot_type]
    bufferOffset = _serializer.uint8(obj.robot_type, buffer, bufferOffset);
    // Serialize message field [robot_ip_address]
    bufferOffset = _serializer.string(obj.robot_ip_address, buffer, bufferOffset);
    // Serialize message field [battery_state]
    bufferOffset = BatteryState.serialize(obj.battery_state, buffer, bufferOffset);
    // Serialize message field [ready_to_start]
    bufferOffset = _serializer.bool(obj.ready_to_start, buffer, bufferOffset);
    // Serialize message field [problems_preventing_start]
    bufferOffset = _arraySerializer.string(obj.problems_preventing_start, buffer, bufferOffset, null);
    // Serialize message field [errors]
    bufferOffset = _arraySerializer.string(obj.errors, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GeneralRobotInfo
    let len;
    let data = new GeneralRobotInfo(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [robot_name]
    data.robot_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [robot_type]
    data.robot_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [robot_ip_address]
    data.robot_ip_address = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [battery_state]
    data.battery_state = BatteryState.deserialize(buffer, bufferOffset);
    // Deserialize message field [ready_to_start]
    data.ready_to_start = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [problems_preventing_start]
    data.problems_preventing_start = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [errors]
    data.errors = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.robot_name);
    length += _getByteLength(object.robot_ip_address);
    object.problems_preventing_start.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.errors.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 50;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_robot_diagnostics/GeneralRobotInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8f8ad84ab9ed52ce1423ffee93d7554c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    time stamp
    string robot_name
    uint8  robot_type
    string robot_ip_address
    
    mrs_robot_diagnostics/BatteryState battery_state
    
    bool ready_to_start
    string[] problems_preventing_start
    string[] errors
    
    ================================================================================
    MSG: mrs_robot_diagnostics/BatteryState
    float64 voltage
    float64 percentage
    float64 wh_drained
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GeneralRobotInfo(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.robot_name !== undefined) {
      resolved.robot_name = msg.robot_name;
    }
    else {
      resolved.robot_name = ''
    }

    if (msg.robot_type !== undefined) {
      resolved.robot_type = msg.robot_type;
    }
    else {
      resolved.robot_type = 0
    }

    if (msg.robot_ip_address !== undefined) {
      resolved.robot_ip_address = msg.robot_ip_address;
    }
    else {
      resolved.robot_ip_address = ''
    }

    if (msg.battery_state !== undefined) {
      resolved.battery_state = BatteryState.Resolve(msg.battery_state)
    }
    else {
      resolved.battery_state = new BatteryState()
    }

    if (msg.ready_to_start !== undefined) {
      resolved.ready_to_start = msg.ready_to_start;
    }
    else {
      resolved.ready_to_start = false
    }

    if (msg.problems_preventing_start !== undefined) {
      resolved.problems_preventing_start = msg.problems_preventing_start;
    }
    else {
      resolved.problems_preventing_start = []
    }

    if (msg.errors !== undefined) {
      resolved.errors = msg.errors;
    }
    else {
      resolved.errors = []
    }

    return resolved;
    }
};

module.exports = GeneralRobotInfo;
