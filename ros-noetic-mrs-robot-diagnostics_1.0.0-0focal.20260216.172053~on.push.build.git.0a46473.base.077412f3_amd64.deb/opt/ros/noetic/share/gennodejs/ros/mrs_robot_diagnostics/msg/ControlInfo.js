// Auto-generated. Do not edit!

// (in-package mrs_robot_diagnostics.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ControlInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.active_controller = null;
      this.available_controllers = null;
      this.active_tracker = null;
      this.available_trackers = null;
      this.thrust = null;
    }
    else {
      if (initObj.hasOwnProperty('active_controller')) {
        this.active_controller = initObj.active_controller
      }
      else {
        this.active_controller = '';
      }
      if (initObj.hasOwnProperty('available_controllers')) {
        this.available_controllers = initObj.available_controllers
      }
      else {
        this.available_controllers = [];
      }
      if (initObj.hasOwnProperty('active_tracker')) {
        this.active_tracker = initObj.active_tracker
      }
      else {
        this.active_tracker = '';
      }
      if (initObj.hasOwnProperty('available_trackers')) {
        this.available_trackers = initObj.available_trackers
      }
      else {
        this.available_trackers = [];
      }
      if (initObj.hasOwnProperty('thrust')) {
        this.thrust = initObj.thrust
      }
      else {
        this.thrust = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ControlInfo
    // Serialize message field [active_controller]
    bufferOffset = _serializer.string(obj.active_controller, buffer, bufferOffset);
    // Serialize message field [available_controllers]
    bufferOffset = _arraySerializer.string(obj.available_controllers, buffer, bufferOffset, null);
    // Serialize message field [active_tracker]
    bufferOffset = _serializer.string(obj.active_tracker, buffer, bufferOffset);
    // Serialize message field [available_trackers]
    bufferOffset = _arraySerializer.string(obj.available_trackers, buffer, bufferOffset, null);
    // Serialize message field [thrust]
    bufferOffset = _serializer.float32(obj.thrust, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ControlInfo
    let len;
    let data = new ControlInfo(null);
    // Deserialize message field [active_controller]
    data.active_controller = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [available_controllers]
    data.available_controllers = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [active_tracker]
    data.active_tracker = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [available_trackers]
    data.available_trackers = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [thrust]
    data.thrust = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.active_controller);
    object.available_controllers.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.active_tracker);
    object.available_trackers.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_robot_diagnostics/ControlInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '60f44d6d23f58b43adf06836b19dd68a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string    active_controller
    string[]  available_controllers
    
    string    active_tracker
    string[]  available_trackers
    
    float32   thrust    # [%]
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ControlInfo(null);
    if (msg.active_controller !== undefined) {
      resolved.active_controller = msg.active_controller;
    }
    else {
      resolved.active_controller = ''
    }

    if (msg.available_controllers !== undefined) {
      resolved.available_controllers = msg.available_controllers;
    }
    else {
      resolved.available_controllers = []
    }

    if (msg.active_tracker !== undefined) {
      resolved.active_tracker = msg.active_tracker;
    }
    else {
      resolved.active_tracker = ''
    }

    if (msg.available_trackers !== undefined) {
      resolved.available_trackers = msg.available_trackers;
    }
    else {
      resolved.available_trackers = []
    }

    if (msg.thrust !== undefined) {
      resolved.thrust = msg.thrust;
    }
    else {
      resolved.thrust = 0.0
    }

    return resolved;
    }
};

module.exports = ControlInfo;
