// Auto-generated. Do not edit!

// (in-package mrs_robot_diagnostics.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class UavInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.flight_state = null;
      this.flight_duration = null;
      this.armed = null;
      this.offboard = null;
      this.mass_nominal = null;
      this.mass_estimate = null;
    }
    else {
      if (initObj.hasOwnProperty('flight_state')) {
        this.flight_state = initObj.flight_state
      }
      else {
        this.flight_state = '';
      }
      if (initObj.hasOwnProperty('flight_duration')) {
        this.flight_duration = initObj.flight_duration
      }
      else {
        this.flight_duration = 0.0;
      }
      if (initObj.hasOwnProperty('armed')) {
        this.armed = initObj.armed
      }
      else {
        this.armed = false;
      }
      if (initObj.hasOwnProperty('offboard')) {
        this.offboard = initObj.offboard
      }
      else {
        this.offboard = false;
      }
      if (initObj.hasOwnProperty('mass_nominal')) {
        this.mass_nominal = initObj.mass_nominal
      }
      else {
        this.mass_nominal = 0.0;
      }
      if (initObj.hasOwnProperty('mass_estimate')) {
        this.mass_estimate = initObj.mass_estimate
      }
      else {
        this.mass_estimate = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UavInfo
    // Serialize message field [flight_state]
    bufferOffset = _serializer.string(obj.flight_state, buffer, bufferOffset);
    // Serialize message field [flight_duration]
    bufferOffset = _serializer.float64(obj.flight_duration, buffer, bufferOffset);
    // Serialize message field [armed]
    bufferOffset = _serializer.bool(obj.armed, buffer, bufferOffset);
    // Serialize message field [offboard]
    bufferOffset = _serializer.bool(obj.offboard, buffer, bufferOffset);
    // Serialize message field [mass_nominal]
    bufferOffset = _serializer.float64(obj.mass_nominal, buffer, bufferOffset);
    // Serialize message field [mass_estimate]
    bufferOffset = _serializer.float64(obj.mass_estimate, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UavInfo
    let len;
    let data = new UavInfo(null);
    // Deserialize message field [flight_state]
    data.flight_state = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [flight_duration]
    data.flight_duration = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [armed]
    data.armed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [offboard]
    data.offboard = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [mass_nominal]
    data.mass_nominal = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [mass_estimate]
    data.mass_estimate = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.flight_state);
    return length + 30;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_robot_diagnostics/UavInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2507a055113367f459cd6f611b464a8d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    string flight_state
    float64 flight_duration # seconds
    bool armed
    bool offboard
    float64 mass_nominal # kilograms
    float64 mass_estimate # kilograms
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UavInfo(null);
    if (msg.flight_state !== undefined) {
      resolved.flight_state = msg.flight_state;
    }
    else {
      resolved.flight_state = ''
    }

    if (msg.flight_duration !== undefined) {
      resolved.flight_duration = msg.flight_duration;
    }
    else {
      resolved.flight_duration = 0.0
    }

    if (msg.armed !== undefined) {
      resolved.armed = msg.armed;
    }
    else {
      resolved.armed = false
    }

    if (msg.offboard !== undefined) {
      resolved.offboard = msg.offboard;
    }
    else {
      resolved.offboard = false
    }

    if (msg.mass_nominal !== undefined) {
      resolved.mass_nominal = msg.mass_nominal;
    }
    else {
      resolved.mass_nominal = 0.0
    }

    if (msg.mass_estimate !== undefined) {
      resolved.mass_estimate = msg.mass_estimate;
    }
    else {
      resolved.mass_estimate = 0.0
    }

    return resolved;
    }
};

module.exports = UavInfo;
