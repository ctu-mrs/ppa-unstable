// Auto-generated. Do not edit!

// (in-package mrs_robot_diagnostics.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SensorInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.type = null;
      this.details = null;
    }
    else {
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('details')) {
        this.details = initObj.details
      }
      else {
        this.details = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SensorInfo
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [details]
    bufferOffset = _serializer.string(obj.details, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SensorInfo
    let len;
    let data = new SensorInfo(null);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [details]
    data.details = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.details);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_robot_diagnostics/SensorInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '06602f1fca09c63c0587fc3e5006d5d0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 type
    string details
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SensorInfo(null);
    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.details !== undefined) {
      resolved.details = msg.details;
    }
    else {
      resolved.details = ''
    }

    return resolved;
    }
};

module.exports = SensorInfo;
