// Auto-generated. Do not edit!

// (in-package mrs_robot_diagnostics.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class UavState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.state = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UavState
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [state]
    bufferOffset = _serializer.uint8(obj.state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UavState
    let len;
    let data = new UavState(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [state]
    data.state = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_robot_diagnostics/UavState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0c44ef3c15c14afc9968017d438f8b59';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time  stamp
    
    uint8 state
    
    uint8 STATE_UNKNOWN     = 0
    uint8 STATE_DISARMED    = 1
    uint8 STATE_ARMED       = 2
    uint8 STATE_OFFBOARD    = 3
    uint8 STATE_MANUAL      = 4
    uint8 STATE_TAKEOFF     = 5
    uint8 STATE_LAND        = 6
    uint8 STATE_RC_MODE     = 7
    uint8 STATE_HOVER       = 8
    uint8 STATE_GOTO        = 9
    uint8 STATE_TRAJECTORY  = 10
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UavState(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.state !== undefined) {
      resolved.state = msg.state;
    }
    else {
      resolved.state = 0
    }

    return resolved;
    }
};

// Constants for message
UavState.Constants = {
  STATE_UNKNOWN: 0,
  STATE_DISARMED: 1,
  STATE_ARMED: 2,
  STATE_OFFBOARD: 3,
  STATE_MANUAL: 4,
  STATE_TAKEOFF: 5,
  STATE_LAND: 6,
  STATE_RC_MODE: 7,
  STATE_HOVER: 8,
  STATE_GOTO: 9,
  STATE_TRAJECTORY: 10,
}

module.exports = UavState;
