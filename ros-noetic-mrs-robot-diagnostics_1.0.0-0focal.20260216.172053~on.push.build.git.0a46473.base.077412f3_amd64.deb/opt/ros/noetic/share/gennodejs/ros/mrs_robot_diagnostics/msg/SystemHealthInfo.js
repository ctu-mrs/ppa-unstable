// Auto-generated. Do not edit!

// (in-package mrs_robot_diagnostics.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let NodeCpuLoad = require('./NodeCpuLoad.js');
let SensorStatus = require('./SensorStatus.js');

//-----------------------------------------------------------

class SystemHealthInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.cpu_load = null;
      this.free_ram = null;
      this.total_ram = null;
      this.free_hdd = null;
      this.node_cpu_loads = null;
      this.hw_api_rate = null;
      this.control_manager_rate = null;
      this.state_estimation_rate = null;
      this.gnss_uncertainty = null;
      this.mag_strength = null;
      this.mag_uncertainty = null;
      this.available_sensors = null;
    }
    else {
      if (initObj.hasOwnProperty('cpu_load')) {
        this.cpu_load = initObj.cpu_load
      }
      else {
        this.cpu_load = 0.0;
      }
      if (initObj.hasOwnProperty('free_ram')) {
        this.free_ram = initObj.free_ram
      }
      else {
        this.free_ram = 0.0;
      }
      if (initObj.hasOwnProperty('total_ram')) {
        this.total_ram = initObj.total_ram
      }
      else {
        this.total_ram = 0.0;
      }
      if (initObj.hasOwnProperty('free_hdd')) {
        this.free_hdd = initObj.free_hdd
      }
      else {
        this.free_hdd = 0;
      }
      if (initObj.hasOwnProperty('node_cpu_loads')) {
        this.node_cpu_loads = initObj.node_cpu_loads
      }
      else {
        this.node_cpu_loads = [];
      }
      if (initObj.hasOwnProperty('hw_api_rate')) {
        this.hw_api_rate = initObj.hw_api_rate
      }
      else {
        this.hw_api_rate = 0.0;
      }
      if (initObj.hasOwnProperty('control_manager_rate')) {
        this.control_manager_rate = initObj.control_manager_rate
      }
      else {
        this.control_manager_rate = 0.0;
      }
      if (initObj.hasOwnProperty('state_estimation_rate')) {
        this.state_estimation_rate = initObj.state_estimation_rate
      }
      else {
        this.state_estimation_rate = 0.0;
      }
      if (initObj.hasOwnProperty('gnss_uncertainty')) {
        this.gnss_uncertainty = initObj.gnss_uncertainty
      }
      else {
        this.gnss_uncertainty = 0.0;
      }
      if (initObj.hasOwnProperty('mag_strength')) {
        this.mag_strength = initObj.mag_strength
      }
      else {
        this.mag_strength = 0.0;
      }
      if (initObj.hasOwnProperty('mag_uncertainty')) {
        this.mag_uncertainty = initObj.mag_uncertainty
      }
      else {
        this.mag_uncertainty = 0.0;
      }
      if (initObj.hasOwnProperty('available_sensors')) {
        this.available_sensors = initObj.available_sensors
      }
      else {
        this.available_sensors = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SystemHealthInfo
    // Serialize message field [cpu_load]
    bufferOffset = _serializer.float32(obj.cpu_load, buffer, bufferOffset);
    // Serialize message field [free_ram]
    bufferOffset = _serializer.float32(obj.free_ram, buffer, bufferOffset);
    // Serialize message field [total_ram]
    bufferOffset = _serializer.float32(obj.total_ram, buffer, bufferOffset);
    // Serialize message field [free_hdd]
    bufferOffset = _serializer.int32(obj.free_hdd, buffer, bufferOffset);
    // Serialize message field [node_cpu_loads]
    // Serialize the length for message field [node_cpu_loads]
    bufferOffset = _serializer.uint32(obj.node_cpu_loads.length, buffer, bufferOffset);
    obj.node_cpu_loads.forEach((val) => {
      bufferOffset = NodeCpuLoad.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [hw_api_rate]
    bufferOffset = _serializer.float32(obj.hw_api_rate, buffer, bufferOffset);
    // Serialize message field [control_manager_rate]
    bufferOffset = _serializer.float32(obj.control_manager_rate, buffer, bufferOffset);
    // Serialize message field [state_estimation_rate]
    bufferOffset = _serializer.float32(obj.state_estimation_rate, buffer, bufferOffset);
    // Serialize message field [gnss_uncertainty]
    bufferOffset = _serializer.float32(obj.gnss_uncertainty, buffer, bufferOffset);
    // Serialize message field [mag_strength]
    bufferOffset = _serializer.float32(obj.mag_strength, buffer, bufferOffset);
    // Serialize message field [mag_uncertainty]
    bufferOffset = _serializer.float32(obj.mag_uncertainty, buffer, bufferOffset);
    // Serialize message field [available_sensors]
    // Serialize the length for message field [available_sensors]
    bufferOffset = _serializer.uint32(obj.available_sensors.length, buffer, bufferOffset);
    obj.available_sensors.forEach((val) => {
      bufferOffset = SensorStatus.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SystemHealthInfo
    let len;
    let data = new SystemHealthInfo(null);
    // Deserialize message field [cpu_load]
    data.cpu_load = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [free_ram]
    data.free_ram = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [total_ram]
    data.total_ram = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [free_hdd]
    data.free_hdd = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [node_cpu_loads]
    // Deserialize array length for message field [node_cpu_loads]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.node_cpu_loads = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.node_cpu_loads[i] = NodeCpuLoad.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [hw_api_rate]
    data.hw_api_rate = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [control_manager_rate]
    data.control_manager_rate = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [state_estimation_rate]
    data.state_estimation_rate = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gnss_uncertainty]
    data.gnss_uncertainty = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [mag_strength]
    data.mag_strength = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [mag_uncertainty]
    data.mag_uncertainty = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [available_sensors]
    // Deserialize array length for message field [available_sensors]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.available_sensors = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.available_sensors[i] = SensorStatus.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.node_cpu_loads.forEach((val) => {
      length += NodeCpuLoad.getMessageSize(val);
    });
    object.available_sensors.forEach((val) => {
      length += SensorStatus.getMessageSize(val);
    });
    return length + 48;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_robot_diagnostics/SystemHealthInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b15a8ec46de23a20cb4c28fed651f75d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    float32 cpu_load                # [%]
    float32 free_ram                # [GiB]
    float32 total_ram               # [GiB]
    int32   free_hdd                # [GiB]
    mrs_robot_diagnostics/NodeCpuLoad[] node_cpu_loads
    
    float32 hw_api_rate             # [Hz]
    float32 control_manager_rate    # [Hz]
    float32 state_estimation_rate   # [Hz]
    
    float32 gnss_uncertainty        # [m]
    float32 mag_strength            # [T]
    float32 mag_uncertainty         # [T]
    
    mrs_robot_diagnostics/SensorStatus[] available_sensors
    
    ================================================================================
    MSG: mrs_robot_diagnostics/NodeCpuLoad
    string  node_name
    float32 cpu_load
    
    ================================================================================
    MSG: mrs_robot_diagnostics/SensorStatus
    string  name
    string  status
    
    uint8 type
    uint8 TYPE_AUTOPILOT    = 0
    uint8 TYPE_RANGEFINDER  = 1
    uint8 TYPE_GPS          = 2 
    uint8 TYPE_IMU          = 3
    uint8 TYPE_BAROMETER    = 4
    uint8 TYPE_MAGNETOMETER = 5
    uint8 TYPE_LIDAR        = 6
    uint8 TYPE_CAMERA       = 7
    
    bool    ready
    string  topic
    float32 rate  # [hz]
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SystemHealthInfo(null);
    if (msg.cpu_load !== undefined) {
      resolved.cpu_load = msg.cpu_load;
    }
    else {
      resolved.cpu_load = 0.0
    }

    if (msg.free_ram !== undefined) {
      resolved.free_ram = msg.free_ram;
    }
    else {
      resolved.free_ram = 0.0
    }

    if (msg.total_ram !== undefined) {
      resolved.total_ram = msg.total_ram;
    }
    else {
      resolved.total_ram = 0.0
    }

    if (msg.free_hdd !== undefined) {
      resolved.free_hdd = msg.free_hdd;
    }
    else {
      resolved.free_hdd = 0
    }

    if (msg.node_cpu_loads !== undefined) {
      resolved.node_cpu_loads = new Array(msg.node_cpu_loads.length);
      for (let i = 0; i < resolved.node_cpu_loads.length; ++i) {
        resolved.node_cpu_loads[i] = NodeCpuLoad.Resolve(msg.node_cpu_loads[i]);
      }
    }
    else {
      resolved.node_cpu_loads = []
    }

    if (msg.hw_api_rate !== undefined) {
      resolved.hw_api_rate = msg.hw_api_rate;
    }
    else {
      resolved.hw_api_rate = 0.0
    }

    if (msg.control_manager_rate !== undefined) {
      resolved.control_manager_rate = msg.control_manager_rate;
    }
    else {
      resolved.control_manager_rate = 0.0
    }

    if (msg.state_estimation_rate !== undefined) {
      resolved.state_estimation_rate = msg.state_estimation_rate;
    }
    else {
      resolved.state_estimation_rate = 0.0
    }

    if (msg.gnss_uncertainty !== undefined) {
      resolved.gnss_uncertainty = msg.gnss_uncertainty;
    }
    else {
      resolved.gnss_uncertainty = 0.0
    }

    if (msg.mag_strength !== undefined) {
      resolved.mag_strength = msg.mag_strength;
    }
    else {
      resolved.mag_strength = 0.0
    }

    if (msg.mag_uncertainty !== undefined) {
      resolved.mag_uncertainty = msg.mag_uncertainty;
    }
    else {
      resolved.mag_uncertainty = 0.0
    }

    if (msg.available_sensors !== undefined) {
      resolved.available_sensors = new Array(msg.available_sensors.length);
      for (let i = 0; i < resolved.available_sensors.length; ++i) {
        resolved.available_sensors[i] = SensorStatus.Resolve(msg.available_sensors[i]);
      }
    }
    else {
      resolved.available_sensors = []
    }

    return resolved;
    }
};

module.exports = SystemHealthInfo;
