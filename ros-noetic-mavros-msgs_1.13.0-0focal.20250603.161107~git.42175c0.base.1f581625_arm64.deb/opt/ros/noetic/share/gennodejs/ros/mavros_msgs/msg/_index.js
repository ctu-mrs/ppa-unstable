
"use strict";

let PlayTuneV2 = require('./PlayTuneV2.js');
let HilActuatorControls = require('./HilActuatorControls.js');
let ESCInfoItem = require('./ESCInfoItem.js');
let ManualControl = require('./ManualControl.js');
let WheelOdomStamped = require('./WheelOdomStamped.js');
let CompanionProcessStatus = require('./CompanionProcessStatus.js');
let State = require('./State.js');
let ESCStatus = require('./ESCStatus.js');
let PositionTarget = require('./PositionTarget.js');
let Vibration = require('./Vibration.js');
let ActuatorControl = require('./ActuatorControl.js');
let Waypoint = require('./Waypoint.js');
let TerrainReport = require('./TerrainReport.js');
let Thrust = require('./Thrust.js');
let LogData = require('./LogData.js');
let GPSINPUT = require('./GPSINPUT.js');
let ADSBVehicle = require('./ADSBVehicle.js');
let WaypointReached = require('./WaypointReached.js');
let BatteryStatus = require('./BatteryStatus.js');
let LandingTarget = require('./LandingTarget.js');
let ESCTelemetry = require('./ESCTelemetry.js');
let HomePosition = require('./HomePosition.js');
let Trajectory = require('./Trajectory.js');
let RTKBaseline = require('./RTKBaseline.js');
let StatusText = require('./StatusText.js');
let FileEntry = require('./FileEntry.js');
let CamIMUStamp = require('./CamIMUStamp.js');
let OnboardComputerStatus = require('./OnboardComputerStatus.js');
let AttitudeTarget = require('./AttitudeTarget.js');
let Param = require('./Param.js');
let RCIn = require('./RCIn.js');
let HilSensor = require('./HilSensor.js');
let TimesyncStatus = require('./TimesyncStatus.js');
let MagnetometerReporter = require('./MagnetometerReporter.js');
let GPSRAW = require('./GPSRAW.js');
let NavControllerOutput = require('./NavControllerOutput.js');
let HilStateQuaternion = require('./HilStateQuaternion.js');
let RCOut = require('./RCOut.js');
let GPSRTK = require('./GPSRTK.js');
let RTCM = require('./RTCM.js');
let OpticalFlowRad = require('./OpticalFlowRad.js');
let EstimatorStatus = require('./EstimatorStatus.js');
let ESCStatusItem = require('./ESCStatusItem.js');
let HilGPS = require('./HilGPS.js');
let RadioStatus = require('./RadioStatus.js');
let CommandCode = require('./CommandCode.js');
let VFR_HUD = require('./VFR_HUD.js');
let WaypointList = require('./WaypointList.js');
let Altitude = require('./Altitude.js');
let GlobalPositionTarget = require('./GlobalPositionTarget.js');
let ParamValue = require('./ParamValue.js');
let Mavlink = require('./Mavlink.js');
let Tunnel = require('./Tunnel.js');
let VehicleInfo = require('./VehicleInfo.js');
let HilControls = require('./HilControls.js');
let ESCTelemetryItem = require('./ESCTelemetryItem.js');
let OverrideRCIn = require('./OverrideRCIn.js');
let ESCInfo = require('./ESCInfo.js');
let ExtendedState = require('./ExtendedState.js');
let DebugValue = require('./DebugValue.js');
let MountControl = require('./MountControl.js');
let LogEntry = require('./LogEntry.js');
let CameraImageCaptured = require('./CameraImageCaptured.js');

module.exports = {
  PlayTuneV2: PlayTuneV2,
  HilActuatorControls: HilActuatorControls,
  ESCInfoItem: ESCInfoItem,
  ManualControl: ManualControl,
  WheelOdomStamped: WheelOdomStamped,
  CompanionProcessStatus: CompanionProcessStatus,
  State: State,
  ESCStatus: ESCStatus,
  PositionTarget: PositionTarget,
  Vibration: Vibration,
  ActuatorControl: ActuatorControl,
  Waypoint: Waypoint,
  TerrainReport: TerrainReport,
  Thrust: Thrust,
  LogData: LogData,
  GPSINPUT: GPSINPUT,
  ADSBVehicle: ADSBVehicle,
  WaypointReached: WaypointReached,
  BatteryStatus: BatteryStatus,
  LandingTarget: LandingTarget,
  ESCTelemetry: ESCTelemetry,
  HomePosition: HomePosition,
  Trajectory: Trajectory,
  RTKBaseline: RTKBaseline,
  StatusText: StatusText,
  FileEntry: FileEntry,
  CamIMUStamp: CamIMUStamp,
  OnboardComputerStatus: OnboardComputerStatus,
  AttitudeTarget: AttitudeTarget,
  Param: Param,
  RCIn: RCIn,
  HilSensor: HilSensor,
  TimesyncStatus: TimesyncStatus,
  MagnetometerReporter: MagnetometerReporter,
  GPSRAW: GPSRAW,
  NavControllerOutput: NavControllerOutput,
  HilStateQuaternion: HilStateQuaternion,
  RCOut: RCOut,
  GPSRTK: GPSRTK,
  RTCM: RTCM,
  OpticalFlowRad: OpticalFlowRad,
  EstimatorStatus: EstimatorStatus,
  ESCStatusItem: ESCStatusItem,
  HilGPS: HilGPS,
  RadioStatus: RadioStatus,
  CommandCode: CommandCode,
  VFR_HUD: VFR_HUD,
  WaypointList: WaypointList,
  Altitude: Altitude,
  GlobalPositionTarget: GlobalPositionTarget,
  ParamValue: ParamValue,
  Mavlink: Mavlink,
  Tunnel: Tunnel,
  VehicleInfo: VehicleInfo,
  HilControls: HilControls,
  ESCTelemetryItem: ESCTelemetryItem,
  OverrideRCIn: OverrideRCIn,
  ESCInfo: ESCInfo,
  ExtendedState: ExtendedState,
  DebugValue: DebugValue,
  MountControl: MountControl,
  LogEntry: LogEntry,
  CameraImageCaptured: CameraImageCaptured,
};
