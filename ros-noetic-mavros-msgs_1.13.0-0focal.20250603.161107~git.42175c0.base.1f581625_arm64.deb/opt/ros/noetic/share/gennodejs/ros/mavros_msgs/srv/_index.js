
"use strict";

let ParamGet = require('./ParamGet.js')
let FileChecksum = require('./FileChecksum.js')
let LogRequestList = require('./LogRequestList.js')
let FileRemove = require('./FileRemove.js')
let CommandHome = require('./CommandHome.js')
let VehicleInfoGet = require('./VehicleInfoGet.js')
let WaypointClear = require('./WaypointClear.js')
let FileRead = require('./FileRead.js')
let FileOpen = require('./FileOpen.js')
let FileClose = require('./FileClose.js')
let MountConfigure = require('./MountConfigure.js')
let CommandBool = require('./CommandBool.js')
let LogRequestData = require('./LogRequestData.js')
let SetMavFrame = require('./SetMavFrame.js')
let FileList = require('./FileList.js')
let FileMakeDir = require('./FileMakeDir.js')
let FileTruncate = require('./FileTruncate.js')
let CommandTOL = require('./CommandTOL.js')
let WaypointSetCurrent = require('./WaypointSetCurrent.js')
let StreamRate = require('./StreamRate.js')
let ParamPush = require('./ParamPush.js')
let CommandTriggerControl = require('./CommandTriggerControl.js')
let FileRename = require('./FileRename.js')
let CommandVtolTransition = require('./CommandVtolTransition.js')
let ParamSet = require('./ParamSet.js')
let MessageInterval = require('./MessageInterval.js')
let CommandLong = require('./CommandLong.js')
let FileWrite = require('./FileWrite.js')
let WaypointPull = require('./WaypointPull.js')
let FileRemoveDir = require('./FileRemoveDir.js')
let LogRequestEnd = require('./LogRequestEnd.js')
let ParamPull = require('./ParamPull.js')
let WaypointPush = require('./WaypointPush.js')
let CommandInt = require('./CommandInt.js')
let SetMode = require('./SetMode.js')
let CommandTriggerInterval = require('./CommandTriggerInterval.js')
let CommandAck = require('./CommandAck.js')

module.exports = {
  ParamGet: ParamGet,
  FileChecksum: FileChecksum,
  LogRequestList: LogRequestList,
  FileRemove: FileRemove,
  CommandHome: CommandHome,
  VehicleInfoGet: VehicleInfoGet,
  WaypointClear: WaypointClear,
  FileRead: FileRead,
  FileOpen: FileOpen,
  FileClose: FileClose,
  MountConfigure: MountConfigure,
  CommandBool: CommandBool,
  LogRequestData: LogRequestData,
  SetMavFrame: SetMavFrame,
  FileList: FileList,
  FileMakeDir: FileMakeDir,
  FileTruncate: FileTruncate,
  CommandTOL: CommandTOL,
  WaypointSetCurrent: WaypointSetCurrent,
  StreamRate: StreamRate,
  ParamPush: ParamPush,
  CommandTriggerControl: CommandTriggerControl,
  FileRename: FileRename,
  CommandVtolTransition: CommandVtolTransition,
  ParamSet: ParamSet,
  MessageInterval: MessageInterval,
  CommandLong: CommandLong,
  FileWrite: FileWrite,
  WaypointPull: WaypointPull,
  FileRemoveDir: FileRemoveDir,
  LogRequestEnd: LogRequestEnd,
  ParamPull: ParamPull,
  WaypointPush: WaypointPush,
  CommandInt: CommandInt,
  SetMode: SetMode,
  CommandTriggerInterval: CommandTriggerInterval,
  CommandAck: CommandAck,
};
