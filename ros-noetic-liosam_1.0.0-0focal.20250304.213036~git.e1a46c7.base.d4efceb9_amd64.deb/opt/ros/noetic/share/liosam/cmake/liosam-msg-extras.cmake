set(liosam_MESSAGE_FILES "msg/cloud_info.msg")
set(liosam_SERVICE_FILES "")
