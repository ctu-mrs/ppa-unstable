(cl:defpackage liosam-msg
  (:use )
  (:export
   "<CLOUD_INFO>"
   "CLOUD_INFO"
  ))

