
"use strict";

let UavDiagnostics = require('./UavDiagnostics.js');
let FutureTrajectory = require('./FutureTrajectory.js');
let MpcPredictionFullState = require('./MpcPredictionFullState.js');
let FuturePoint = require('./FuturePoint.js');
let MpcTrackerDiagnostics = require('./MpcTrackerDiagnostics.js');
let GimbalState = require('./GimbalState.js');
let GpsInfo = require('./GpsInfo.js');
let GpsData = require('./GpsData.js');
let RtkGps = require('./RtkGps.js');
let RtkFixType = require('./RtkFixType.js');
let LandoffDiagnostics = require('./LandoffDiagnostics.js');
let GazeboSpawnerDiagnostics = require('./GazeboSpawnerDiagnostics.js');
let EstimatorInput = require('./EstimatorInput.js');
let EulerAngles = require('./EulerAngles.js');
let EstimatorDiagnostics = require('./EstimatorDiagnostics.js');
let TrackerCommand = require('./TrackerCommand.js');
let ControllerDiagnostics = require('./ControllerDiagnostics.js');
let TrajectoryReference = require('./TrajectoryReference.js');
let DynamicsConstraints = require('./DynamicsConstraints.js');
let TrackerStatus = require('./TrackerStatus.js');
let GainManagerDiagnostics = require('./GainManagerDiagnostics.js');
let Reference = require('./Reference.js');
let ControlManagerDiagnostics = require('./ControlManagerDiagnostics.js');
let VelocityReference = require('./VelocityReference.js');
let VelocityReferenceStamped = require('./VelocityReferenceStamped.js');
let EstimatorCorrection = require('./EstimatorCorrection.js');
let ReferenceStamped = require('./ReferenceStamped.js');
let ReferenceArray = require('./ReferenceArray.js');
let EstimationDiagnostics = require('./EstimationDiagnostics.js');
let UavManagerDiagnostics = require('./UavManagerDiagnostics.js');
let ControllerStatus = require('./ControllerStatus.js');
let EstimatorOutput = require('./EstimatorOutput.js');
let PathReference = require('./PathReference.js');
let UavState = require('./UavState.js');
let ControlError = require('./ControlError.js');
let ConstraintManagerDiagnostics = require('./ConstraintManagerDiagnostics.js');
let CustomTopic = require('./CustomTopic.js');
let UavStatus = require('./UavStatus.js');
let UavStatusShort = require('./UavStatusShort.js');
let NodeCpuLoad = require('./NodeCpuLoad.js');
let Se3Gains = require('./Se3Gains.js');
let Path = require('./Path.js');
let PathWithVelocity = require('./PathWithVelocity.js');
let ReferenceWithVelocity = require('./ReferenceWithVelocity.js');
let ProfilerUpdate = require('./ProfilerUpdate.js');
let Histogram = require('./Histogram.js');
let ObstacleSectors = require('./ObstacleSectors.js');
let SpeedTrackerCommand = require('./SpeedTrackerCommand.js');
let Float64MultiArrayStamped = require('./Float64MultiArrayStamped.js');
let Float64Stamped = require('./Float64Stamped.js');
let Track = require('./Track.js');
let TrackArrayStamped = require('./TrackArrayStamped.js');
let ImageLabeled = require('./ImageLabeled.js');
let ImageLabeledArray = require('./ImageLabeledArray.js');
let TrackStamped = require('./TrackStamped.js');
let PoseWithCovarianceArrayStamped = require('./PoseWithCovarianceArrayStamped.js');
let PoseWithCovarianceIdentified = require('./PoseWithCovarianceIdentified.js');
let RangeWithCovarianceIdentified = require('./RangeWithCovarianceIdentified.js');
let StringStamped = require('./StringStamped.js');
let Sphere = require('./Sphere.js');
let RangeWithCovarianceArrayStamped = require('./RangeWithCovarianceArrayStamped.js');
let Float64ArrayStamped = require('./Float64ArrayStamped.js');
let Float64 = require('./Float64.js');
let BoolStamped = require('./BoolStamped.js');
let UInt16Stamped = require('./UInt16Stamped.js');
let HwApiVelocityHdgRateCmd = require('./HwApiVelocityHdgRateCmd.js');
let HwApiControlGroupCmd = require('./HwApiControlGroupCmd.js');
let HwApiStatus = require('./HwApiStatus.js');
let HwApiPositionCmd = require('./HwApiPositionCmd.js');
let HwApiAccelerationHdgCmd = require('./HwApiAccelerationHdgCmd.js');
let HwApiVelocityHdgCmd = require('./HwApiVelocityHdgCmd.js');
let HwApiAttitudeRateCmd = require('./HwApiAttitudeRateCmd.js');
let HwApiRcChannels = require('./HwApiRcChannels.js');
let HwApiCapabilities = require('./HwApiCapabilities.js');
let HwApiAttitudeCmd = require('./HwApiAttitudeCmd.js');
let HwApiAccelerationHdgRateCmd = require('./HwApiAccelerationHdgRateCmd.js');
let HwApiAltitude = require('./HwApiAltitude.js');
let HwApiActuatorCmd = require('./HwApiActuatorCmd.js');

module.exports = {
  UavDiagnostics: UavDiagnostics,
  FutureTrajectory: FutureTrajectory,
  MpcPredictionFullState: MpcPredictionFullState,
  FuturePoint: FuturePoint,
  MpcTrackerDiagnostics: MpcTrackerDiagnostics,
  GimbalState: GimbalState,
  GpsInfo: GpsInfo,
  GpsData: GpsData,
  RtkGps: RtkGps,
  RtkFixType: RtkFixType,
  LandoffDiagnostics: LandoffDiagnostics,
  GazeboSpawnerDiagnostics: GazeboSpawnerDiagnostics,
  EstimatorInput: EstimatorInput,
  EulerAngles: EulerAngles,
  EstimatorDiagnostics: EstimatorDiagnostics,
  TrackerCommand: TrackerCommand,
  ControllerDiagnostics: ControllerDiagnostics,
  TrajectoryReference: TrajectoryReference,
  DynamicsConstraints: DynamicsConstraints,
  TrackerStatus: TrackerStatus,
  GainManagerDiagnostics: GainManagerDiagnostics,
  Reference: Reference,
  ControlManagerDiagnostics: ControlManagerDiagnostics,
  VelocityReference: VelocityReference,
  VelocityReferenceStamped: VelocityReferenceStamped,
  EstimatorCorrection: EstimatorCorrection,
  ReferenceStamped: ReferenceStamped,
  ReferenceArray: ReferenceArray,
  EstimationDiagnostics: EstimationDiagnostics,
  UavManagerDiagnostics: UavManagerDiagnostics,
  ControllerStatus: ControllerStatus,
  EstimatorOutput: EstimatorOutput,
  PathReference: PathReference,
  UavState: UavState,
  ControlError: ControlError,
  ConstraintManagerDiagnostics: ConstraintManagerDiagnostics,
  CustomTopic: CustomTopic,
  UavStatus: UavStatus,
  UavStatusShort: UavStatusShort,
  NodeCpuLoad: NodeCpuLoad,
  Se3Gains: Se3Gains,
  Path: Path,
  PathWithVelocity: PathWithVelocity,
  ReferenceWithVelocity: ReferenceWithVelocity,
  ProfilerUpdate: ProfilerUpdate,
  Histogram: Histogram,
  ObstacleSectors: ObstacleSectors,
  SpeedTrackerCommand: SpeedTrackerCommand,
  Float64MultiArrayStamped: Float64MultiArrayStamped,
  Float64Stamped: Float64Stamped,
  Track: Track,
  TrackArrayStamped: TrackArrayStamped,
  ImageLabeled: ImageLabeled,
  ImageLabeledArray: ImageLabeledArray,
  TrackStamped: TrackStamped,
  PoseWithCovarianceArrayStamped: PoseWithCovarianceArrayStamped,
  PoseWithCovarianceIdentified: PoseWithCovarianceIdentified,
  RangeWithCovarianceIdentified: RangeWithCovarianceIdentified,
  StringStamped: StringStamped,
  Sphere: Sphere,
  RangeWithCovarianceArrayStamped: RangeWithCovarianceArrayStamped,
  Float64ArrayStamped: Float64ArrayStamped,
  Float64: Float64,
  BoolStamped: BoolStamped,
  UInt16Stamped: UInt16Stamped,
  HwApiVelocityHdgRateCmd: HwApiVelocityHdgRateCmd,
  HwApiControlGroupCmd: HwApiControlGroupCmd,
  HwApiStatus: HwApiStatus,
  HwApiPositionCmd: HwApiPositionCmd,
  HwApiAccelerationHdgCmd: HwApiAccelerationHdgCmd,
  HwApiVelocityHdgCmd: HwApiVelocityHdgCmd,
  HwApiAttitudeRateCmd: HwApiAttitudeRateCmd,
  HwApiRcChannels: HwApiRcChannels,
  HwApiCapabilities: HwApiCapabilities,
  HwApiAttitudeCmd: HwApiAttitudeCmd,
  HwApiAccelerationHdgRateCmd: HwApiAccelerationHdgRateCmd,
  HwApiAltitude: HwApiAltitude,
  HwApiActuatorCmd: HwApiActuatorCmd,
};
