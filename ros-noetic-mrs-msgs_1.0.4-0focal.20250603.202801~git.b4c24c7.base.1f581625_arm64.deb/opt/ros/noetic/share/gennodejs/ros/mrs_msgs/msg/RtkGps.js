// Auto-generated. Do not edit!

// (in-package mrs_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let GpsData = require('./GpsData.js');
let RtkFixType = require('./RtkFixType.js');
let std_msgs = _finder('std_msgs');
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class RtkGps {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.gps = null;
      this.status = null;
      this.fix_type = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('gps')) {
        this.gps = initObj.gps
      }
      else {
        this.gps = new GpsData();
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = new sensor_msgs.msg.NavSatStatus();
      }
      if (initObj.hasOwnProperty('fix_type')) {
        this.fix_type = initObj.fix_type
      }
      else {
        this.fix_type = new RtkFixType();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RtkGps
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [gps]
    bufferOffset = GpsData.serialize(obj.gps, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = sensor_msgs.msg.NavSatStatus.serialize(obj.status, buffer, bufferOffset);
    // Serialize message field [fix_type]
    bufferOffset = RtkFixType.serialize(obj.fix_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RtkGps
    let len;
    let data = new RtkGps(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [gps]
    data.gps = GpsData.deserialize(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = sensor_msgs.msg.NavSatStatus.deserialize(buffer, bufferOffset);
    // Deserialize message field [fix_type]
    data.fix_type = RtkFixType.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 100;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mrs_msgs/RtkGps';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ceef5bb940703e2da0f6e62a0802eeb7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    mrs_msgs/GpsData gps
    sensor_msgs/NavSatStatus status
    mrs_msgs/RtkFixType fix_type
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: mrs_msgs/GpsData
    float64 latitude
    float64 longitude
    float64 altitude
    float64[9] covariance
    
    ================================================================================
    MSG: sensor_msgs/NavSatStatus
    # Navigation Satellite fix status for any Global Navigation Satellite System
    
    # Whether to output an augmented fix is determined by both the fix
    # type and the last time differential corrections were received.  A
    # fix is valid when status >= STATUS_FIX.
    
    int8 STATUS_NO_FIX =  -1        # unable to fix position
    int8 STATUS_FIX =      0        # unaugmented fix
    int8 STATUS_SBAS_FIX = 1        # with satellite-based augmentation
    int8 STATUS_GBAS_FIX = 2        # with ground-based augmentation
    
    int8 status
    
    # Bits defining which Global Navigation Satellite System signals were
    # used by the receiver.
    
    uint16 SERVICE_GPS =     1
    uint16 SERVICE_GLONASS = 2
    uint16 SERVICE_COMPASS = 4      # includes BeiDou.
    uint16 SERVICE_GALILEO = 8
    
    uint16 service
    
    ================================================================================
    MSG: mrs_msgs/RtkFixType
    uint8 RTK_FIX=5
    uint8 RTK_FLOAT=4
    uint8 UNKNOWN=3
    uint8 DGPS=2
    uint8 SPS=1
    uint8 NO_FIX=0
    uint8 fix_type
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RtkGps(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.gps !== undefined) {
      resolved.gps = GpsData.Resolve(msg.gps)
    }
    else {
      resolved.gps = new GpsData()
    }

    if (msg.status !== undefined) {
      resolved.status = sensor_msgs.msg.NavSatStatus.Resolve(msg.status)
    }
    else {
      resolved.status = new sensor_msgs.msg.NavSatStatus()
    }

    if (msg.fix_type !== undefined) {
      resolved.fix_type = RtkFixType.Resolve(msg.fix_type)
    }
    else {
      resolved.fix_type = new RtkFixType()
    }

    return resolved;
    }
};

module.exports = RtkGps;
