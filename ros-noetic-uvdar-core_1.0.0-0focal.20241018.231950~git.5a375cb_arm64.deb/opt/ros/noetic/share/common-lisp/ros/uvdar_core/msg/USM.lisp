; Auto-generated. Do not edit!


(cl:in-package uvdar_core-msg)


;//! \htmlinclude USM.msg.html

(cl:defclass <USM> (roslisp-msg-protocol:ros-message)
  ((blank_msg
    :reader blank_msg
    :initarg :blank_msg
    :type cl:boolean
    :initform cl:nil)
   (msg_type
    :reader msg_type
    :initarg :msg_type
    :type cl:integer
    :initform 0)
   (payload
    :reader payload
    :initarg :payload
    :type (cl:vector cl:float)
   :initform (cl:make-array 0 :element-type 'cl:float :initial-element 0.0)))
)

(cl:defclass USM (<USM>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <USM>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'USM)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-msg:<USM> is deprecated: use uvdar_core-msg:USM instead.")))

(cl:ensure-generic-function 'blank_msg-val :lambda-list '(m))
(cl:defmethod blank_msg-val ((m <USM>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:blank_msg-val is deprecated.  Use uvdar_core-msg:blank_msg instead.")
  (blank_msg m))

(cl:ensure-generic-function 'msg_type-val :lambda-list '(m))
(cl:defmethod msg_type-val ((m <USM>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:msg_type-val is deprecated.  Use uvdar_core-msg:msg_type instead.")
  (msg_type m))

(cl:ensure-generic-function 'payload-val :lambda-list '(m))
(cl:defmethod payload-val ((m <USM>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:payload-val is deprecated.  Use uvdar_core-msg:payload instead.")
  (payload m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <USM>) ostream)
  "Serializes a message object of type '<USM>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'blank_msg) 1 0)) ostream)
  (cl:let* ((signed (cl:slot-value msg 'msg_type)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'payload))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-single-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)))
   (cl:slot-value msg 'payload))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <USM>) istream)
  "Deserializes a message object of type '<USM>"
    (cl:setf (cl:slot-value msg 'blank_msg) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'msg_type) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'payload) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'payload)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-single-float-bits bits))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<USM>)))
  "Returns string type for a message object of type '<USM>"
  "uvdar_core/USM")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'USM)))
  "Returns string type for a message object of type 'USM"
  "uvdar_core/USM")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<USM>)))
  "Returns md5sum for a message object of type '<USM>"
  "6689f332297817c47d89432ea6a38875")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'USM)))
  "Returns md5sum for a message object of type 'USM"
  "6689f332297817c47d89432ea6a38875")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<USM>)))
  "Returns full string definition for message of type '<USM>"
  (cl:format cl:nil "#Uvdar Swarm Message~%bool blank_msg~%int32 msg_type~%float32[] payload~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'USM)))
  "Returns full string definition for message of type 'USM"
  (cl:format cl:nil "#Uvdar Swarm Message~%bool blank_msg~%int32 msg_type~%float32[] payload~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <USM>))
  (cl:+ 0
     1
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'payload) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <USM>))
  "Converts a ROS message object to a list"
  (cl:list 'USM
    (cl:cons ':blank_msg (blank_msg msg))
    (cl:cons ':msg_type (msg_type msg))
    (cl:cons ':payload (payload msg))
))
