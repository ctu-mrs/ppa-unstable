(cl:in-package uvdar_core-srv)
(cl:export '(VALUE-VAL
          VALUE
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))