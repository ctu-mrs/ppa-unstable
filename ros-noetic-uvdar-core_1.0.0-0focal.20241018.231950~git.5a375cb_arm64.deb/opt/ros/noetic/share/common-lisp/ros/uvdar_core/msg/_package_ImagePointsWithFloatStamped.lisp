(cl:in-package uvdar_core-msg)
(cl:export '(STAMP-VAL
          STAMP
          IMAGE_HEIGHT-VAL
          IMAGE_HEIGHT
          IMAGE_WIDTH-VAL
          IMAGE_WIDTH
          POINTS-VAL
          POINTS
))