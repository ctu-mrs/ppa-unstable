(cl:in-package uvdar_core-msg)
(cl:export '(F1-VAL
          F1
          F2-VAL
          F2
          F3-VAL
          F3
          F4-VAL
          F4
          F5-VAL
          F5
          F6-VAL
          F6
          F7-VAL
          F7
          F8-VAL
          F8
))