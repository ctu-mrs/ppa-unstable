; Auto-generated. Do not edit!


(cl:in-package uvdar_core-msg)


;//! \htmlinclude FrequencySet.msg.html

(cl:defclass <FrequencySet> (roslisp-msg-protocol:ros-message)
  ((f1
    :reader f1
    :initarg :f1
    :type cl:fixnum
    :initform 0)
   (f2
    :reader f2
    :initarg :f2
    :type cl:fixnum
    :initform 0)
   (f3
    :reader f3
    :initarg :f3
    :type cl:fixnum
    :initform 0)
   (f4
    :reader f4
    :initarg :f4
    :type cl:fixnum
    :initform 0)
   (f5
    :reader f5
    :initarg :f5
    :type cl:fixnum
    :initform 0)
   (f6
    :reader f6
    :initarg :f6
    :type cl:fixnum
    :initform 0)
   (f7
    :reader f7
    :initarg :f7
    :type cl:fixnum
    :initform 0)
   (f8
    :reader f8
    :initarg :f8
    :type cl:fixnum
    :initform 0))
)

(cl:defclass FrequencySet (<FrequencySet>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <FrequencySet>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'FrequencySet)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name uvdar_core-msg:<FrequencySet> is deprecated: use uvdar_core-msg:FrequencySet instead.")))

(cl:ensure-generic-function 'f1-val :lambda-list '(m))
(cl:defmethod f1-val ((m <FrequencySet>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:f1-val is deprecated.  Use uvdar_core-msg:f1 instead.")
  (f1 m))

(cl:ensure-generic-function 'f2-val :lambda-list '(m))
(cl:defmethod f2-val ((m <FrequencySet>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:f2-val is deprecated.  Use uvdar_core-msg:f2 instead.")
  (f2 m))

(cl:ensure-generic-function 'f3-val :lambda-list '(m))
(cl:defmethod f3-val ((m <FrequencySet>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:f3-val is deprecated.  Use uvdar_core-msg:f3 instead.")
  (f3 m))

(cl:ensure-generic-function 'f4-val :lambda-list '(m))
(cl:defmethod f4-val ((m <FrequencySet>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:f4-val is deprecated.  Use uvdar_core-msg:f4 instead.")
  (f4 m))

(cl:ensure-generic-function 'f5-val :lambda-list '(m))
(cl:defmethod f5-val ((m <FrequencySet>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:f5-val is deprecated.  Use uvdar_core-msg:f5 instead.")
  (f5 m))

(cl:ensure-generic-function 'f6-val :lambda-list '(m))
(cl:defmethod f6-val ((m <FrequencySet>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:f6-val is deprecated.  Use uvdar_core-msg:f6 instead.")
  (f6 m))

(cl:ensure-generic-function 'f7-val :lambda-list '(m))
(cl:defmethod f7-val ((m <FrequencySet>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:f7-val is deprecated.  Use uvdar_core-msg:f7 instead.")
  (f7 m))

(cl:ensure-generic-function 'f8-val :lambda-list '(m))
(cl:defmethod f8-val ((m <FrequencySet>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader uvdar_core-msg:f8-val is deprecated.  Use uvdar_core-msg:f8 instead.")
  (f8 m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <FrequencySet>) ostream)
  "Serializes a message object of type '<FrequencySet>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f1)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f2)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f3)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f4)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f5)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f6)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f7)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f8)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <FrequencySet>) istream)
  "Deserializes a message object of type '<FrequencySet>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f1)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f2)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f3)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f4)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f5)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f6)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f7)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'f8)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<FrequencySet>)))
  "Returns string type for a message object of type '<FrequencySet>"
  "uvdar_core/FrequencySet")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'FrequencySet)))
  "Returns string type for a message object of type 'FrequencySet"
  "uvdar_core/FrequencySet")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<FrequencySet>)))
  "Returns md5sum for a message object of type '<FrequencySet>"
  "b4ba54bd51af1c63e7f6d0f9d284cf29")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'FrequencySet)))
  "Returns md5sum for a message object of type 'FrequencySet"
  "b4ba54bd51af1c63e7f6d0f9d284cf29")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<FrequencySet>)))
  "Returns full string definition for message of type '<FrequencySet>"
  (cl:format cl:nil "uint8 f1~%uint8 f2~%uint8 f3~%uint8 f4~%uint8 f5~%uint8 f6~%uint8 f7~%uint8 f8~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'FrequencySet)))
  "Returns full string definition for message of type 'FrequencySet"
  (cl:format cl:nil "uint8 f1~%uint8 f2~%uint8 f3~%uint8 f4~%uint8 f5~%uint8 f6~%uint8 f7~%uint8 f8~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <FrequencySet>))
  (cl:+ 0
     1
     1
     1
     1
     1
     1
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <FrequencySet>))
  "Converts a ROS message object to a list"
  (cl:list 'FrequencySet
    (cl:cons ':f1 (f1 msg))
    (cl:cons ':f2 (f2 msg))
    (cl:cons ':f3 (f3 msg))
    (cl:cons ':f4 (f4 msg))
    (cl:cons ':f5 (f5 msg))
    (cl:cons ':f6 (f6 msg))
    (cl:cons ':f7 (f7 msg))
    (cl:cons ':f8 (f8 msg))
))
