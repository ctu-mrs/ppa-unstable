set(mrs_octomap_server_MESSAGE_FILES "msg/PoseWithSize.msg")
set(mrs_octomap_server_SERVICE_FILES "")
