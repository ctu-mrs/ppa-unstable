
"use strict";

let SetOrientation = require('./SetOrientation.js')

module.exports = {
  SetOrientation: SetOrientation,
};
