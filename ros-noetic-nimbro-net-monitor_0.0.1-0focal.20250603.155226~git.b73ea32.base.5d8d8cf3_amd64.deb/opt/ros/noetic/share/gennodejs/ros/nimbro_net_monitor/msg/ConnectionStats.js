// Auto-generated. Do not edit!

// (in-package nimbro_net_monitor.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ConnectionStats {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.topic = null;
      this.local_node = null;
      this.destination = null;
      this.direction = null;
      this.transport = null;
      this.bits_per_second = null;
    }
    else {
      if (initObj.hasOwnProperty('topic')) {
        this.topic = initObj.topic
      }
      else {
        this.topic = '';
      }
      if (initObj.hasOwnProperty('local_node')) {
        this.local_node = initObj.local_node
      }
      else {
        this.local_node = '';
      }
      if (initObj.hasOwnProperty('destination')) {
        this.destination = initObj.destination
      }
      else {
        this.destination = '';
      }
      if (initObj.hasOwnProperty('direction')) {
        this.direction = initObj.direction
      }
      else {
        this.direction = 0;
      }
      if (initObj.hasOwnProperty('transport')) {
        this.transport = initObj.transport
      }
      else {
        this.transport = '';
      }
      if (initObj.hasOwnProperty('bits_per_second')) {
        this.bits_per_second = initObj.bits_per_second
      }
      else {
        this.bits_per_second = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ConnectionStats
    // Serialize message field [topic]
    bufferOffset = _serializer.string(obj.topic, buffer, bufferOffset);
    // Serialize message field [local_node]
    bufferOffset = _serializer.string(obj.local_node, buffer, bufferOffset);
    // Serialize message field [destination]
    bufferOffset = _serializer.string(obj.destination, buffer, bufferOffset);
    // Serialize message field [direction]
    bufferOffset = _serializer.uint8(obj.direction, buffer, bufferOffset);
    // Serialize message field [transport]
    bufferOffset = _serializer.string(obj.transport, buffer, bufferOffset);
    // Serialize message field [bits_per_second]
    bufferOffset = _serializer.uint64(obj.bits_per_second, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ConnectionStats
    let len;
    let data = new ConnectionStats(null);
    // Deserialize message field [topic]
    data.topic = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [local_node]
    data.local_node = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [destination]
    data.destination = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [direction]
    data.direction = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [transport]
    data.transport = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [bits_per_second]
    data.bits_per_second = _deserializer.uint64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.topic);
    length += _getByteLength(object.local_node);
    length += _getByteLength(object.destination);
    length += _getByteLength(object.transport);
    return length + 25;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_net_monitor/ConnectionStats';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b24299a1a38da64ecf65a30e5e6ffb39';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    uint8 DIR_IN = 0
    uint8 DIR_OUT = 1
    
    # Topic name
    string topic
    
    # Local node
    string local_node
    
    # Peer node (the other end)
    # this is a node *name*
    string destination
    
    # See DIR_IN/DIR_OUT
    uint8 direction
    
    # Used transport (e.g. 'TCPROS')
    string transport
    
    # Current bandwidth
    uint64 bits_per_second
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ConnectionStats(null);
    if (msg.topic !== undefined) {
      resolved.topic = msg.topic;
    }
    else {
      resolved.topic = ''
    }

    if (msg.local_node !== undefined) {
      resolved.local_node = msg.local_node;
    }
    else {
      resolved.local_node = ''
    }

    if (msg.destination !== undefined) {
      resolved.destination = msg.destination;
    }
    else {
      resolved.destination = ''
    }

    if (msg.direction !== undefined) {
      resolved.direction = msg.direction;
    }
    else {
      resolved.direction = 0
    }

    if (msg.transport !== undefined) {
      resolved.transport = msg.transport;
    }
    else {
      resolved.transport = ''
    }

    if (msg.bits_per_second !== undefined) {
      resolved.bits_per_second = msg.bits_per_second;
    }
    else {
      resolved.bits_per_second = 0
    }

    return resolved;
    }
};

// Constants for message
ConnectionStats.Constants = {
  DIR_IN: 0,
  DIR_OUT: 1,
}

module.exports = ConnectionStats;
