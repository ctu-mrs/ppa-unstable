
"use strict";

let UavDiagnostics = require('./UavDiagnostics.js');
let FuturePoint = require('./FuturePoint.js');
let MpcTrackerDiagnostics = require('./MpcTrackerDiagnostics.js');
let MpcPredictionFullState = require('./MpcPredictionFullState.js');
let FutureTrajectory = require('./FutureTrajectory.js');
let GimbalState = require('./GimbalState.js');
let RtkGps = require('./RtkGps.js');
let RtkFixType = require('./RtkFixType.js');
let GpsData = require('./GpsData.js');
let GpsInfo = require('./GpsInfo.js');
let LandoffDiagnostics = require('./LandoffDiagnostics.js');
let GazeboSpawnerDiagnostics = require('./GazeboSpawnerDiagnostics.js');
let TrackerStatus = require('./TrackerStatus.js');
let VelocityReferenceStamped = require('./VelocityReferenceStamped.js');
let ReferenceArray = require('./ReferenceArray.js');
let ControlManagerDiagnostics = require('./ControlManagerDiagnostics.js');
let TrackerCommand = require('./TrackerCommand.js');
let VelocityReference = require('./VelocityReference.js');
let ControlError = require('./ControlError.js');
let GainManagerDiagnostics = require('./GainManagerDiagnostics.js');
let UavState = require('./UavState.js');
let UavManagerDiagnostics = require('./UavManagerDiagnostics.js');
let ControllerDiagnostics = require('./ControllerDiagnostics.js');
let ConstraintManagerDiagnostics = require('./ConstraintManagerDiagnostics.js');
let EstimatorOutput = require('./EstimatorOutput.js');
let EstimatorCorrection = require('./EstimatorCorrection.js');
let ReferenceStamped = require('./ReferenceStamped.js');
let ControllerStatus = require('./ControllerStatus.js');
let Reference = require('./Reference.js');
let TrajectoryReference = require('./TrajectoryReference.js');
let EstimatorDiagnostics = require('./EstimatorDiagnostics.js');
let DynamicsConstraints = require('./DynamicsConstraints.js');
let PathReference = require('./PathReference.js');
let EstimationDiagnostics = require('./EstimationDiagnostics.js');
let EstimatorInput = require('./EstimatorInput.js');
let EulerAngles = require('./EulerAngles.js');
let CustomTopic = require('./CustomTopic.js');
let NodeCpuLoad = require('./NodeCpuLoad.js');
let UavStatusShort = require('./UavStatusShort.js');
let UavStatus = require('./UavStatus.js');
let Se3Gains = require('./Se3Gains.js');
let Path = require('./Path.js');
let ReferenceWithVelocity = require('./ReferenceWithVelocity.js');
let PathWithVelocity = require('./PathWithVelocity.js');
let ProfilerUpdate = require('./ProfilerUpdate.js');
let ObstacleSectors = require('./ObstacleSectors.js');
let Histogram = require('./Histogram.js');
let SpeedTrackerCommand = require('./SpeedTrackerCommand.js');
let Sphere = require('./Sphere.js');
let ImageLabeledArray = require('./ImageLabeledArray.js');
let Float64MultiArrayStamped = require('./Float64MultiArrayStamped.js');
let Float64ArrayStamped = require('./Float64ArrayStamped.js');
let TrackStamped = require('./TrackStamped.js');
let Float64Stamped = require('./Float64Stamped.js');
let TrackArrayStamped = require('./TrackArrayStamped.js');
let Float64 = require('./Float64.js');
let PoseWithCovarianceArrayStamped = require('./PoseWithCovarianceArrayStamped.js');
let PoseWithCovarianceIdentified = require('./PoseWithCovarianceIdentified.js');
let RangeWithCovarianceArrayStamped = require('./RangeWithCovarianceArrayStamped.js');
let RangeWithCovarianceIdentified = require('./RangeWithCovarianceIdentified.js');
let ImageLabeled = require('./ImageLabeled.js');
let StringStamped = require('./StringStamped.js');
let Track = require('./Track.js');
let BoolStamped = require('./BoolStamped.js');
let UInt16Stamped = require('./UInt16Stamped.js');
let HwApiControlGroupCmd = require('./HwApiControlGroupCmd.js');
let HwApiAccelerationHdgRateCmd = require('./HwApiAccelerationHdgRateCmd.js');
let HwApiRcChannels = require('./HwApiRcChannels.js');
let HwApiStatus = require('./HwApiStatus.js');
let HwApiAltitude = require('./HwApiAltitude.js');
let HwApiCapabilities = require('./HwApiCapabilities.js');
let HwApiVelocityHdgCmd = require('./HwApiVelocityHdgCmd.js');
let HwApiActuatorCmd = require('./HwApiActuatorCmd.js');
let HwApiAccelerationHdgCmd = require('./HwApiAccelerationHdgCmd.js');
let HwApiVelocityHdgRateCmd = require('./HwApiVelocityHdgRateCmd.js');
let HwApiAttitudeRateCmd = require('./HwApiAttitudeRateCmd.js');
let HwApiPositionCmd = require('./HwApiPositionCmd.js');
let HwApiAttitudeCmd = require('./HwApiAttitudeCmd.js');

module.exports = {
  UavDiagnostics: UavDiagnostics,
  FuturePoint: FuturePoint,
  MpcTrackerDiagnostics: MpcTrackerDiagnostics,
  MpcPredictionFullState: MpcPredictionFullState,
  FutureTrajectory: FutureTrajectory,
  GimbalState: GimbalState,
  RtkGps: RtkGps,
  RtkFixType: RtkFixType,
  GpsData: GpsData,
  GpsInfo: GpsInfo,
  LandoffDiagnostics: LandoffDiagnostics,
  GazeboSpawnerDiagnostics: GazeboSpawnerDiagnostics,
  TrackerStatus: TrackerStatus,
  VelocityReferenceStamped: VelocityReferenceStamped,
  ReferenceArray: ReferenceArray,
  ControlManagerDiagnostics: ControlManagerDiagnostics,
  TrackerCommand: TrackerCommand,
  VelocityReference: VelocityReference,
  ControlError: ControlError,
  GainManagerDiagnostics: GainManagerDiagnostics,
  UavState: UavState,
  UavManagerDiagnostics: UavManagerDiagnostics,
  ControllerDiagnostics: ControllerDiagnostics,
  ConstraintManagerDiagnostics: ConstraintManagerDiagnostics,
  EstimatorOutput: EstimatorOutput,
  EstimatorCorrection: EstimatorCorrection,
  ReferenceStamped: ReferenceStamped,
  ControllerStatus: ControllerStatus,
  Reference: Reference,
  TrajectoryReference: TrajectoryReference,
  EstimatorDiagnostics: EstimatorDiagnostics,
  DynamicsConstraints: DynamicsConstraints,
  PathReference: PathReference,
  EstimationDiagnostics: EstimationDiagnostics,
  EstimatorInput: EstimatorInput,
  EulerAngles: EulerAngles,
  CustomTopic: CustomTopic,
  NodeCpuLoad: NodeCpuLoad,
  UavStatusShort: UavStatusShort,
  UavStatus: UavStatus,
  Se3Gains: Se3Gains,
  Path: Path,
  ReferenceWithVelocity: ReferenceWithVelocity,
  PathWithVelocity: PathWithVelocity,
  ProfilerUpdate: ProfilerUpdate,
  ObstacleSectors: ObstacleSectors,
  Histogram: Histogram,
  SpeedTrackerCommand: SpeedTrackerCommand,
  Sphere: Sphere,
  ImageLabeledArray: ImageLabeledArray,
  Float64MultiArrayStamped: Float64MultiArrayStamped,
  Float64ArrayStamped: Float64ArrayStamped,
  TrackStamped: TrackStamped,
  Float64Stamped: Float64Stamped,
  TrackArrayStamped: TrackArrayStamped,
  Float64: Float64,
  PoseWithCovarianceArrayStamped: PoseWithCovarianceArrayStamped,
  PoseWithCovarianceIdentified: PoseWithCovarianceIdentified,
  RangeWithCovarianceArrayStamped: RangeWithCovarianceArrayStamped,
  RangeWithCovarianceIdentified: RangeWithCovarianceIdentified,
  ImageLabeled: ImageLabeled,
  StringStamped: StringStamped,
  Track: Track,
  BoolStamped: BoolStamped,
  UInt16Stamped: UInt16Stamped,
  HwApiControlGroupCmd: HwApiControlGroupCmd,
  HwApiAccelerationHdgRateCmd: HwApiAccelerationHdgRateCmd,
  HwApiRcChannels: HwApiRcChannels,
  HwApiStatus: HwApiStatus,
  HwApiAltitude: HwApiAltitude,
  HwApiCapabilities: HwApiCapabilities,
  HwApiVelocityHdgCmd: HwApiVelocityHdgCmd,
  HwApiActuatorCmd: HwApiActuatorCmd,
  HwApiAccelerationHdgCmd: HwApiAccelerationHdgCmd,
  HwApiVelocityHdgRateCmd: HwApiVelocityHdgRateCmd,
  HwApiAttitudeRateCmd: HwApiAttitudeRateCmd,
  HwApiPositionCmd: HwApiPositionCmd,
  HwApiAttitudeCmd: HwApiAttitudeCmd,
};
