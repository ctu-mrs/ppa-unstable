; Auto-generated. Do not edit!


(cl:in-package mrs_msgs-srv)


;//! \htmlinclude TransformReferenceArraySrv-request.msg.html

(cl:defclass <TransformReferenceArraySrv-request> (roslisp-msg-protocol:ros-message)
  ((to_frame_id
    :reader to_frame_id
    :initarg :to_frame_id
    :type cl:string
    :initform "")
   (array
    :reader array
    :initarg :array
    :type mrs_msgs-msg:ReferenceArray
    :initform (cl:make-instance 'mrs_msgs-msg:ReferenceArray)))
)

(cl:defclass TransformReferenceArraySrv-request (<TransformReferenceArraySrv-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TransformReferenceArraySrv-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TransformReferenceArraySrv-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_msgs-srv:<TransformReferenceArraySrv-request> is deprecated: use mrs_msgs-srv:TransformReferenceArraySrv-request instead.")))

(cl:ensure-generic-function 'to_frame_id-val :lambda-list '(m))
(cl:defmethod to_frame_id-val ((m <TransformReferenceArraySrv-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-srv:to_frame_id-val is deprecated.  Use mrs_msgs-srv:to_frame_id instead.")
  (to_frame_id m))

(cl:ensure-generic-function 'array-val :lambda-list '(m))
(cl:defmethod array-val ((m <TransformReferenceArraySrv-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-srv:array-val is deprecated.  Use mrs_msgs-srv:array instead.")
  (array m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TransformReferenceArraySrv-request>) ostream)
  "Serializes a message object of type '<TransformReferenceArraySrv-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'to_frame_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'to_frame_id))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'array) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TransformReferenceArraySrv-request>) istream)
  "Deserializes a message object of type '<TransformReferenceArraySrv-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'to_frame_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'to_frame_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'array) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TransformReferenceArraySrv-request>)))
  "Returns string type for a service object of type '<TransformReferenceArraySrv-request>"
  "mrs_msgs/TransformReferenceArraySrvRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TransformReferenceArraySrv-request)))
  "Returns string type for a service object of type 'TransformReferenceArraySrv-request"
  "mrs_msgs/TransformReferenceArraySrvRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TransformReferenceArraySrv-request>)))
  "Returns md5sum for a message object of type '<TransformReferenceArraySrv-request>"
  "81cada64938c0b33fc0638175fb06137")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TransformReferenceArraySrv-request)))
  "Returns md5sum for a message object of type 'TransformReferenceArraySrv-request"
  "81cada64938c0b33fc0638175fb06137")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TransformReferenceArraySrv-request>)))
  "Returns full string definition for message of type '<TransformReferenceArraySrv-request>"
  (cl:format cl:nil "string to_frame_id~%mrs_msgs/ReferenceArray array~%~%================================================================================~%MSG: mrs_msgs/ReferenceArray~%# A list of references.~%~%std_msgs/Header header~%mrs_msgs/Reference[] array~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: mrs_msgs/Reference~%# This message defines a control reference with a Position+Heading.~%~%geometry_msgs/Point position~%~%# Heading is atan2() of XY-world projection of the UAV's body X-axis.~%float64 heading~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TransformReferenceArraySrv-request)))
  "Returns full string definition for message of type 'TransformReferenceArraySrv-request"
  (cl:format cl:nil "string to_frame_id~%mrs_msgs/ReferenceArray array~%~%================================================================================~%MSG: mrs_msgs/ReferenceArray~%# A list of references.~%~%std_msgs/Header header~%mrs_msgs/Reference[] array~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: mrs_msgs/Reference~%# This message defines a control reference with a Position+Heading.~%~%geometry_msgs/Point position~%~%# Heading is atan2() of XY-world projection of the UAV's body X-axis.~%float64 heading~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TransformReferenceArraySrv-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'to_frame_id))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'array))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TransformReferenceArraySrv-request>))
  "Converts a ROS message object to a list"
  (cl:list 'TransformReferenceArraySrv-request
    (cl:cons ':to_frame_id (to_frame_id msg))
    (cl:cons ':array (array msg))
))
;//! \htmlinclude TransformReferenceArraySrv-response.msg.html

(cl:defclass <TransformReferenceArraySrv-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform "")
   (array
    :reader array
    :initarg :array
    :type mrs_msgs-msg:ReferenceArray
    :initform (cl:make-instance 'mrs_msgs-msg:ReferenceArray)))
)

(cl:defclass TransformReferenceArraySrv-response (<TransformReferenceArraySrv-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TransformReferenceArraySrv-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TransformReferenceArraySrv-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name mrs_msgs-srv:<TransformReferenceArraySrv-response> is deprecated: use mrs_msgs-srv:TransformReferenceArraySrv-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <TransformReferenceArraySrv-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-srv:success-val is deprecated.  Use mrs_msgs-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <TransformReferenceArraySrv-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-srv:message-val is deprecated.  Use mrs_msgs-srv:message instead.")
  (message m))

(cl:ensure-generic-function 'array-val :lambda-list '(m))
(cl:defmethod array-val ((m <TransformReferenceArraySrv-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader mrs_msgs-srv:array-val is deprecated.  Use mrs_msgs-srv:array instead.")
  (array m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TransformReferenceArraySrv-response>) ostream)
  "Serializes a message object of type '<TransformReferenceArraySrv-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'array) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TransformReferenceArraySrv-response>) istream)
  "Deserializes a message object of type '<TransformReferenceArraySrv-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'array) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TransformReferenceArraySrv-response>)))
  "Returns string type for a service object of type '<TransformReferenceArraySrv-response>"
  "mrs_msgs/TransformReferenceArraySrvResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TransformReferenceArraySrv-response)))
  "Returns string type for a service object of type 'TransformReferenceArraySrv-response"
  "mrs_msgs/TransformReferenceArraySrvResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TransformReferenceArraySrv-response>)))
  "Returns md5sum for a message object of type '<TransformReferenceArraySrv-response>"
  "81cada64938c0b33fc0638175fb06137")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TransformReferenceArraySrv-response)))
  "Returns md5sum for a message object of type 'TransformReferenceArraySrv-response"
  "81cada64938c0b33fc0638175fb06137")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TransformReferenceArraySrv-response>)))
  "Returns full string definition for message of type '<TransformReferenceArraySrv-response>"
  (cl:format cl:nil "bool success~%string message~%mrs_msgs/ReferenceArray array~%~%~%================================================================================~%MSG: mrs_msgs/ReferenceArray~%# A list of references.~%~%std_msgs/Header header~%mrs_msgs/Reference[] array~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: mrs_msgs/Reference~%# This message defines a control reference with a Position+Heading.~%~%geometry_msgs/Point position~%~%# Heading is atan2() of XY-world projection of the UAV's body X-axis.~%float64 heading~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TransformReferenceArraySrv-response)))
  "Returns full string definition for message of type 'TransformReferenceArraySrv-response"
  (cl:format cl:nil "bool success~%string message~%mrs_msgs/ReferenceArray array~%~%~%================================================================================~%MSG: mrs_msgs/ReferenceArray~%# A list of references.~%~%std_msgs/Header header~%mrs_msgs/Reference[] array~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: mrs_msgs/Reference~%# This message defines a control reference with a Position+Heading.~%~%geometry_msgs/Point position~%~%# Heading is atan2() of XY-world projection of the UAV's body X-axis.~%float64 heading~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TransformReferenceArraySrv-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'array))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TransformReferenceArraySrv-response>))
  "Converts a ROS message object to a list"
  (cl:list 'TransformReferenceArraySrv-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
    (cl:cons ':array (array msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'TransformReferenceArraySrv)))
  'TransformReferenceArraySrv-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'TransformReferenceArraySrv)))
  'TransformReferenceArraySrv-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TransformReferenceArraySrv)))
  "Returns string type for a service object of type '<TransformReferenceArraySrv>"
  "mrs_msgs/TransformReferenceArraySrv")