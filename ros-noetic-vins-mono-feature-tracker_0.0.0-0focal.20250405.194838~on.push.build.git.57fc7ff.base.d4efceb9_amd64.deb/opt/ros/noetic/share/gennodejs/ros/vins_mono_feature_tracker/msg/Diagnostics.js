// Auto-generated. Do not edit!

// (in-package vins_mono_feature_tracker.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Diagnostics {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.t_clahe = null;
      this.t_optical_flow = null;
      this.t_mask = null;
      this.t_ransac = null;
      this.t_detect_features = null;
      this.t_add_features = null;
      this.t_undistort = null;
      this.t_publish = null;
      this.t_total_feature_tracker = null;
      this.n_pts_tracked = null;
      this.n_pts_after_ransac = null;
      this.n_pts_added = null;
      this.n_pts_final = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('t_clahe')) {
        this.t_clahe = initObj.t_clahe
      }
      else {
        this.t_clahe = [];
      }
      if (initObj.hasOwnProperty('t_optical_flow')) {
        this.t_optical_flow = initObj.t_optical_flow
      }
      else {
        this.t_optical_flow = [];
      }
      if (initObj.hasOwnProperty('t_mask')) {
        this.t_mask = initObj.t_mask
      }
      else {
        this.t_mask = [];
      }
      if (initObj.hasOwnProperty('t_ransac')) {
        this.t_ransac = initObj.t_ransac
      }
      else {
        this.t_ransac = [];
      }
      if (initObj.hasOwnProperty('t_detect_features')) {
        this.t_detect_features = initObj.t_detect_features
      }
      else {
        this.t_detect_features = [];
      }
      if (initObj.hasOwnProperty('t_add_features')) {
        this.t_add_features = initObj.t_add_features
      }
      else {
        this.t_add_features = [];
      }
      if (initObj.hasOwnProperty('t_undistort')) {
        this.t_undistort = initObj.t_undistort
      }
      else {
        this.t_undistort = [];
      }
      if (initObj.hasOwnProperty('t_publish')) {
        this.t_publish = initObj.t_publish
      }
      else {
        this.t_publish = 0.0;
      }
      if (initObj.hasOwnProperty('t_total_feature_tracker')) {
        this.t_total_feature_tracker = initObj.t_total_feature_tracker
      }
      else {
        this.t_total_feature_tracker = 0.0;
      }
      if (initObj.hasOwnProperty('n_pts_tracked')) {
        this.n_pts_tracked = initObj.n_pts_tracked
      }
      else {
        this.n_pts_tracked = [];
      }
      if (initObj.hasOwnProperty('n_pts_after_ransac')) {
        this.n_pts_after_ransac = initObj.n_pts_after_ransac
      }
      else {
        this.n_pts_after_ransac = [];
      }
      if (initObj.hasOwnProperty('n_pts_added')) {
        this.n_pts_added = initObj.n_pts_added
      }
      else {
        this.n_pts_added = [];
      }
      if (initObj.hasOwnProperty('n_pts_final')) {
        this.n_pts_final = initObj.n_pts_final
      }
      else {
        this.n_pts_final = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Diagnostics
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [t_clahe]
    bufferOffset = _arraySerializer.float64(obj.t_clahe, buffer, bufferOffset, null);
    // Serialize message field [t_optical_flow]
    bufferOffset = _arraySerializer.float64(obj.t_optical_flow, buffer, bufferOffset, null);
    // Serialize message field [t_mask]
    bufferOffset = _arraySerializer.float64(obj.t_mask, buffer, bufferOffset, null);
    // Serialize message field [t_ransac]
    bufferOffset = _arraySerializer.float64(obj.t_ransac, buffer, bufferOffset, null);
    // Serialize message field [t_detect_features]
    bufferOffset = _arraySerializer.float64(obj.t_detect_features, buffer, bufferOffset, null);
    // Serialize message field [t_add_features]
    bufferOffset = _arraySerializer.float64(obj.t_add_features, buffer, bufferOffset, null);
    // Serialize message field [t_undistort]
    bufferOffset = _arraySerializer.float64(obj.t_undistort, buffer, bufferOffset, null);
    // Serialize message field [t_publish]
    bufferOffset = _serializer.float64(obj.t_publish, buffer, bufferOffset);
    // Serialize message field [t_total_feature_tracker]
    bufferOffset = _serializer.float64(obj.t_total_feature_tracker, buffer, bufferOffset);
    // Serialize message field [n_pts_tracked]
    bufferOffset = _arraySerializer.int32(obj.n_pts_tracked, buffer, bufferOffset, null);
    // Serialize message field [n_pts_after_ransac]
    bufferOffset = _arraySerializer.int32(obj.n_pts_after_ransac, buffer, bufferOffset, null);
    // Serialize message field [n_pts_added]
    bufferOffset = _arraySerializer.int32(obj.n_pts_added, buffer, bufferOffset, null);
    // Serialize message field [n_pts_final]
    bufferOffset = _arraySerializer.int32(obj.n_pts_final, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Diagnostics
    let len;
    let data = new Diagnostics(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [t_clahe]
    data.t_clahe = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [t_optical_flow]
    data.t_optical_flow = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [t_mask]
    data.t_mask = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [t_ransac]
    data.t_ransac = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [t_detect_features]
    data.t_detect_features = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [t_add_features]
    data.t_add_features = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [t_undistort]
    data.t_undistort = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [t_publish]
    data.t_publish = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [t_total_feature_tracker]
    data.t_total_feature_tracker = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [n_pts_tracked]
    data.n_pts_tracked = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [n_pts_after_ransac]
    data.n_pts_after_ransac = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [n_pts_added]
    data.n_pts_added = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [n_pts_final]
    data.n_pts_final = _arrayDeserializer.int32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += 8 * object.t_clahe.length;
    length += 8 * object.t_optical_flow.length;
    length += 8 * object.t_mask.length;
    length += 8 * object.t_ransac.length;
    length += 8 * object.t_detect_features.length;
    length += 8 * object.t_add_features.length;
    length += 8 * object.t_undistort.length;
    length += 4 * object.n_pts_tracked.length;
    length += 4 * object.n_pts_after_ransac.length;
    length += 4 * object.n_pts_added.length;
    length += 4 * object.n_pts_final.length;
    return length + 60;
  }

  static datatype() {
    // Returns string type for a message object
    return 'vins_mono_feature_tracker/Diagnostics';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fd491fae496542137bf49e20ae1c2efa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    float64[] t_clahe
    float64[] t_optical_flow
    float64[] t_mask
    float64[] t_ransac
    float64[] t_detect_features
    float64[] t_add_features
    float64[] t_undistort
    
    float64 t_publish
    float64 t_total_feature_tracker
    
    int32[] n_pts_tracked
    int32[] n_pts_after_ransac
    int32[] n_pts_added
    int32[] n_pts_final
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Diagnostics(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.t_clahe !== undefined) {
      resolved.t_clahe = msg.t_clahe;
    }
    else {
      resolved.t_clahe = []
    }

    if (msg.t_optical_flow !== undefined) {
      resolved.t_optical_flow = msg.t_optical_flow;
    }
    else {
      resolved.t_optical_flow = []
    }

    if (msg.t_mask !== undefined) {
      resolved.t_mask = msg.t_mask;
    }
    else {
      resolved.t_mask = []
    }

    if (msg.t_ransac !== undefined) {
      resolved.t_ransac = msg.t_ransac;
    }
    else {
      resolved.t_ransac = []
    }

    if (msg.t_detect_features !== undefined) {
      resolved.t_detect_features = msg.t_detect_features;
    }
    else {
      resolved.t_detect_features = []
    }

    if (msg.t_add_features !== undefined) {
      resolved.t_add_features = msg.t_add_features;
    }
    else {
      resolved.t_add_features = []
    }

    if (msg.t_undistort !== undefined) {
      resolved.t_undistort = msg.t_undistort;
    }
    else {
      resolved.t_undistort = []
    }

    if (msg.t_publish !== undefined) {
      resolved.t_publish = msg.t_publish;
    }
    else {
      resolved.t_publish = 0.0
    }

    if (msg.t_total_feature_tracker !== undefined) {
      resolved.t_total_feature_tracker = msg.t_total_feature_tracker;
    }
    else {
      resolved.t_total_feature_tracker = 0.0
    }

    if (msg.n_pts_tracked !== undefined) {
      resolved.n_pts_tracked = msg.n_pts_tracked;
    }
    else {
      resolved.n_pts_tracked = []
    }

    if (msg.n_pts_after_ransac !== undefined) {
      resolved.n_pts_after_ransac = msg.n_pts_after_ransac;
    }
    else {
      resolved.n_pts_after_ransac = []
    }

    if (msg.n_pts_added !== undefined) {
      resolved.n_pts_added = msg.n_pts_added;
    }
    else {
      resolved.n_pts_added = []
    }

    if (msg.n_pts_final !== undefined) {
      resolved.n_pts_final = msg.n_pts_final;
    }
    else {
      resolved.n_pts_final = []
    }

    return resolved;
    }
};

module.exports = Diagnostics;
