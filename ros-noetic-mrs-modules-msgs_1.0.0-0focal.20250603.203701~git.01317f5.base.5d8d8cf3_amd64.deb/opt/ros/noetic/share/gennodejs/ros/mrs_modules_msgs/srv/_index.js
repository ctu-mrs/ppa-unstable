
"use strict";

let SetServo = require('./SetServo.js')
let SetTrigger = require('./SetTrigger.js')

module.exports = {
  SetServo: SetServo,
  SetTrigger: SetTrigger,
};
