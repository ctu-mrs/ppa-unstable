(cl:in-package nimbro_topic_transport-msg)
(cl:export '(TYPE-VAL
          TYPE
          FLAGS-VAL
          FLAGS
          MD5-VAL
          MD5
          DATA-VAL
          DATA
))