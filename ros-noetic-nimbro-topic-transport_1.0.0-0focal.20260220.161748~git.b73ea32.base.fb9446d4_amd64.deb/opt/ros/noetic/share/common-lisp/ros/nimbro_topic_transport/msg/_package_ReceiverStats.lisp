(cl:in-package nimbro_topic_transport-msg)
(cl:export '(HEADER-VAL
          HEADER
          NODE-VAL
          NODE
          PROTOCOL-VAL
          PROTOCOL
          LABEL-VAL
          LABEL
          HOST-VAL
          HOST
          REMOTE-VAL
          REMOTE
          LOCAL_PORT-VAL
          LOCAL_PORT
          REMOTE_PORT-VAL
          REMOTE_PORT
          FEC-VAL
          FEC
          BANDWIDTH-VAL
          BANDWIDTH
          DROP_RATE-VAL
          DROP_RATE
))