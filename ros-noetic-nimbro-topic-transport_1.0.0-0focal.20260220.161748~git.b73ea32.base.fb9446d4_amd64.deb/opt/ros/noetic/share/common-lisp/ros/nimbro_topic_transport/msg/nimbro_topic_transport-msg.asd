
(cl:in-package :asdf)

(defsystem "nimbro_topic_transport-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :std_msgs-msg
)
  :components ((:file "_package")
    (:file "CompressedMsg" :depends-on ("_package_CompressedMsg"))
    (:file "_package_CompressedMsg" :depends-on ("_package"))
    (:file "ReceiverStats" :depends-on ("_package_ReceiverStats"))
    (:file "_package_ReceiverStats" :depends-on ("_package"))
    (:file "SenderStats" :depends-on ("_package_SenderStats"))
    (:file "_package_SenderStats" :depends-on ("_package"))
    (:file "TopicBandwidth" :depends-on ("_package_TopicBandwidth"))
    (:file "_package_TopicBandwidth" :depends-on ("_package"))
  ))