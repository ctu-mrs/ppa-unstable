(cl:in-package nimbro_topic_transport-msg)
(cl:export '(NAME-VAL
          NAME
          BANDWIDTH-VAL
          BANDWIDTH
))