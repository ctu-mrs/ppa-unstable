; Auto-generated. Do not edit!


(cl:in-package nimbro_topic_transport-msg)


;//! \htmlinclude SenderStats.msg.html

(cl:defclass <SenderStats> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (node
    :reader node
    :initarg :node
    :type cl:string
    :initform "")
   (protocol
    :reader protocol
    :initarg :protocol
    :type cl:string
    :initform "")
   (label
    :reader label
    :initarg :label
    :type cl:string
    :initform "")
   (host
    :reader host
    :initarg :host
    :type cl:string
    :initform "")
   (destination
    :reader destination
    :initarg :destination
    :type cl:string
    :initform "")
   (destination_port
    :reader destination_port
    :initarg :destination_port
    :type cl:fixnum
    :initform 0)
   (source_port
    :reader source_port
    :initarg :source_port
    :type cl:fixnum
    :initform 0)
   (fec
    :reader fec
    :initarg :fec
    :type cl:boolean
    :initform cl:nil)
   (bandwidth
    :reader bandwidth
    :initarg :bandwidth
    :type cl:float
    :initform 0.0)
   (topics
    :reader topics
    :initarg :topics
    :type (cl:vector nimbro_topic_transport-msg:TopicBandwidth)
   :initform (cl:make-array 0 :element-type 'nimbro_topic_transport-msg:TopicBandwidth :initial-element (cl:make-instance 'nimbro_topic_transport-msg:TopicBandwidth))))
)

(cl:defclass SenderStats (<SenderStats>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SenderStats>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SenderStats)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nimbro_topic_transport-msg:<SenderStats> is deprecated: use nimbro_topic_transport-msg:SenderStats instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:header-val is deprecated.  Use nimbro_topic_transport-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'node-val :lambda-list '(m))
(cl:defmethod node-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:node-val is deprecated.  Use nimbro_topic_transport-msg:node instead.")
  (node m))

(cl:ensure-generic-function 'protocol-val :lambda-list '(m))
(cl:defmethod protocol-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:protocol-val is deprecated.  Use nimbro_topic_transport-msg:protocol instead.")
  (protocol m))

(cl:ensure-generic-function 'label-val :lambda-list '(m))
(cl:defmethod label-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:label-val is deprecated.  Use nimbro_topic_transport-msg:label instead.")
  (label m))

(cl:ensure-generic-function 'host-val :lambda-list '(m))
(cl:defmethod host-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:host-val is deprecated.  Use nimbro_topic_transport-msg:host instead.")
  (host m))

(cl:ensure-generic-function 'destination-val :lambda-list '(m))
(cl:defmethod destination-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:destination-val is deprecated.  Use nimbro_topic_transport-msg:destination instead.")
  (destination m))

(cl:ensure-generic-function 'destination_port-val :lambda-list '(m))
(cl:defmethod destination_port-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:destination_port-val is deprecated.  Use nimbro_topic_transport-msg:destination_port instead.")
  (destination_port m))

(cl:ensure-generic-function 'source_port-val :lambda-list '(m))
(cl:defmethod source_port-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:source_port-val is deprecated.  Use nimbro_topic_transport-msg:source_port instead.")
  (source_port m))

(cl:ensure-generic-function 'fec-val :lambda-list '(m))
(cl:defmethod fec-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:fec-val is deprecated.  Use nimbro_topic_transport-msg:fec instead.")
  (fec m))

(cl:ensure-generic-function 'bandwidth-val :lambda-list '(m))
(cl:defmethod bandwidth-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:bandwidth-val is deprecated.  Use nimbro_topic_transport-msg:bandwidth instead.")
  (bandwidth m))

(cl:ensure-generic-function 'topics-val :lambda-list '(m))
(cl:defmethod topics-val ((m <SenderStats>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nimbro_topic_transport-msg:topics-val is deprecated.  Use nimbro_topic_transport-msg:topics instead.")
  (topics m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SenderStats>) ostream)
  "Serializes a message object of type '<SenderStats>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'node))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'node))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'protocol))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'protocol))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'label))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'label))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'host))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'host))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'destination))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'destination))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'destination_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'destination_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'source_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'source_port)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'fec) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'bandwidth))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'topics))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'topics))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SenderStats>) istream)
  "Deserializes a message object of type '<SenderStats>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'node) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'node) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'protocol) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'protocol) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'label) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'label) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'host) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'host) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'destination) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'destination) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'destination_port)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'destination_port)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'source_port)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'source_port)) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'fec) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'bandwidth) (roslisp-utils:decode-single-float-bits bits)))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'topics) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'topics)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'nimbro_topic_transport-msg:TopicBandwidth))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SenderStats>)))
  "Returns string type for a message object of type '<SenderStats>"
  "nimbro_topic_transport/SenderStats")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SenderStats)))
  "Returns string type for a message object of type 'SenderStats"
  "nimbro_topic_transport/SenderStats")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SenderStats>)))
  "Returns md5sum for a message object of type '<SenderStats>"
  "785e5b5b423320e1379bc0c4ba6dbaa3")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SenderStats)))
  "Returns md5sum for a message object of type 'SenderStats"
  "785e5b5b423320e1379bc0c4ba6dbaa3")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SenderStats>)))
  "Returns full string definition for message of type '<SenderStats>"
  (cl:format cl:nil "Header header~%~%# Node name~%string node~%~%# Protocol (\"TCP\" or \"UDP\")~%string protocol~%~%# Connection label~%string label~%~%# Local hostname~%string host~%~%# Destination address~%string destination~%~%# Destination port~%uint16 destination_port~%~%# Source port~%uint16 source_port~%~%# Is Forward Error Correction enabled?~%bool fec~%~%# Bandwidth in bit/s~%float32 bandwidth~%~%# Topic specific bandwidth~%TopicBandwidth[] topics~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: nimbro_topic_transport/TopicBandwidth~%# Topic name~%string name~%# Bandwidth~%float32 bandwidth~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SenderStats)))
  "Returns full string definition for message of type 'SenderStats"
  (cl:format cl:nil "Header header~%~%# Node name~%string node~%~%# Protocol (\"TCP\" or \"UDP\")~%string protocol~%~%# Connection label~%string label~%~%# Local hostname~%string host~%~%# Destination address~%string destination~%~%# Destination port~%uint16 destination_port~%~%# Source port~%uint16 source_port~%~%# Is Forward Error Correction enabled?~%bool fec~%~%# Bandwidth in bit/s~%float32 bandwidth~%~%# Topic specific bandwidth~%TopicBandwidth[] topics~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: nimbro_topic_transport/TopicBandwidth~%# Topic name~%string name~%# Bandwidth~%float32 bandwidth~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SenderStats>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:length (cl:slot-value msg 'node))
     4 (cl:length (cl:slot-value msg 'protocol))
     4 (cl:length (cl:slot-value msg 'label))
     4 (cl:length (cl:slot-value msg 'host))
     4 (cl:length (cl:slot-value msg 'destination))
     2
     2
     1
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'topics) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SenderStats>))
  "Converts a ROS message object to a list"
  (cl:list 'SenderStats
    (cl:cons ':header (header msg))
    (cl:cons ':node (node msg))
    (cl:cons ':protocol (protocol msg))
    (cl:cons ':label (label msg))
    (cl:cons ':host (host msg))
    (cl:cons ':destination (destination msg))
    (cl:cons ':destination_port (destination_port msg))
    (cl:cons ':source_port (source_port msg))
    (cl:cons ':fec (fec msg))
    (cl:cons ':bandwidth (bandwidth msg))
    (cl:cons ':topics (topics msg))
))
