// Auto-generated. Do not edit!

// (in-package nimbro_topic_transport.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TopicBandwidth = require('./TopicBandwidth.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class SenderStats {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.node = null;
      this.protocol = null;
      this.label = null;
      this.host = null;
      this.destination = null;
      this.destination_port = null;
      this.source_port = null;
      this.fec = null;
      this.bandwidth = null;
      this.topics = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('node')) {
        this.node = initObj.node
      }
      else {
        this.node = '';
      }
      if (initObj.hasOwnProperty('protocol')) {
        this.protocol = initObj.protocol
      }
      else {
        this.protocol = '';
      }
      if (initObj.hasOwnProperty('label')) {
        this.label = initObj.label
      }
      else {
        this.label = '';
      }
      if (initObj.hasOwnProperty('host')) {
        this.host = initObj.host
      }
      else {
        this.host = '';
      }
      if (initObj.hasOwnProperty('destination')) {
        this.destination = initObj.destination
      }
      else {
        this.destination = '';
      }
      if (initObj.hasOwnProperty('destination_port')) {
        this.destination_port = initObj.destination_port
      }
      else {
        this.destination_port = 0;
      }
      if (initObj.hasOwnProperty('source_port')) {
        this.source_port = initObj.source_port
      }
      else {
        this.source_port = 0;
      }
      if (initObj.hasOwnProperty('fec')) {
        this.fec = initObj.fec
      }
      else {
        this.fec = false;
      }
      if (initObj.hasOwnProperty('bandwidth')) {
        this.bandwidth = initObj.bandwidth
      }
      else {
        this.bandwidth = 0.0;
      }
      if (initObj.hasOwnProperty('topics')) {
        this.topics = initObj.topics
      }
      else {
        this.topics = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SenderStats
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [node]
    bufferOffset = _serializer.string(obj.node, buffer, bufferOffset);
    // Serialize message field [protocol]
    bufferOffset = _serializer.string(obj.protocol, buffer, bufferOffset);
    // Serialize message field [label]
    bufferOffset = _serializer.string(obj.label, buffer, bufferOffset);
    // Serialize message field [host]
    bufferOffset = _serializer.string(obj.host, buffer, bufferOffset);
    // Serialize message field [destination]
    bufferOffset = _serializer.string(obj.destination, buffer, bufferOffset);
    // Serialize message field [destination_port]
    bufferOffset = _serializer.uint16(obj.destination_port, buffer, bufferOffset);
    // Serialize message field [source_port]
    bufferOffset = _serializer.uint16(obj.source_port, buffer, bufferOffset);
    // Serialize message field [fec]
    bufferOffset = _serializer.bool(obj.fec, buffer, bufferOffset);
    // Serialize message field [bandwidth]
    bufferOffset = _serializer.float32(obj.bandwidth, buffer, bufferOffset);
    // Serialize message field [topics]
    // Serialize the length for message field [topics]
    bufferOffset = _serializer.uint32(obj.topics.length, buffer, bufferOffset);
    obj.topics.forEach((val) => {
      bufferOffset = TopicBandwidth.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SenderStats
    let len;
    let data = new SenderStats(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [node]
    data.node = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [protocol]
    data.protocol = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [label]
    data.label = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [host]
    data.host = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [destination]
    data.destination = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [destination_port]
    data.destination_port = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [source_port]
    data.source_port = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [fec]
    data.fec = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [bandwidth]
    data.bandwidth = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [topics]
    // Deserialize array length for message field [topics]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.topics = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.topics[i] = TopicBandwidth.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.node);
    length += _getByteLength(object.protocol);
    length += _getByteLength(object.label);
    length += _getByteLength(object.host);
    length += _getByteLength(object.destination);
    object.topics.forEach((val) => {
      length += TopicBandwidth.getMessageSize(val);
    });
    return length + 33;
  }

  static datatype() {
    // Returns string type for a message object
    return 'nimbro_topic_transport/SenderStats';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '785e5b5b423320e1379bc0c4ba6dbaa3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    
    # Node name
    string node
    
    # Protocol ("TCP" or "UDP")
    string protocol
    
    # Connection label
    string label
    
    # Local hostname
    string host
    
    # Destination address
    string destination
    
    # Destination port
    uint16 destination_port
    
    # Source port
    uint16 source_port
    
    # Is Forward Error Correction enabled?
    bool fec
    
    # Bandwidth in bit/s
    float32 bandwidth
    
    # Topic specific bandwidth
    TopicBandwidth[] topics
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: nimbro_topic_transport/TopicBandwidth
    # Topic name
    string name
    # Bandwidth
    float32 bandwidth
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SenderStats(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.node !== undefined) {
      resolved.node = msg.node;
    }
    else {
      resolved.node = ''
    }

    if (msg.protocol !== undefined) {
      resolved.protocol = msg.protocol;
    }
    else {
      resolved.protocol = ''
    }

    if (msg.label !== undefined) {
      resolved.label = msg.label;
    }
    else {
      resolved.label = ''
    }

    if (msg.host !== undefined) {
      resolved.host = msg.host;
    }
    else {
      resolved.host = ''
    }

    if (msg.destination !== undefined) {
      resolved.destination = msg.destination;
    }
    else {
      resolved.destination = ''
    }

    if (msg.destination_port !== undefined) {
      resolved.destination_port = msg.destination_port;
    }
    else {
      resolved.destination_port = 0
    }

    if (msg.source_port !== undefined) {
      resolved.source_port = msg.source_port;
    }
    else {
      resolved.source_port = 0
    }

    if (msg.fec !== undefined) {
      resolved.fec = msg.fec;
    }
    else {
      resolved.fec = false
    }

    if (msg.bandwidth !== undefined) {
      resolved.bandwidth = msg.bandwidth;
    }
    else {
      resolved.bandwidth = 0.0
    }

    if (msg.topics !== undefined) {
      resolved.topics = new Array(msg.topics.length);
      for (let i = 0; i < resolved.topics.length; ++i) {
        resolved.topics[i] = TopicBandwidth.Resolve(msg.topics[i]);
      }
    }
    else {
      resolved.topics = []
    }

    return resolved;
    }
};

module.exports = SenderStats;
